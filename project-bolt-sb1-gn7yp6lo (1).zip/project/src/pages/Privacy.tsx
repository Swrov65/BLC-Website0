import { Seo } from '@/components/Seo';
import { Card, SectionHeading } from '@/components/ui';

const sections = [
  {
    title: 'Information we collect',
    body: 'We collect the email address you register with, your display name, and any profile information you choose to provide. We also store project, notification, and support ticket data you create.',
  },
  {
    title: 'How we use your data',
    body: 'Your data is used to provide the BLC platform — authentication, dashboard, projects, and support. We do not sell your data to third parties.',
  },
  {
    title: 'Data security',
    body: 'All tables use Row Level Security. You can only access your own data. Admin access is enforced server-side. Secrets are never exposed to the browser.',
  },
  {
    title: 'Data retention',
    body: 'Your data is retained while your account is active. You may request deletion of your account and associated data by contacting us.',
  },
  {
    title: 'Cookies and sessions',
    body: 'BLC uses secure session tokens for authentication. We do not use advertising or tracking cookies.',
  },
  {
    title: 'Your rights',
    body: 'You can view and update your profile from your dashboard. You can request data export or deletion by contacting us.',
  },
];

export default function Privacy() {
  return (
    <>
      <Seo title="Privacy Policy" description="How Bangladesh Logic Code collects, uses, and protects your data." />
      <section className="section py-16">
        <SectionHeading center eyebrow="Legal" title="Privacy Policy" subtitle={`Last updated: ${new Date().toLocaleDateString()}`} />
        <div className="max-w-3xl mx-auto space-y-6">
          {sections.map((s) => (
            <Card key={s.title}>
              <h2 className="text-lg font-bold text-white">{s.title}</h2>
              <p className="mt-3 text-sm text-neutral-400 leading-relaxed">{s.body}</p>
            </Card>
          ))}
          <p className="text-xs text-neutral-500 text-center">
            Bangladesh Logic Code · Founded by Soyaif
          </p>
        </div>
      </section>
    </>
  );
}
