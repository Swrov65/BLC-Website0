import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, Settings, Sparkles, ShieldCheck } from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Card, Badge } from '@/components/ui';
import { Button } from '@/components/Button';

const toolMeta: Record<string, { name: string; description: string; provider: string }> = {
  image: { name: 'AI Image Generator', description: 'Generate images from text prompts using a real image-generation provider.', provider: 'Image generation API (e.g. OpenAI DALL·E, Stability AI)' },
  video: { name: 'AI Video Generator', description: 'Generate videos from text or image prompts using a compatible video-generation provider.', provider: 'Video generation API (e.g. Runway, Pika)' },
  voice: { name: 'AI Voice Generator', description: 'Convert text into natural-sounding speech using a real text-to-speech provider.', provider: 'TTS API (e.g. OpenAI TTS, ElevenLabs)' },
  logo: { name: 'AI Logo Designer', description: 'Generate logo concepts from text descriptions.', provider: 'Image generation API (e.g. OpenAI DALL·E, Stability AI)' },
  search: { name: 'AI Search Engine', description: 'Search the web with a real search API and display source links.', provider: 'Search API (e.g. Tavily, SerpAPI, Google Custom Search)' },
};

export default function AiToolPlaceholder() {
  const { tool } = useParams<{ tool: string }>();
  const meta = toolMeta[tool ?? ''] ?? { name: 'AI Tool', description: 'This tool is part of the BLC AI suite.', provider: 'Configuration required' };

  return (
    <>
      <Seo title={meta.name} />
      <section className="section py-16">
        <Link to="/" className="inline-flex items-center gap-1.5 text-sm text-secondary-400 hover:text-secondary-300 mb-6">
          <ArrowLeft className="h-4 w-4" /> Back to BLC Home
        </Link>
        <Card className="max-w-2xl mx-auto text-center">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-secondary-500/20 to-accent-500/20 border border-secondary-500/30 mx-auto">
            <Sparkles className="h-7 w-7 text-secondary-400" />
          </div>
          <h1 className="mt-6 text-2xl font-bold text-white">{meta.name}</h1>
          <p className="mt-3 text-neutral-400 leading-relaxed">{meta.description}</p>
          <div className="mt-6 flex items-center justify-center gap-2">
            <Badge variant="warning"><Settings className="h-3.5 w-3.5" /> Setup Required</Badge>
            <Badge variant="neutral">External Provider</Badge>
          </div>
          <div className="mt-6 rounded-lg border border-neutral-800 bg-blc-navy-800/50 p-4 text-left">
            <p className="text-xs font-semibold uppercase tracking-wider text-neutral-500 mb-2">Required Provider</p>
            <p className="text-sm text-neutral-300">{meta.provider}</p>
          </div>
          <p className="mt-6 text-sm text-neutral-500">
            This tool requires an external provider that cannot use the existing chat-based AI endpoint.
            It will not display fake or simulated output. Once the required provider is configured server-side,
            a dedicated edge function will be built for it.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
            <Link to="/ai-lab"><Button rightIcon={<ArrowLeft className="h-4 w-4 rotate-180" />}>Try AI Lab</Button></Link>
            <Link to="/dashboard/support"><Button variant="secondary">Contact Support</Button></Link>
          </div>
        </Card>
        <div className="max-w-2xl mx-auto mt-6 flex items-center justify-center gap-2 text-xs text-neutral-600">
          <ShieldCheck className="h-4 w-4 text-success-400" />
          API keys are never exposed to the browser. All AI calls run through secure server-side routes.
        </div>
      </section>
    </>
  );
}
