import { Link } from 'react-router-dom';
import { ArrowRight, Code2, BrainCircuit, Cloud, ShieldCheck, Terminal, AppWindow } from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Card, SectionHeading, StatusBadge } from '@/components/ui';
import { PRODUCTS } from '@/lib/data';

const productIcons: Record<string, typeof BrainCircuit> = {
  BrainCircuit, Code2, Cloud, AppWindow, Terminal, ShieldCheck,
};

export default function Products() {
  return (
    <>
      <Seo title="Products" description="Explore BLC products: Intelligence, Studio, Cloud, Apps, Developer Platform, and Security." />
      <section className="section py-16">
        <SectionHeading
          center
          eyebrow="Products"
          title="Six products. One platform."
          subtitle="Each product has an honest availability label. We never claim something is live when it is not."
        />
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {PRODUCTS.map((p) => {
            const Icon = productIcons[p.icon] ?? Code2;
            return (
              <Link key={p.id} to={`/products/${p.slug}`} className="group">
                <Card className="h-full hover:border-secondary-400/40 transition-all duration-300 hover:-translate-y-1">
                  <div className="flex items-start justify-between">
                    <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-secondary-500/20 to-accent-500/20 border border-secondary-500/30">
                      <Icon className="h-6 w-6 text-secondary-400" />
                    </div>
                    <StatusBadge status={p.availability} />
                  </div>
                  <h3 className="mt-5 text-lg font-bold text-white group-hover:text-secondary-300 transition-colors">{p.name}</h3>
                  <p className="mt-2 text-sm text-neutral-400 leading-relaxed">{p.tagline}</p>
                  <span className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-secondary-400">
                    View details <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </span>
                </Card>
              </Link>
            );
          })}
        </div>
      </section>
    </>
  );
}
