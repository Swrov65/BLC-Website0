import { Seo } from '@/components/Seo';
import { Card, SectionHeading } from '@/components/ui';

const sections = [
  { title: 'Acceptance of terms', body: 'By accessing or using Bangladesh Logic Code, you agree to these terms of service. If you do not agree, do not use the platform.' },
  { title: 'Use of the platform', body: 'You agree to use BLC lawfully and not to abuse, attack, or disrupt the service. You are responsible for your account and its content.' },
  { title: 'Accounts', body: 'You must provide accurate information and keep your credentials secure. You are responsible for activity under your account.' },
  { title: 'Acceptable use', body: 'You may not use BLC to store illegal content, attempt to access other users\' data, or attempt to bypass security controls.' },
  { title: 'Service availability', body: 'BLC is provided "as is". We do not guarantee uninterrupted availability. Planned products may not be fully functional.' },
  { title: 'Limitation of liability', body: 'To the maximum extent permitted by law, BLC and its founder are not liable for indirect or consequential damages arising from use of the platform.' },
  { title: 'Changes to terms', body: 'We may update these terms from time to time. Continued use after changes constitutes acceptance of the new terms.' },
];

export default function Terms() {
  return (
    <>
      <Seo title="Terms of Service" description="Terms of service for Bangladesh Logic Code." />
      <section className="section py-16">
        <SectionHeading center eyebrow="Legal" title="Terms of Service" subtitle={`Last updated: ${new Date().toLocaleDateString()}`} />
        <div className="max-w-3xl mx-auto space-y-6">
          {sections.map((s) => (
            <Card key={s.title}>
              <h2 className="text-lg font-bold text-white">{s.title}</h2>
              <p className="mt-3 text-sm text-neutral-400 leading-relaxed">{s.body}</p>
            </Card>
          ))}
          <p className="text-xs text-neutral-500 text-center">Bangladesh Logic Code · Founded by Soyaif</p>
        </div>
      </section>
    </>
  );
}
