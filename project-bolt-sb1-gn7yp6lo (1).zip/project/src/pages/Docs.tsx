import { useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Search, BookOpen, ChevronRight, FileText } from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Card, EmptyState } from '@/components/ui';
import { Button } from '@/components/Button';
import { DOCS } from '@/lib/data';

export default function Docs() {
  const { slug } = useParams<{ slug: string }>();
  const [query, setQuery] = useState('');

  const filtered = useMemo(() => {
    if (!query.trim()) return DOCS;
    const q = query.toLowerCase();
    return DOCS.filter(
      (d) => d.title.toLowerCase().includes(q) || d.excerpt.toLowerCase().includes(q) || d.body.toLowerCase().includes(q),
    );
  }, [query]);

  const categories = useMemo(() => {
    const map = new Map<string, typeof DOCS>();
    for (const d of DOCS) {
      const arr = map.get(d.category) ?? [];
      arr.push(d);
      map.set(d.category, arr);
    }
    return Array.from(map.entries());
  }, []);

  const current = slug ? DOCS.find((d) => d.slug === slug) : null;

  if (current) {
    return (
      <>
        <Seo title={current.title} description={current.excerpt} />
        <section className="section py-12">
          <Link to="/docs" className="inline-flex items-center gap-2 text-sm text-neutral-400 hover:text-secondary-400">
            <BookOpen className="h-4 w-4" /> All documentation
          </Link>
          <div className="mt-6 grid lg:grid-cols-4 gap-8">
            <aside className="lg:col-span-1 space-y-6">
              <DocNav categories={categories} activeSlug={current.slug} />
            </aside>
            <article className="lg:col-span-3">
              <Card>
                <p className="text-xs font-semibold uppercase tracking-wider text-secondary-400">{current.category}</p>
                <h1 className="mt-2 text-3xl font-bold text-white">{current.title}</h1>
                <div className="mt-6 prose prose-invert max-w-none text-neutral-300 leading-relaxed whitespace-pre-wrap">
                  {renderMarkdown(current.body)}
                </div>
              </Card>
            </article>
          </div>
        </section>
      </>
    );
  }

  return (
    <>
      <Seo title="Documentation" description="BLC documentation — getting started, APIs, authentication, security, and more." />
      <section className="section py-12">
        <div className="max-w-2xl">
          <h1 className="text-4xl font-bold text-white">Documentation</h1>
          <p className="mt-3 text-neutral-400">Everything you need to use the BLC platform.</p>
          <div className="mt-6 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-neutral-500" />
            <input
              type="search"
              placeholder="Search documentation..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="input pl-12"
              aria-label="Search documentation"
            />
          </div>
        </div>

        {filtered.length === 0 ? (
          <EmptyState
            icon={<FileText className="h-10 w-10" />}
            title="No results"
            description={`No articles match "${query}".`}
            action={<Button variant="secondary" onClick={() => setQuery('')}>Clear search</Button>}
          />
        ) : (
          <div className="mt-10 grid lg:grid-cols-4 gap-8">
            <aside className="lg:col-span-1">
              <DocNav categories={categories} />
            </aside>
            <div className="lg:col-span-3 space-y-3">
              {filtered.map((d) => (
                <Link key={d.slug} to={`/docs/${d.slug}`}>
                  <Card className="!py-4 hover:border-secondary-400/40 transition-colors group">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-xs text-secondary-400">{d.category}</p>
                        <h3 className="mt-1 font-semibold text-white group-hover:text-secondary-300 transition-colors">{d.title}</h3>
                        <p className="mt-1 text-sm text-neutral-400">{d.excerpt}</p>
                      </div>
                      <ChevronRight className="h-5 w-5 text-neutral-600 group-hover:text-secondary-400 transition-colors" />
                    </div>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        )}
      </section>
    </>
  );
}

function DocNav({ categories, activeSlug }: { categories: [string, typeof DOCS][]; activeSlug?: string }) {
  return (
    <nav className="space-y-6 sticky top-20">
      {categories.map(([cat, articles]) => (
        <div key={cat}>
          <p className="text-xs font-semibold uppercase tracking-wider text-neutral-500 mb-2">{cat}</p>
          <ul className="space-y-1">
            {articles.map((a) => (
              <li key={a.slug}>
                <Link
                  to={`/docs/${a.slug}`}
                  className={`block px-3 py-1.5 text-sm rounded-md transition-colors ${
                    activeSlug === a.slug ? 'text-secondary-400 bg-blc-navy-700' : 'text-neutral-400 hover:text-white hover:bg-neutral-800/50'
                  }`}
                >
                  {a.title}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      ))}
    </nav>
  );
}

function renderMarkdown(body: string) {
  const lines = body.split('\n');
  return lines.map((line, i) => {
    if (line.startsWith('# ')) return <h1 key={i} className="text-2xl font-bold text-white mt-6 mb-3">{line.slice(2)}</h1>;
    if (line.startsWith('## ')) return <h2 key={i} className="text-xl font-semibold text-white mt-5 mb-2">{line.slice(3)}</h2>;
    if (line.startsWith('**') && line.endsWith('**')) return <p key={i} className="font-semibold text-white mt-3">{line.slice(2, -2)}</p>;
    if (line.startsWith('- ')) return <li key={i} className="ml-4 text-neutral-300">{line.slice(2)}</li>;
    if (line.startsWith('```')) return null;
    if (line.trim() === '') return <div key={i} className="h-3" />;
    return <p key={i} className="text-neutral-300">{line}</p>;
  });
}
