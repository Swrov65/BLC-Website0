import { Link } from 'react-router-dom';
import { Target, Eye, Heart, Code2, ShieldCheck, Rocket, Users, ArrowRight } from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Card, SectionHeading, Badge } from '@/components/ui';
import { Button } from '@/components/Button';
import { TechBackground } from '@/components/TechBackground';

const values = [
  { icon: Code2, title: 'Craftsmanship', desc: 'We treat code as a craft — clear, maintainable, and honest.' },
  { icon: ShieldCheck, title: 'Security first', desc: 'Security is never an afterthought. It is designed in from the start.' },
  { icon: Rocket, title: 'Bias for shipping', desc: 'We ship working software and iterate based on real feedback.' },
  { icon: Heart, title: 'Respect for users', desc: 'We respect privacy, time, and accessibility for everyone.' },
];

const roadmap = [
  { phase: 'Phase 1', title: 'Foundation', status: 'live', items: ['Public website', 'Authentication', 'User dashboard', 'Admin panel', 'Security overview'] },
  { phase: 'Phase 2', title: 'Platform', status: 'in_development', items: ['Developer Platform APIs', 'AI Lab integration', 'API key management', 'Webhooks'] },
  { phase: 'Phase 3', title: 'Scale', status: 'planned', items: ['BLC Cloud infrastructure', 'BLC Studio tooling', 'BLC Apps collection', 'Marketplace concept'] },
];

export default function About() {
  return (
    <>
      <Seo title="About" description="Bangladesh Logic Code — mission, vision, values, roadmap, and founder profile. Founded by Soyaif." />
      <section className="relative overflow-hidden">
        <TechBackground />
        <div className="section relative py-20 text-center">
          <Badge variant="info">About BLC</Badge>
          <h1 className="mt-6 text-4xl sm:text-5xl font-bold heading-gradient">Engineering beyond boundaries</h1>
          <p className="mt-6 max-w-2xl mx-auto text-neutral-400 text-lg leading-relaxed">
            Bangladesh Logic Code is a technology platform founded by Soyaif with a mission to make
            intelligent, secure, and accessible software available to everyone.
          </p>
        </div>
      </section>

      <section className="section py-16">
        <div className="grid lg:grid-cols-2 gap-8">
          <Card>
            <Target className="h-8 w-8 text-secondary-400" />
            <h2 className="mt-4 text-2xl font-bold text-white">Mission</h2>
            <p className="mt-3 text-neutral-400 leading-relaxed">
              To build technology that is intelligent, secure, and accessible — empowering developers and
              organizations to solve meaningful problems without compromising on quality or trust.
            </p>
          </Card>
          <Card>
            <Eye className="h-8 w-8 text-accent-400" />
            <h2 className="mt-4 text-2xl font-bold text-white">Vision</h2>
            <p className="mt-3 text-neutral-400 leading-relaxed">
              A world where powerful developer tools, AI workspaces, and cloud infrastructure are within
              reach of every builder — regardless of geography or budget.
            </p>
          </Card>
        </div>
      </section>

      <section className="section py-16">
        <SectionHeading center eyebrow="Values" title="What we believe in" />
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {values.map((v) => (
            <Card key={v.title}>
              <v.icon className="h-7 w-7 text-secondary-400" />
              <h4 className="mt-4 font-semibold text-white">{v.title}</h4>
              <p className="mt-2 text-sm text-neutral-400">{v.desc}</p>
            </Card>
          ))}
        </div>
      </section>

      <section className="section py-16">
        <SectionHeading center eyebrow="Roadmap" title="Technology roadmap" subtitle="An honest view of where we are and where we are going." />
        <div className="grid lg:grid-cols-3 gap-6">
          {roadmap.map((r) => (
            <Card key={r.phase}>
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold uppercase tracking-wider text-secondary-400">{r.phase}</span>
                <Badge variant={r.status === 'live' ? 'success' : r.status === 'in_development' ? 'warning' : 'neutral'}>
                  {r.status === 'live' ? 'Live' : r.status === 'in_development' ? 'In progress' : 'Planned'}
                </Badge>
              </div>
              <h3 className="mt-3 text-xl font-bold text-white">{r.title}</h3>
              <ul className="mt-4 space-y-2">
                {r.items.map((item) => (
                  <li key={item} className="text-sm text-neutral-400 flex items-center gap-2">
                    <span className="h-1.5 w-1.5 rounded-full bg-secondary-400" />
                    {item}
                  </li>
                ))}
              </ul>
            </Card>
          ))}
        </div>
      </section>

      <section className="section py-16">
        <SectionHeading center eyebrow="Philosophy" title="Development philosophy" />
        <Card className="max-w-3xl mx-auto">
          <ul className="space-y-4 text-neutral-300">
            {[
              'Build complete, working features — not just mockups.',
              'Be honest about what works and what does not.',
              'Never expose secrets or fake a working integration.',
              'Security and accessibility are requirements, not nice-to-haves.',
              'Ship in phases, iterate, and keep track of unfinished work.',
            ].map((p) => (
              <li key={p} className="flex items-start gap-3">
                <ShieldCheck className="h-5 w-5 text-success-400 shrink-0 mt-0.5" />
                <span>{p}</span>
              </li>
            ))}
          </ul>
        </Card>
      </section>

      <section className="section py-16">
        <Card className="overflow-hidden">
          <div className="grid lg:grid-cols-3 gap-8 items-center">
            <div className="flex justify-center">
              <div className="relative">
                <div className="absolute inset-0 rounded-full bg-gradient-to-br from-secondary-500/30 to-accent-500/30 blur-2xl" />
                <div className="relative h-32 w-32 rounded-full glass flex items-center justify-center">
                  <Users className="h-12 w-12 text-secondary-400" />
                </div>
              </div>
            </div>
            <div className="lg:col-span-2">
              <Badge variant="accent">Founder & Developer</Badge>
              <h2 className="mt-4 text-3xl font-bold text-white">Soyaif</h2>
              <p className="mt-4 text-neutral-400 leading-relaxed">
                Soyaif is the founder and developer of Bangladesh Logic Code. The platform reflects a
                commitment to honest engineering — building real, working software and being transparent
                about what is ready and what is still in progress.
              </p>
              <p className="mt-3 text-neutral-400 leading-relaxed">
                Every product page states its true availability. No fake analytics, no invented
                testimonials, no claimed certifications. Just a platform that is built to last.
              </p>
              <Link to="/contact" className="inline-block mt-6">
                <Button rightIcon={<ArrowRight className="h-4 w-4" />}>Get in touch</Button>
              </Link>
            </div>
          </div>
        </Card>
      </section>
    </>
  );
}
