import { useState, useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Mail, Lock, ArrowRight, ArrowLeft, User, Check, X } from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Logo } from '@/components/Logo';
import { Button } from '@/components/Button';
import { Card } from '@/components/ui';
import { useAuth } from '@/auth/AuthContext';
import { useToast } from '@/components/Toast';
import { isSupabaseConfigured } from '@/lib/supabase';

function getPasswordStrength(password: string) {
  const checks = [
    { label: 'At least 8 characters', passed: password.length >= 8 },
    { label: 'Contains uppercase letter', passed: /[A-Z]/.test(password) },
    { label: 'Contains lowercase letter', passed: /[a-z]/.test(password) },
    { label: 'Contains a number', passed: /\d/.test(password) },
    { label: 'Contains a special character', passed: /[^A-Za-z0-9]/.test(password) },
  ];
  const score = checks.filter((c) => c.passed).length;
  return { checks, score, allPassed: score === 5 };
}

export default function Signup() {
  const { signUp } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showStrength, setShowStrength] = useState(false);
  const [loading, setLoading] = useState(false);

  const { checks, score, allPassed } = useMemo(() => getPasswordStrength(password), [password]);
  const strengthLabel = score <= 1 ? 'Very weak' : score === 2 ? 'Weak' : score === 3 ? 'Fair' : score === 4 ? 'Good' : 'Strong';
  const strengthColor = score <= 2 ? 'text-error-400' : score === 3 ? 'text-warning-400' : 'text-success-400';

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!isSupabaseConfigured) {
      toast.push({ title: 'Backend not configured', description: 'Supabase must be configured for authentication.', variant: 'error' });
      return;
    }
    if (!allPassed) {
      toast.push({ title: 'Password too weak', description: 'Meet all password requirements.', variant: 'warning' });
      return;
    }
    setLoading(true);
    const { error } = await signUp(email, password, name.trim() || undefined);
    if (error) {
      setLoading(false);
      toast.push({ title: 'Sign up failed', description: error, variant: 'error' });
      return;
    }
    toast.push({ title: 'Account created', description: 'You can now sign in.', variant: 'success' });
    setLoading(false);
    navigate('/login');
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-hero-gradient">
      <Seo title="Sign up" />
      <div className="w-full max-w-md">
        <div className="flex justify-center mb-8">
          <Link to="/"><Logo /></Link>
        </div>
        <Card>
          <h1 className="text-2xl font-bold text-white">Create your account</h1>
          <p className="mt-2 text-sm text-neutral-400">Join the BLC platform.</p>

          {!isSupabaseConfigured && (
            <div className="mt-4 rounded-lg border border-warning-500/30 bg-warning-500/10 p-3 text-xs text-warning-300">
              Supabase is not configured. Authentication is unavailable until it is set up.
            </div>
          )}

          <form onSubmit={handleSubmit} className="mt-6 space-y-4" noValidate>
            <div>
              <label className="label" htmlFor="name">Display name</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-500" />
                <input id="name" type="text" required value={name} onChange={(e) => setName(e.target.value)} className="input pl-10" placeholder="Your name" />
              </div>
            </div>
            <div>
              <label className="label" htmlFor="email">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-500" />
                <input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="input pl-10" placeholder="you@example.com" />
              </div>
            </div>
            <div>
              <label className="label" htmlFor="password">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-500" />
                <input
                  id="password"
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  onFocus={() => setShowStrength(true)}
                  className="input pl-10"
                  placeholder="Strong password"
                />
              </div>
              {showStrength && password.length > 0 && (
                <div className="mt-2 space-y-1.5">
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-1.5 rounded-full bg-neutral-800 overflow-hidden">
                      <div
                        className={`h-full transition-all duration-300 ${score <= 2 ? 'bg-error-400' : score === 3 ? 'bg-warning-400' : 'bg-success-400'}`}
                        style={{ width: `${(score / 5) * 100}%` }}
                      />
                    </div>
                    <span className={`text-xs font-medium ${strengthColor}`}>{strengthLabel}</span>
                  </div>
                  <div className="grid grid-cols-1 gap-1">
                    {checks.map((c) => (
                      <div key={c.label} className="flex items-center gap-1.5 text-xs">
                        {c.passed ? <Check className="h-3 w-3 text-success-400" /> : <X className="h-3 w-3 text-neutral-600" />}
                        <span className={c.passed ? 'text-neutral-300' : 'text-neutral-500'}>{c.label}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
            <Button type="submit" className="w-full" loading={loading} rightIcon={!loading ? <ArrowRight className="h-4 w-4" /> : undefined}>
              Create account
            </Button>
          </form>

          <p className="mt-6 text-center text-sm text-neutral-400">
            Already have an account? <Link to="/login" className="text-secondary-400 hover:text-secondary-300 font-medium">Sign in</Link>
          </p>
        </Card>
        <div className="mt-6 text-center">
          <Link to="/" className="inline-flex items-center gap-1 text-xs text-neutral-500 hover:text-neutral-300">
            <ArrowLeft className="h-3 w-3" /> Back to home
          </Link>
        </div>
      </div>
    </div>
  );
}
