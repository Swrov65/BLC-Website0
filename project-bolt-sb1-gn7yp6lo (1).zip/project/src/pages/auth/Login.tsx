import { useState, useRef, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Mail, Lock, ArrowRight, ArrowLeft, ShieldAlert } from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Logo } from '@/components/Logo';
import { Button } from '@/components/Button';
import { Card } from '@/components/ui';
import { useAuth } from '@/auth/AuthContext';
import { useToast } from '@/components/Toast';
import { isSupabaseConfigured } from '@/lib/supabase';

const MAX_ATTEMPTS = 5;
const LOCKOUT_SECONDS = 60;

export default function Login() {
  const { signIn } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [attempts, setAttempts] = useState(0);
  const [lockoutUntil, setLockoutUntil] = useState<number | null>(null);
  const [remainingLock, setRemainingLock] = useState(0);
  const lockTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const from = (location.state as { from?: string })?.from ?? '/';

  useEffect(() => {
    if (lockoutUntil === null) {
      if (lockTimerRef.current) {
        clearInterval(lockTimerRef.current);
        lockTimerRef.current = null;
      }
      return;
    }
    setRemainingLock(Math.max(0, Math.ceil((lockoutUntil - Date.now()) / 1000)));
    lockTimerRef.current = setInterval(() => {
      const remaining = Math.max(0, Math.ceil((lockoutUntil - Date.now()) / 1000));
      setRemainingLock(remaining);
      if (remaining <= 0) {
        setLockoutUntil(null);
        setAttempts(0);
        if (lockTimerRef.current) {
          clearInterval(lockTimerRef.current);
          lockTimerRef.current = null;
        }
      }
    }, 1000);
    return () => {
      if (lockTimerRef.current) {
        clearInterval(lockTimerRef.current);
        lockTimerRef.current = null;
      }
    };
  }, [lockoutUntil]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!isSupabaseConfigured) {
      toast.push({ title: 'Backend not configured', description: 'Supabase must be configured for authentication.', variant: 'error' });
      return;
    }
    if (lockoutUntil !== null) {
      toast.push({ title: 'Too many attempts', description: `Try again in ${remainingLock} seconds.`, variant: 'warning' });
      return;
    }
    setLoading(true);
    const { error } = await signIn(email, password);
    setLoading(false);
    if (error) {
      const newAttempts = attempts + 1;
      setAttempts(newAttempts);
      if (newAttempts >= MAX_ATTEMPTS) {
        setLockoutUntil(Date.now() + LOCKOUT_SECONDS * 1000);
        toast.push({
          title: 'Account temporarily locked',
          description: `Too many failed attempts. Wait ${LOCKOUT_SECONDS} seconds before trying again.`,
          variant: 'error',
        });
      } else {
        const remaining = MAX_ATTEMPTS - newAttempts;
        toast.push({
          title: 'Sign in failed',
          description: `${error}${remaining > 0 ? ` (${remaining} attempts remaining)` : ''}`,
          variant: 'error',
        });
      }
    } else {
      setAttempts(0);
      toast.push({ title: 'Welcome back', variant: 'success' });
      navigate(from, { replace: true });
    }
  }

  const isLocked = lockoutUntil !== null && remainingLock > 0;

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-hero-gradient">
      <Seo title="Sign in" />
      <div className="w-full max-w-md">
        <div className="flex justify-center mb-8">
          <Link to="/"><Logo /></Link>
        </div>
        <Card>
          <h1 className="text-2xl font-bold text-white">Sign in</h1>
          <p className="mt-2 text-sm text-neutral-400">Welcome back to BLC.</p>

          {!isSupabaseConfigured && (
            <div className="mt-4 rounded-lg border border-warning-500/30 bg-warning-500/10 p-3 text-xs text-warning-300">
              Supabase is not configured. Authentication is unavailable until it is set up.
            </div>
          )}

          {isLocked && (
            <div className="mt-4 rounded-lg border border-error-500/30 bg-error-500/10 p-3 flex items-start gap-2">
              <ShieldAlert className="h-4 w-4 text-error-400 shrink-0 mt-0.5" />
              <p className="text-xs text-error-300">
                Too many failed login attempts. Please wait <span className="font-bold">{remainingLock}s</span> before trying again.
              </p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="mt-6 space-y-4" noValidate>
            <div>
              <label className="label" htmlFor="email">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-500" />
                <input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="input pl-10" placeholder="you@example.com" disabled={isLocked} />
              </div>
            </div>
            <div>
              <label className="label" htmlFor="password">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-500" />
                <input id="password" type="password" required value={password} onChange={(e) => setPassword(e.target.value)} className="input pl-10" placeholder="••••••••" disabled={isLocked} />
              </div>
            </div>
            <div className="flex justify-end">
              <Link to="/reset-password" className="text-xs text-secondary-400 hover:text-secondary-300">Forgot password?</Link>
            </div>
            <Button type="submit" className="w-full" loading={loading} disabled={isLocked} rightIcon={!loading && !isLocked ? <ArrowRight className="h-4 w-4" /> : undefined}>
              {isLocked ? `Locked (${remainingLock}s)` : 'Sign in'}
            </Button>
          </form>

          <p className="mt-6 text-center text-sm text-neutral-400">
            No account? <Link to="/signup" className="text-secondary-400 hover:text-secondary-300 font-medium">Sign up</Link>
          </p>
        </Card>
        <div className="mt-6 text-center">
          <Link to="/" className="inline-flex items-center gap-1 text-xs text-neutral-500 hover:text-neutral-300">
            <ArrowLeft className="h-3 w-3" /> Back to home
          </Link>
        </div>
      </div>
    </div>
  );
}
