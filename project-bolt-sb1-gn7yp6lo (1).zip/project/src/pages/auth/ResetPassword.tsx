import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Mail, ArrowLeft, ArrowRight } from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Logo } from '@/components/Logo';
import { Button } from '@/components/Button';
import { Card } from '@/components/ui';
import { useToast } from '@/components/Toast';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';

export default function ResetPassword() {
  const toast = useToast();
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!isSupabaseConfigured) {
      toast.push({ title: 'Backend not configured', description: 'Supabase must be configured.', variant: 'error' });
      return;
    }
    setLoading(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email);
    setLoading(false);
    if (error) {
      toast.push({ title: 'Request failed', description: error.message, variant: 'error' });
    } else {
      setSent(true);
      toast.push({ title: 'Reset link sent', description: 'Check your email if delivery is configured.', variant: 'success' });
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-hero-gradient">
      <Seo title="Reset password" />
      <div className="w-full max-w-md">
        <div className="flex justify-center mb-8">
          <Link to="/"><Logo /></Link>
        </div>
        <Card>
          <h1 className="text-2xl font-bold text-white">Reset password</h1>
          <p className="mt-2 text-sm text-neutral-400">Enter your email to receive a reset link.</p>

          {sent ? (
            <div className="mt-6 rounded-lg border border-success-500/30 bg-success-500/10 p-4 text-sm text-success-300">
              If an account exists for that email, a reset link has been sent. This requires email delivery to be configured.
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="mt-6 space-y-4" noValidate>
              <div>
                <label className="label" htmlFor="email">Email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-500" />
                  <input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="input pl-10" placeholder="you@example.com" />
                </div>
              </div>
              <Button type="submit" className="w-full" loading={loading} rightIcon={!loading ? <ArrowRight className="h-4 w-4" /> : undefined}>
                Send reset link
              </Button>
            </form>
          )}

          <p className="mt-6 text-center text-sm text-neutral-400">
            <Link to="/login" className="text-secondary-400 hover:text-secondary-300 font-medium">Back to sign in</Link>
          </p>
        </Card>
        <div className="mt-6 text-center">
          <Link to="/" className="inline-flex items-center gap-1 text-xs text-neutral-500 hover:text-neutral-300">
            <ArrowLeft className="h-3 w-3" /> Back to home
          </Link>
        </div>
      </div>
    </div>
  );
}
