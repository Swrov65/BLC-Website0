import { useEffect, useState, useCallback } from 'react';
import {
  Code2, FilePlus, Trash2, FileText, Folder, Loader2, Download, Upload, Eye, Save,
} from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Card, Badge, EmptyState, Spinner } from '@/components/ui';
import { Button } from '@/components/Button';
import { useAuth } from '@/auth/AuthContext';
import { useToast } from '@/components/Toast';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import type { Project, ProjectFile } from '@/types';
import { cn } from '@/lib/utils';

const SUPPORTED_EXTENSIONS = ['html', 'css', 'js', 'jsx', 'ts', 'tsx', 'json', 'md', 'txt', 'xml', 'svg'];

function getFileType(filename: string): string {
  const ext = filename.split('.').pop()?.toLowerCase() ?? '';
  return ext;
}

function getLanguageLabel(ext: string): string {
  const map: Record<string, string> = {
    html: 'HTML', css: 'CSS', js: 'JavaScript', jsx: 'React JSX',
    ts: 'TypeScript', tsx: 'React TSX', json: 'JSON', md: 'Markdown',
    txt: 'Text', xml: 'XML', svg: 'SVG',
  };
  return map[ext] ?? 'Text';
}

export default function DashboardStudio() {
  const { user } = useAuth();
  const toast = useToast();
  const [projects, setProjects] = useState<Project[]>([]);
  const [activeProject, setActiveProject] = useState<Project | null>(null);
  const [files, setFiles] = useState<ProjectFile[]>([]);
  const [activeFile, setActiveFile] = useState<ProjectFile | null>(null);
  const [fileContent, setFileContent] = useState('');
  const [loadingProjects, setLoadingProjects] = useState(true);
  const [loadingFiles, setLoadingFiles] = useState(false);
  const [saving, setSaving] = useState(false);
  const [newFilename, setNewFilename] = useState('');
  const [showNewFile, setShowNewFile] = useState(false);
  const [previewMode, setPreviewMode] = useState(false);

  const loadProjects = useCallback(async () => {
    if (!isSupabaseConfigured || !user) {
      setLoadingProjects(false);
      return;
    }
    try {
      const { data, error } = await supabase
        .from('projects')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      if (error) throw error;
      setProjects((data ?? []) as Project[]);
      if (data && data.length > 0 && !activeProject) setActiveProject(data[0] as Project);
    } catch (err) {
      console.warn('Failed to load projects', err);
    } finally {
      setLoadingProjects(false);
    }
  }, [user, activeProject]);

  const loadFiles = useCallback(async (projectId: string) => {
    setLoadingFiles(true);
    try {
      const { data, error } = await supabase
        .from('project_files')
        .select('*')
        .eq('project_id', projectId)
        .order('file_path', { ascending: true });
      if (error) throw error;
      setFiles((data ?? []) as ProjectFile[]);
    } catch (err) {
      console.warn('Failed to load files', err);
    } finally {
      setLoadingFiles(false);
    }
  }, []);

  useEffect(() => {
    void loadProjects();
  }, [loadProjects]);

  useEffect(() => {
    if (activeProject) void loadFiles(activeProject.id);
    else { setFiles([]); setActiveFile(null); }
  }, [activeProject, loadFiles]);

  async function createFile(e: React.FormEvent) {
    e.preventDefault();
    if (!newFilename.trim() || !activeProject || !user) return;
    const filename = newFilename.trim();
    const ext = getFileType(filename);
    if (!SUPPORTED_EXTENSIONS.includes(ext)) {
      toast.push({ title: 'Unsupported file type', description: `Allowed: ${SUPPORTED_EXTENSIONS.join(', ')}`, variant: 'warning' });
      return;
    }
    try {
      const { data, error } = await supabase
        .from('project_files')
        .insert({
          project_id: activeProject.id,
          user_id: user.id,
          filename,
          file_path: filename,
          content: '',
          file_type: ext,
          size_bytes: 0,
        })
        .select('*')
        .single();
      if (error) throw error;
      setFiles((prev) => [...prev, data as ProjectFile]);
      setActiveFile(data as ProjectFile);
      setFileContent('');
      setNewFilename('');
      setShowNewFile(false);
      toast.push({ title: 'File created', variant: 'success' });
    } catch (err) {
      toast.push({ title: 'Could not create file', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    }
  }

  async function saveFile() {
    if (!activeFile) return;
    setSaving(true);
    try {
      const { error } = await supabase
        .from('project_files')
        .update({ content: fileContent, size_bytes: new TextEncoder().encode(fileContent).length, updated_at: new Date().toISOString() })
        .eq('id', activeFile.id);
      if (error) throw error;
      setFiles((prev) => prev.map((f) => (f.id === activeFile.id ? { ...f, content: fileContent, size_bytes: new TextEncoder().encode(fileContent).length } : f)));
      toast.push({ title: 'File saved', variant: 'success' });
    } catch (err) {
      toast.push({ title: 'Save failed', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    } finally {
      setSaving(false);
    }
  }

  async function deleteFile(file: ProjectFile) {
    try {
      const { error } = await supabase.from('project_files').delete().eq('id', file.id);
      if (error) throw error;
      setFiles((prev) => prev.filter((f) => f.id !== file.id));
      if (activeFile?.id === file.id) { setActiveFile(null); setFileContent(''); }
      toast.push({ title: 'File deleted', variant: 'success' });
    } catch (err) {
      toast.push({ title: 'Delete failed', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    }
  }

  function selectFile(file: ProjectFile) {
    setActiveFile(file);
    setFileContent(file.content ?? '');
    setPreviewMode(false);
  }

  function exportProject() {
    if (files.length === 0) {
      toast.push({ title: 'No files to export', variant: 'warning' });
      return;
    }
    const exportData = files.map((f) => ({ filename: f.filename, content: f.content ?? '' }));
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${activeProject?.name ?? 'project'}-export.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.push({ title: 'Project exported', variant: 'success' });
  }

  const canPreview = activeFile && (getFileType(activeFile.filename) === 'html');

  return (
    <>
      <Seo title="BLC Studio" />
      <h1 className="text-2xl font-bold text-white mb-6">BLC Studio</h1>

      {!isSupabaseConfigured && (
        <Card className="mb-6 border-warning-500/20">
          <p className="text-sm text-warning-300">Backend not configured. Studio requires Supabase to store project files.</p>
        </Card>
      )}

      {loadingProjects ? (
        <div className="flex justify-center py-12"><Spinner className="h-6 w-6" /></div>
      ) : projects.length === 0 ? (
        <Card>
          <EmptyState
            icon={<Code2 className="h-10 w-10" />}
            title="No projects yet"
            description="Create a project from the Projects page to start coding in BLC Studio."
          />
        </Card>
      ) : (
        <div className="grid lg:grid-cols-4 gap-4 h-[calc(100vh-14rem)] min-h-[500px]">
          {/* Project selector + file explorer */}
          <Card className="lg:col-span-1 flex flex-col !p-3">
            <div className="mb-3">
              <label className="label text-xs mb-1">Project</label>
              <select
                className="input text-sm"
                value={activeProject?.id ?? ''}
                onChange={(e) => {
                  const p = projects.find((pr) => pr.id === e.target.value);
                  setActiveProject(p ?? null);
                  setActiveFile(null);
                }}
              >
                {projects.map((p) => (
                  <option key={p.id} value={p.id}>{p.name}</option>
                ))}
              </select>
            </div>

            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-neutral-400 uppercase tracking-wider">Files</span>
              <div className="flex gap-1">
                <button onClick={() => setShowNewFile(!showNewFile)} className="p-1 text-neutral-400 hover:text-secondary-400" aria-label="New file">
                  <FilePlus className="h-4 w-4" />
                </button>
                <button onClick={exportProject} className="p-1 text-neutral-400 hover:text-secondary-400" aria-label="Export">
                  <Download className="h-4 w-4" />
                </button>
              </div>
            </div>

            {showNewFile && (
              <form onSubmit={createFile} className="mb-2">
                <input
                  className="input text-xs"
                  placeholder="filename.html"
                  value={newFilename}
                  onChange={(e) => setNewFilename(e.target.value)}
                  autoFocus
                />
              </form>
            )}

            <div className="flex-1 overflow-y-auto space-y-1">
              {loadingFiles ? (
                <div className="flex justify-center py-8"><Loader2 className="h-4 w-4 animate-spin text-neutral-500" /></div>
              ) : files.length === 0 ? (
                <p className="text-xs text-neutral-500 text-center py-8">No files. Create one to start.</p>
              ) : (
                files.map((f) => (
                  <div
                    key={f.id}
                    className={cn(
                      'group flex items-center gap-2 rounded-lg px-2 py-1.5 cursor-pointer transition-colors',
                      activeFile?.id === f.id ? 'bg-blc-navy-700 text-white' : 'text-neutral-400 hover:bg-neutral-800/50',
                    )}
                    onClick={() => selectFile(f)}
                  >
                    <FileText className="h-3.5 w-3.5 shrink-0 text-secondary-400" />
                    <span className="text-sm truncate flex-1">{f.filename}</span>
                    <button
                      onClick={(e) => { e.stopPropagation(); void deleteFile(f); }}
                      className="opacity-0 group-hover:opacity-100 text-neutral-500 hover:text-error-400 transition-all"
                      aria-label="Delete file"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </Card>

          {/* Editor / Preview */}
          <Card className="lg:col-span-3 flex flex-col !p-0 overflow-hidden">
            {!activeFile ? (
              <div className="flex-1 flex items-center justify-center">
                <EmptyState
                  icon={<Code2 className="h-8 w-8" />}
                  title="No file selected"
                  description="Select a file from the explorer or create a new one."
                />
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between border-b border-neutral-800 px-4 py-2">
                  <div className="flex items-center gap-2">
                    <FileText className="h-4 w-4 text-secondary-400" />
                    <span className="text-sm font-medium text-white">{activeFile.filename}</span>
                    <Badge variant="neutral">{getLanguageLabel(getFileType(activeFile.filename))}</Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    {canPreview && (
                      <Button size="sm" variant="ghost" leftIcon={<Eye className="h-3.5 w-3.5" />} onClick={() => setPreviewMode(!previewMode)}>
                        {previewMode ? 'Editor' : 'Preview'}
                      </Button>
                    )}
                    <Button size="sm" variant="secondary" loading={saving} leftIcon={!saving ? <Save className="h-3.5 w-3.5" /> : undefined} onClick={saveFile}>
                      Save
                    </Button>
                  </div>
                </div>

                {previewMode && canPreview ? (
                  <iframe
                    srcDoc={fileContent}
                    className="flex-1 w-full bg-white"
                    title="Preview"
                    sandbox="allow-scripts"
                  />
                ) : (
                  <textarea
                    value={fileContent}
                    onChange={(e) => setFileContent(e.target.value)}
                    className="flex-1 w-full bg-blc-navy-900 text-neutral-200 font-mono text-sm p-4 resize-none focus:outline-none border-0"
                    spellCheck={false}
                    placeholder="Start coding..."
                  />
                )}
              </>
            )}
          </Card>
        </div>
      )}

      <Card className="mt-6 border-secondary-500/20">
        <div className="flex items-start gap-3">
          <Code2 className="h-5 w-5 text-secondary-400 shrink-0 mt-0.5" />
          <p className="text-sm text-neutral-300">
            BLC Studio supports web-development file types (HTML, CSS, JS, TS, JSX, TSX, JSON, Markdown).
            HTML files can be previewed in a sandboxed iframe. Files are stored securely with per-user ownership —
            you cannot access other users' project files.
          </p>
        </div>
      </Card>
    </>
  );
}
