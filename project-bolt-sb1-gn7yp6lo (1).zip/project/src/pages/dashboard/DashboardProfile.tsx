import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Save, Upload, Loader2 } from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Card } from '@/components/ui';
import { Button } from '@/components/Button';
import { useAuth } from '@/auth/AuthContext';
import { useToast } from '@/components/Toast';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';

const schema = z.object({
  display_name: z.string().min(1, 'Display name is required').max(60),
  full_name: z.string().max(120).optional().or(z.literal('')),
  bio: z.string().max(500).optional().or(z.literal('')),
});

type FormData = z.infer<typeof schema>;

export default function DashboardProfile() {
  const { profile, user, refreshProfile } = useAuth();
  const toast = useToast();
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  const { register, handleSubmit, reset, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      display_name: profile?.display_name ?? '',
      full_name: profile?.full_name ?? '',
      bio: profile?.bio ?? '',
    },
  });

  useEffect(() => {
    if (profile) {
      reset({
        display_name: profile.display_name ?? '',
        full_name: profile.full_name ?? '',
        bio: profile.bio ?? '',
      });
    }
  }, [profile, reset]);

  async function onSubmit(data: FormData) {
    if (!isSupabaseConfigured || !user) return;
    setSaving(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          display_name: data.display_name,
          full_name: data.full_name || null,
          bio: data.bio || null,
          updated_at: new Date().toISOString(),
        })
        .eq('id', user.id);
      if (error) throw error;
      await refreshProfile();
      toast.push({ title: 'Profile updated', variant: 'success' });
    } catch (err) {
      toast.push({ title: 'Update failed', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    } finally {
      setSaving(false);
    }
  }

  async function handleAvatarUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file || !user || !isSupabaseConfigured) return;
    if (file.size > 2 * 1024 * 1024) {
      toast.push({ title: 'File too large', description: 'Max 2MB.', variant: 'warning' });
      return;
    }
    setUploading(true);
    try {
      const ext = file.name.split('.').pop();
      const path = `${user.id}/avatar.${ext}`;
      const { error: upErr } = await supabase.storage.from('avatars').upload(path, file, { upsert: true });
      if (upErr) throw upErr;
      const { data: pub } = supabase.storage.from('avatars').getPublicUrl(path);
      const { error: pErr } = await supabase.from('profiles').update({ avatar_url: pub.publicUrl, updated_at: new Date().toISOString() }).eq('id', user.id);
      if (pErr) throw pErr;
      await refreshProfile();
      toast.push({ title: 'Avatar updated', variant: 'success' });
    } catch (err) {
      toast.push({ title: 'Upload failed', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    } finally {
      setUploading(false);
    }
  }

  return (
    <>
      <Seo title="Profile" />
      <h1 className="text-2xl font-bold text-white mb-6">Profile settings</h1>

      <div className="grid lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-1">
          <h2 className="font-semibold text-white">Avatar</h2>
          <div className="mt-4 flex flex-col items-center">
            <div className="h-28 w-28 rounded-full bg-gradient-to-br from-secondary-500/20 to-accent-500/20 border border-secondary-500/30 flex items-center justify-center overflow-hidden">
              {profile?.avatar_url ? (
                <img src={profile.avatar_url} alt="Avatar" className="h-full w-full object-cover" />
              ) : (
                <span className="text-3xl font-bold text-secondary-400">
                  {(profile?.display_name ?? profile?.email ?? '?')[0]?.toUpperCase()}
                </span>
              )}
            </div>
            <label className="mt-4 cursor-pointer">
              <input type="file" accept="image/*" className="hidden" onChange={handleAvatarUpload} disabled={uploading} />
              <Button variant="secondary" size="sm" leftIcon={uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />} disabled={uploading}>
                {uploading ? 'Uploading...' : 'Upload'}
              </Button>
            </label>
            <p className="mt-2 text-xs text-neutral-500">Max 2MB. JPG/PNG.</p>
          </div>
        </Card>

        <Card className="lg:col-span-2">
          <h2 className="font-semibold text-white">Details</h2>
          <form onSubmit={handleSubmit(onSubmit)} className="mt-4 space-y-4" noValidate>
            <div>
              <label className="label" htmlFor="display_name">Display name</label>
              <input id="display_name" className="input" {...register('display_name')} />
              {errors.display_name && <p className="mt-1 text-xs text-error-400">{errors.display_name.message}</p>}
            </div>
            <div>
              <label className="label" htmlFor="full_name">Full name</label>
              <input id="full_name" className="input" {...register('full_name')} />
            </div>
            <div>
              <label className="label" htmlFor="bio">Bio</label>
              <textarea id="bio" rows={4} className="input resize-y" {...register('bio')} />
              {errors.bio && <p className="mt-1 text-xs text-error-400">{errors.bio.message}</p>}
            </div>
            <div>
              <label className="label">Email</label>
              <input className="input opacity-60" value={profile?.email ?? user?.email ?? ''} disabled />
              <p className="mt-1 text-xs text-neutral-500">Email cannot be changed here.</p>
            </div>
            <Button type="submit" loading={saving} leftIcon={!saving ? <Save className="h-4 w-4" /> : undefined}>
              Save changes
            </Button>
          </form>
        </Card>
      </div>
    </>
  );
}
