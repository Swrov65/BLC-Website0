import { useEffect, useState } from 'react';
import { LifeBuoy, Plus, Send } from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Card, Badge, EmptyState, Spinner } from '@/components/ui';
import { Button } from '@/components/Button';
import { useAuth } from '@/auth/AuthContext';
import { useToast } from '@/components/Toast';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import type { SupportTicket } from '@/types';

export default function DashboardSupport() {
  const { user } = useAuth();
  const toast = useToast();
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [loading, setLoading] = useState(true);
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [creating, setCreating] = useState(false);

  async function load() {
    if (!isSupabaseConfigured || !user) {
      setLoading(false);
      return;
    }
    try {
      const { data, error } = await supabase
        .from('support_tickets')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      if (error) throw error;
      setTickets((data ?? []) as SupportTicket[]);
    } catch (err) {
      console.warn('Failed to load tickets', err);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, [user]);

  async function createTicket(e: React.FormEvent) {
    e.preventDefault();
    if (!subject.trim() || !message.trim() || !user) return;
    setCreating(true);
    try {
      const { data, error } = await supabase
        .from('support_tickets')
        .insert({ subject: subject.trim(), message: message.trim(), status: 'open' })
        .select('*')
        .single();
      if (error) throw error;
      setTickets((prev) => [data as SupportTicket, ...prev]);
      setSubject('');
      setMessage('');
      toast.push({ title: 'Ticket created', variant: 'success' });
    } catch (err) {
      toast.push({ title: 'Could not create ticket', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    } finally {
      setCreating(false);
    }
  }

  const statusVariant = (s: SupportTicket['status']) =>
    s === 'open' ? 'info' : s === 'in_progress' ? 'warning' : s === 'resolved' ? 'success' : 'neutral';

  return (
    <>
      <Seo title="Support" />
      <h1 className="text-2xl font-bold text-white mb-6">Support</h1>

      <Card className="mb-6">
        <div className="flex items-center gap-3 mb-4">
          <Plus className="h-5 w-5 text-secondary-400" />
          <h2 className="font-semibold text-white">Open a support ticket</h2>
        </div>
        <form onSubmit={createTicket} className="space-y-4">
          <div>
            <label className="label" htmlFor="subj">Subject</label>
            <input id="subj" className="input" value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Brief summary" required />
          </div>
          <div>
            <label className="label" htmlFor="msg">Message</label>
            <textarea id="msg" rows={4} className="input resize-y" value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Describe your issue" required />
          </div>
          <Button type="submit" loading={creating} leftIcon={!creating ? <Send className="h-4 w-4" /> : undefined}>Submit ticket</Button>
        </form>
      </Card>

      <h2 className="font-semibold text-white mb-3">Your tickets</h2>
      {loading ? (
        <div className="flex justify-center py-12"><Spinner className="h-6 w-6" /></div>
      ) : tickets.length === 0 ? (
        <Card>
          <EmptyState
            icon={<LifeBuoy className="h-10 w-10" />}
            title="No support tickets"
            description="You have not opened any tickets yet."
          />
        </Card>
      ) : (
        <div className="space-y-3">
          {tickets.map((t) => (
            <Card key={t.id} className="!py-4">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-white">{t.subject}</h3>
                    <Badge variant={statusVariant(t.status)}>{t.status.replace('_', ' ')}</Badge>
                  </div>
                  <p className="mt-1 text-sm text-neutral-400">{t.message}</p>
                  <p className="mt-2 text-xs text-neutral-500">{new Date(t.created_at).toLocaleString()}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </>
  );
}
