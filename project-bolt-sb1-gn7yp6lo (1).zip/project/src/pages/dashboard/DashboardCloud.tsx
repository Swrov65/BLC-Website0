import { useEffect, useState, useCallback } from 'react';
import {
  Cloud, FolderOpen, HardDrive, Upload, Download, Trash2, FileText, Loader2, AlertCircle,
} from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Card, Badge, EmptyState, Spinner } from '@/components/ui';
import { Button } from '@/components/Button';
import { useAuth } from '@/auth/AuthContext';
import { useToast } from '@/components/Toast';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import type { Project, ProjectFile } from '@/types';
import { cn } from '@/lib/utils';

const MAX_FILE_SIZE = 10 * 1024 * 1024;
const ALLOWED_UPLOAD_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'application/pdf', 'text/plain', 'application/json', 'text/html', 'text/css', 'text/javascript'];

function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

export default function DashboardCloud() {
  const { user } = useAuth();
  const toast = useToast();
  const [projects, setProjects] = useState<Project[]>([]);
  const [activeProject, setActiveProject] = useState<Project | null>(null);
  const [files, setFiles] = useState<ProjectFile[]>([]);
  const [loadingProjects, setLoadingProjects] = useState(true);
  const [loadingFiles, setLoadingFiles] = useState(false);
  const [uploading, setUploading] = useState(false);

  const loadProjects = useCallback(async () => {
    if (!isSupabaseConfigured || !user) {
      setLoadingProjects(false);
      return;
    }
    try {
      const { data, error } = await supabase
        .from('projects')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      if (error) throw error;
      setProjects((data ?? []) as Project[]);
      if (data && data.length > 0) setActiveProject(data[0] as Project);
    } catch (err) {
      console.warn('Failed to load projects', err);
    } finally {
      setLoadingProjects(false);
    }
  }, [user]);

  const loadFiles = useCallback(async (projectId: string) => {
    setLoadingFiles(true);
    try {
      const { data, error } = await supabase
        .from('project_files')
        .select('*')
        .eq('project_id', projectId)
        .order('created_at', { ascending: false });
      if (error) throw error;
      setFiles((data ?? []) as ProjectFile[]);
    } catch (err) {
      console.warn('Failed to load files', err);
    } finally {
      setLoadingFiles(false);
    }
  }, []);

  useEffect(() => {
    void loadProjects();
  }, [loadProjects]);

  useEffect(() => {
    if (activeProject) void loadFiles(activeProject.id);
    else setFiles([]);
  }, [activeProject, loadFiles]);

  async function uploadFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file || !activeProject || !user) return;
    if (file.size > MAX_FILE_SIZE) {
      toast.push({ title: 'File too large', description: 'Maximum file size is 10MB.', variant: 'warning' });
      return;
    }
    if (!ALLOWED_UPLOAD_TYPES.includes(file.type) && !file.type.startsWith('text/')) {
      toast.push({ title: 'File type not allowed', description: 'Allowed: images, PDF, text, JSON, HTML, CSS, JS.', variant: 'warning' });
      return;
    }
    setUploading(true);
    try {
      const content = await file.text();
      const ext = file.name.split('.').pop()?.toLowerCase() ?? 'txt';
      const { data, error } = await supabase
        .from('project_files')
        .insert({
          project_id: activeProject.id,
          user_id: user.id,
          filename: file.name,
          file_path: file.name,
          content,
          file_type: ext,
          size_bytes: file.size,
        })
        .select('*')
        .single();
      if (error) throw error;
      setFiles((prev) => [data as ProjectFile, ...prev]);
      toast.push({ title: 'File uploaded', description: file.name, variant: 'success' });
    } catch (err) {
      toast.push({ title: 'Upload failed', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  }

  function downloadFile(file: ProjectFile) {
    const blob = new Blob([file.content ?? ''], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = file.filename;
    a.click();
    URL.revokeObjectURL(url);
  }

  async function deleteFile(file: ProjectFile) {
    try {
      const { error } = await supabase.from('project_files').delete().eq('id', file.id);
      if (error) throw error;
      setFiles((prev) => prev.filter((f) => f.id !== file.id));
      toast.push({ title: 'File deleted', variant: 'success' });
    } catch (err) {
      toast.push({ title: 'Delete failed', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    }
  }

  const totalSize = files.reduce((sum, f) => sum + f.size_bytes, 0);
  const storageLimit = 100 * 1024 * 1024;
  const storagePercent = Math.min(100, (totalSize / storageLimit) * 100);

  return (
    <>
      <Seo title="BLC Cloud" />
      <h1 className="text-2xl font-bold text-white mb-6">BLC Cloud</h1>

      {!isSupabaseConfigured && (
        <Card className="mb-6 border-warning-500/20">
          <p className="text-sm text-warning-300">Backend not configured. Cloud storage requires Supabase.</p>
        </Card>
      )}

      {loadingProjects ? (
        <div className="flex justify-center py-12"><Spinner className="h-6 w-6" /></div>
      ) : projects.length === 0 ? (
        <Card>
          <EmptyState
            icon={<Cloud className="h-10 w-10" />}
            title="No projects yet"
            description="Create a project from the Projects page to start managing files in BLC Cloud."
          />
        </Card>
      ) : (
        <>
          {/* Storage overview */}
          <Card className="mb-6">
            <div className="flex items-center gap-3 mb-4">
              <HardDrive className="h-5 w-5 text-secondary-400" />
              <h2 className="font-semibold text-white">Storage usage</h2>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-neutral-400">{formatBytes(totalSize)} used</span>
                <span className="text-neutral-500">of {formatBytes(storageLimit)}</span>
              </div>
              <div className="h-2 rounded-full bg-neutral-800 overflow-hidden">
                <div
                  className={cn('h-full transition-all', storagePercent > 80 ? 'bg-error-400' : 'bg-secondary-400')}
                  style={{ width: `${storagePercent}%` }}
                />
              </div>
              <p className="text-xs text-neutral-500">{files.length} files across {projects.length} projects</p>
            </div>
          </Card>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Project selector + upload */}
            <Card className="lg:col-span-1">
              <div className="mb-4">
                <label className="label text-xs mb-1">Project</label>
                <select
                  className="input text-sm"
                  value={activeProject?.id ?? ''}
                  onChange={(e) => {
                    const p = projects.find((pr) => pr.id === e.target.value);
                    setActiveProject(p ?? null);
                  }}
                >
                  {projects.map((p) => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>
              </div>

              {activeProject && (
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Badge variant={activeProject.status === 'active' ? 'success' : activeProject.status === 'paused' ? 'warning' : 'neutral'}>
                      {activeProject.status}
                    </Badge>
                    {activeProject.description && <p className="text-xs text-neutral-500 truncate">{activeProject.description}</p>}
                  </div>

                  <label className="cursor-pointer block">
                    <input type="file" className="hidden" onChange={uploadFile} disabled={uploading} />
                    <Button variant="secondary" size="sm" className="w-full" leftIcon={uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />} disabled={uploading}>
                      {uploading ? 'Uploading...' : 'Upload file'}
                    </Button>
                  </label>
                  <p className="text-xs text-neutral-500">Max 10MB. Images, PDF, text, JSON, HTML, CSS, JS.</p>
                </div>
              )}

              <div className="mt-6 border-t border-neutral-800 pt-4">
                <h3 className="text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-2">Deployment</h3>
                <div className="rounded-lg bg-blc-navy-700/40 p-3">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertCircle className="h-4 w-4 text-warning-400" />
                    <span className="text-sm text-warning-300">Not configured</span>
                  </div>
                  <p className="text-xs text-neutral-500">
                    Deployment requires a hosting provider account (e.g., Netlify, Vercel).
                    Configure deployment credentials in your Supabase Edge Function secrets to enable this feature.
                  </p>
                </div>
              </div>
            </Card>

            {/* File list */}
            <Card className="lg:col-span-2">
              <div className="flex items-center gap-3 mb-4">
                <FolderOpen className="h-5 w-5 text-secondary-400" />
                <h2 className="font-semibold text-white">Files {activeProject && `— ${activeProject.name}`}</h2>
              </div>

              {loadingFiles ? (
                <div className="flex justify-center py-8"><Spinner className="h-5 w-5" /></div>
              ) : files.length === 0 ? (
                <EmptyState
                  icon={<FileText className="h-8 w-8" />}
                  title="No files"
                  description="Upload files to store them in BLC Cloud."
                />
              ) : (
                <div className="space-y-2">
                  {files.map((f) => (
                    <div key={f.id} className="flex items-center justify-between rounded-lg p-3 bg-blc-navy-700/40">
                      <div className="flex items-center gap-2 min-w-0">
                        <FileText className="h-4 w-4 text-secondary-400 shrink-0" />
                        <div className="min-w-0">
                          <p className="text-sm text-white truncate">{f.filename}</p>
                          <p className="text-xs text-neutral-500">{formatBytes(f.size_bytes)} · {new Date(f.updated_at).toLocaleDateString()}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <button onClick={() => downloadFile(f)} className="p-2 text-neutral-400 hover:text-secondary-400 transition-colors" aria-label="Download">
                          <Download className="h-4 w-4" />
                        </button>
                        <button onClick={() => void deleteFile(f)} className="p-2 text-neutral-400 hover:text-error-400 transition-colors" aria-label="Delete">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </div>
        </>
      )}

      <Card className="mt-6 border-secondary-500/20">
        <div className="flex items-start gap-3">
          <Cloud className="h-5 w-5 text-secondary-400 shrink-0 mt-0.5" />
          <p className="text-sm text-neutral-300">
            BLC Cloud provides secure per-user project file storage. Files are protected by Row Level Security —
            you can only access your own project files. Deployment integration requires a hosting provider account
            and is shown as "Not configured" until credentials are added.
          </p>
        </div>
      </Card>
    </>
  );
}
