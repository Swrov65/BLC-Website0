import { useEffect, useState, useCallback } from 'react';
import { Webhook as WebhookIcon, Plus, Trash2, Check, X, Activity } from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Card, Badge, EmptyState, Spinner } from '@/components/ui';
import { Button } from '@/components/Button';
import { useAuth } from '@/auth/AuthContext';
import { useToast } from '@/components/Toast';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import type { Webhook as WebhookType, WebhookDelivery } from '@/types';

const AVAILABLE_EVENTS = [
  'project.created', 'project.updated', 'project.deleted',
  'api_key.created', 'api_key.revoked',
  'contact.submitted',
];

export default function DashboardWebhooks() {
  const { user } = useAuth();
  const toast = useToast();
  const [webhooks, setWebhooks] = useState<WebhookType[]>([]);
  const [deliveries, setDeliveries] = useState<Record<string, WebhookDelivery[]>>({});
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [url, setUrl] = useState('');
  const [description, setDescription] = useState('');
  const [selectedEvents, setSelectedEvents] = useState<string[]>([]);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!isSupabaseConfigured || !user) {
      setLoading(false);
      return;
    }
    try {
      const { data, error } = await supabase
        .from('webhooks')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      if (error) throw error;
      setWebhooks((data ?? []) as WebhookType[]);
    } catch (err) {
      console.warn('Failed to load webhooks', err);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    void load();
  }, [load]);

  async function loadDeliveries(webhookId: string) {
    try {
      const { data, error } = await supabase
        .from('webhook_deliveries')
        .select('*')
        .eq('webhook_id', webhookId)
        .order('created_at', { ascending: false })
        .limit(20);
      if (error) throw error;
      setDeliveries((prev) => ({ ...prev, [webhookId]: (data ?? []) as WebhookDelivery[] }));
    } catch (err) {
      console.warn('Failed to load deliveries', err);
    }
  }

  async function createWebhook(e: React.FormEvent) {
    e.preventDefault();
    if (!url.trim() || !user) return;
    if (!url.startsWith('https://')) {
      toast.push({ title: 'Invalid URL', description: 'Webhook URL must use HTTPS.', variant: 'warning' });
      return;
    }
    setCreating(true);
    try {
      const secretBytes = new Uint8Array(24);
      crypto.getRandomValues(secretBytes);
      const secret = 'whsec_' + Array.from(secretBytes).map((b) => b.toString(16).padStart(2, '0')).join('');
      const { data, error } = await supabase
        .from('webhooks')
        .insert({
          user_id: user.id,
          url: url.trim(),
          description: description.trim() || null,
          events: selectedEvents,
          secret,
          active: true,
        })
        .select('*')
        .single();
      if (error) throw error;
      setWebhooks((prev) => [data as WebhookType, ...prev]);
      setUrl('');
      setDescription('');
      setSelectedEvents([]);
      setShowForm(false);
      toast.push({ title: 'Webhook created', description: 'Save the signing secret — it is shown only once.', variant: 'success' });
    } catch (err) {
      toast.push({ title: 'Could not create webhook', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    } finally {
      setCreating(false);
    }
  }

  async function deleteWebhook(id: string) {
    try {
      const { error } = await supabase.from('webhooks').delete().eq('id', id);
      if (error) throw error;
      setWebhooks((prev) => prev.filter((w) => w.id !== id));
      setConfirmDelete(null);
      toast.push({ title: 'Webhook deleted', variant: 'success' });
    } catch (err) {
      toast.push({ title: 'Delete failed', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    }
  }

  async function toggleActive(webhook: WebhookType) {
    try {
      const { error } = await supabase.from('webhooks').update({ active: !webhook.active }).eq('id', webhook.id);
      if (error) throw error;
      setWebhooks((prev) => prev.map((w) => (w.id === webhook.id ? { ...w, active: !w.active } : w)));
    } catch (err) {
      toast.push({ title: 'Update failed', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    }
  }

  function toggleEvent(event: string) {
    setSelectedEvents((prev) => (prev.includes(event) ? prev.filter((e) => e !== event) : [...prev, event]));
  }

  return (
    <>
      <Seo title="Webhooks" />
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white">Webhooks</h1>
          <p className="mt-1 text-sm text-neutral-400">Receive event notifications at your endpoints.</p>
        </div>
        <Button size="sm" leftIcon={<Plus className="h-4 w-4" />} onClick={() => setShowForm(!showForm)}>New webhook</Button>
      </div>

      {showForm && (
        <Card className="mb-6">
          <form onSubmit={createWebhook} className="space-y-4">
            <div>
              <label className="label" htmlFor="whurl">Endpoint URL (HTTPS)</label>
              <input id="whurl" className="input" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://your-app.com/webhooks/blc" required />
            </div>
            <div>
              <label className="label" htmlFor="whdesc">Description (optional)</label>
              <input id="whdesc" className="input" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="What is this webhook for?" />
            </div>
            <div>
              <label className="label">Events to subscribe</label>
              <div className="grid sm:grid-cols-2 gap-2 mt-2">
                {AVAILABLE_EVENTS.map((event) => (
                  <button
                    key={event}
                    type="button"
                    onClick={() => toggleEvent(event)}
                    className={`flex items-center gap-2 rounded-lg px-3 py-2 text-sm border transition-colors ${
                      selectedEvents.includes(event)
                        ? 'bg-secondary-500/15 text-secondary-300 border-secondary-500/30'
                        : 'text-neutral-400 border-neutral-800 hover:text-white'
                    }`}
                  >
                    {selectedEvents.includes(event) ? <Check className="h-3.5 w-3.5" /> : <X className="h-3.5 w-3.5 opacity-40" />}
                    <code className="text-xs">{event}</code>
                  </button>
                ))}
              </div>
            </div>
            <div className="flex gap-2">
              <Button type="submit" loading={creating}>Create webhook</Button>
              <Button type="button" variant="ghost" onClick={() => setShowForm(false)}>Cancel</Button>
            </div>
          </form>
        </Card>
      )}

      {loading ? (
        <div className="flex justify-center py-12"><Spinner className="h-6 w-6" /></div>
      ) : webhooks.length === 0 ? (
        <Card>
          <EmptyState
            icon={<WebhookIcon className="h-10 w-10" />}
            title="No webhooks"
            description="Create a webhook to receive event notifications at your endpoint."
          />
        </Card>
      ) : (
        <div className="space-y-3">
          {webhooks.map((w) => (
            <Card key={w.id} className="!py-4">
              <div className="flex items-start justify-between gap-4 flex-wrap">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <WebhookIcon className="h-4 w-4 text-secondary-400 shrink-0" />
                    <p className="text-sm font-medium text-white truncate">{w.url}</p>
                    <Badge variant={w.active ? 'success' : 'neutral'}>{w.active ? 'Active' : 'Paused'}</Badge>
                  </div>
                  {w.description && <p className="mt-1 text-xs text-neutral-500">{w.description}</p>}
                  {w.events.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1">
                      {w.events.map((e) => (
                        <code key={e} className="text-xs rounded bg-neutral-800 px-1.5 py-0.5 text-neutral-400">{e}</code>
                      ))}
                    </div>
                  )}
                  <p className="mt-2 text-xs text-neutral-500 font-mono">Secret: {w.secret ? w.secret.slice(0, 12) + '••••' : '—'}</p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <Button size="sm" variant="ghost" onClick={() => toggleActive(w)}>{w.active ? 'Pause' : 'Activate'}</Button>
                  <Button size="sm" variant="ghost" leftIcon={<Activity className="h-3.5 w-3.5" />} onClick={() => {
                    if (expandedId === w.id) { setExpandedId(null); }
                    else { setExpandedId(w.id); void loadDeliveries(w.id); }
                  }}>
                    {expandedId === w.id ? 'Hide' : 'Logs'}
                  </Button>
                  {confirmDelete === w.id ? (
                    <div className="flex items-center gap-1">
                      <Button size="sm" variant="danger" onClick={() => void deleteWebhook(w.id)}>Confirm</Button>
                      <Button size="sm" variant="ghost" onClick={() => setConfirmDelete(null)}>Cancel</Button>
                    </div>
                  ) : (
                    <Button size="sm" variant="ghost" leftIcon={<Trash2 className="h-3.5 w-3.5" />} onClick={() => setConfirmDelete(w.id)}>Delete</Button>
                  )}
                </div>
              </div>

              {expandedId === w.id && (
                <div className="mt-4 border-t border-neutral-800 pt-4">
                  <h4 className="text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-2">Recent deliveries</h4>
                  {(deliveries[w.id] ?? []).length === 0 ? (
                    <p className="text-xs text-neutral-500 py-4 text-center">No deliveries yet.</p>
                  ) : (
                    <div className="space-y-2">
                      {(deliveries[w.id] ?? []).map((d) => (
                        <div key={d.id} className="flex items-center justify-between rounded-lg p-2 bg-blc-navy-700/40 text-xs">
                          <div className="flex items-center gap-2">
                            <Badge variant={d.success ? 'success' : 'error'}>{d.success ? 'OK' : 'Failed'}</Badge>
                            <code className="text-neutral-300">{d.event}</code>
                          </div>
                          <div className="flex items-center gap-3 text-neutral-500">
                            {d.status_code && <span>HTTP {d.status_code}</span>}
                            <span>Attempt {d.attempt}</span>
                            <span>{new Date(d.created_at).toLocaleString()}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </Card>
          ))}
        </div>
      )}

      {!isSupabaseConfigured && (
        <Card className="mt-6 border-warning-500/20">
          <p className="text-sm text-warning-300">Backend not configured. Webhooks require Supabase.</p>
        </Card>
      )}
    </>
  );
}
