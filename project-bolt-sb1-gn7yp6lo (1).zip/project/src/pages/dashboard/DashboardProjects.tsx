import { useEffect, useState } from 'react';
import { Plus, FolderKanban, Trash2, Archive, Pause, Play } from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Card, Badge, EmptyState, Spinner } from '@/components/ui';
import { Button } from '@/components/Button';
import { useAuth } from '@/auth/AuthContext';
import { useToast } from '@/components/Toast';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import type { Project } from '@/types';

export default function DashboardProjects() {
  const { user } = useAuth();
  const toast = useToast();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  async function load() {
    if (!isSupabaseConfigured || !user) {
      setLoading(false);
      return;
    }
    try {
      const { data, error } = await supabase
        .from('projects')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      if (error) throw error;
      setProjects((data ?? []) as Project[]);
    } catch (err) {
      console.warn('Failed to load projects', err);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, [user]);

  async function createProject(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim() || !user) return;
    setCreating(true);
    try {
      const { data, error } = await supabase
        .from('projects')
        .insert({ name: name.trim(), description: description.trim() || null, status: 'active' })
        .select('*')
        .single();
      if (error) throw error;
      setProjects((prev) => [data as Project, ...prev]);
      setName('');
      setDescription('');
      toast.push({ title: 'Project created', variant: 'success' });
    } catch (err) {
      toast.push({ title: 'Could not create project', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    } finally {
      setCreating(false);
    }
  }

  async function updateStatus(id: string, status: Project['status']) {
    try {
      const { error } = await supabase.from('projects').update({ status, updated_at: new Date().toISOString() }).eq('id', id);
      if (error) throw error;
      setProjects((prev) => prev.map((p) => (p.id === id ? { ...p, status } : p)));
      toast.push({ title: 'Project updated', variant: 'success' });
    } catch (err) {
      toast.push({ title: 'Update failed', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    }
  }

  async function deleteProject(id: string) {
    try {
      const { error } = await supabase.from('projects').delete().eq('id', id);
      if (error) throw error;
      setProjects((prev) => prev.filter((p) => p.id !== id));
      setConfirmDelete(null);
      toast.push({ title: 'Project deleted', variant: 'success' });
    } catch (err) {
      toast.push({ title: 'Delete failed', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    }
  }

  return (
    <>
      <Seo title="Projects" />
      <h1 className="text-2xl font-bold text-white mb-6">Projects</h1>

      <Card className="mb-6">
        <h2 className="font-semibold text-white">Create a project</h2>
        <form onSubmit={createProject} className="mt-4 space-y-4">
          <div>
            <label className="label" htmlFor="pname">Project name</label>
            <input id="pname" className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="My new app" required />
          </div>
          <div>
            <label className="label" htmlFor="pdesc">Description (optional)</label>
            <textarea id="pdesc" rows={2} className="input resize-y" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="What is this project about?" />
          </div>
          <Button type="submit" loading={creating} leftIcon={!creating ? <Plus className="h-4 w-4" /> : undefined}>Create project</Button>
        </form>
      </Card>

      {loading ? (
        <div className="flex justify-center py-12"><Spinner className="h-6 w-6" /></div>
      ) : projects.length === 0 ? (
        <Card>
          <EmptyState
            icon={<FolderKanban className="h-10 w-10" />}
            title="No projects yet"
            description="Create your first project to get started."
          />
        </Card>
      ) : (
        <div className="space-y-3">
          {projects.map((p) => (
            <Card key={p.id} className="!py-4">
              <div className="flex items-start justify-between gap-4 flex-wrap">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-3">
                    <h3 className="font-semibold text-white truncate">{p.name}</h3>
                    <Badge variant={p.status === 'active' ? 'success' : p.status === 'paused' ? 'warning' : 'neutral'}>{p.status}</Badge>
                  </div>
                  {p.description && <p className="mt-1 text-sm text-neutral-400">{p.description}</p>}
                  <p className="mt-2 text-xs text-neutral-500">Created {new Date(p.created_at).toLocaleDateString()}</p>
                </div>
                <div className="flex items-center gap-2">
                  {p.status !== 'active' && (
                    <Button size="sm" variant="ghost" leftIcon={<Play className="h-3.5 w-3.5" />} onClick={() => updateStatus(p.id, 'active')}>Activate</Button>
                  )}
                  {p.status !== 'paused' && (
                    <Button size="sm" variant="ghost" leftIcon={<Pause className="h-3.5 w-3.5" />} onClick={() => updateStatus(p.id, 'paused')}>Pause</Button>
                  )}
                  {p.status !== 'archived' && (
                    <Button size="sm" variant="ghost" leftIcon={<Archive className="h-3.5 w-3.5" />} onClick={() => updateStatus(p.id, 'archived')}>Archive</Button>
                  )}
                  {confirmDelete === p.id ? (
                    <div className="flex items-center gap-2">
                      <Button size="sm" variant="danger" onClick={() => void deleteProject(p.id)}>Confirm</Button>
                      <Button size="sm" variant="ghost" onClick={() => setConfirmDelete(null)}>Cancel</Button>
                    </div>
                  ) : (
                    <Button size="sm" variant="ghost" leftIcon={<Trash2 className="h-3.5 w-3.5" />} onClick={() => setConfirmDelete(p.id)}>Delete</Button>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {!isSupabaseConfigured && (
        <Card className="mt-6 border-warning-500/20">
          <p className="text-sm text-warning-300">Backend not configured. Projects require Supabase to persist.</p>
        </Card>
      )}
    </>
  );
}
