import { useEffect, useState } from 'react';
import { Bell, Check, Trash2 } from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Card, Badge, EmptyState, Spinner } from '@/components/ui';
import { Button } from '@/components/Button';
import { useAuth } from '@/auth/AuthContext';
import { useToast } from '@/components/Toast';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import type { Notification } from '@/types';

export default function DashboardNotifications() {
  const { user } = useAuth();
  const toast = useToast();
  const [items, setItems] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    if (!isSupabaseConfigured || !user) {
      setLoading(false);
      return;
    }
    try {
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50);
      if (error) throw error;
      setItems((data ?? []) as Notification[]);
    } catch (err) {
      console.warn('Failed to load notifications', err);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, [user]);

  async function markRead(id: string) {
    try {
      const { error } = await supabase.from('notifications').update({ read: true }).eq('id', id);
      if (error) throw error;
      setItems((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
    } catch (err) {
      toast.push({ title: 'Update failed', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    }
  }

  async function markAllRead() {
    if (!user) return;
    try {
      const { error } = await supabase.from('notifications').update({ read: true }).eq('user_id', user.id).eq('read', false);
      if (error) throw error;
      setItems((prev) => prev.map((n) => ({ ...n, read: true })));
      toast.push({ title: 'All marked as read', variant: 'success' });
    } catch (err) {
      toast.push({ title: 'Update failed', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    }
  }

  async function removeNotification(id: string) {
    try {
      const { error } = await supabase.from('notifications').delete().eq('id', id);
      if (error) throw error;
      setItems((prev) => prev.filter((n) => n.id !== id));
    } catch (err) {
      toast.push({ title: 'Delete failed', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    }
  }

  const unread = items.filter((n) => !n.read).length;

  return (
    <>
      <Seo title="Notifications" />
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white">Notifications</h1>
          <p className="mt-1 text-sm text-neutral-400">{unread} unread</p>
        </div>
        {unread > 0 && (
          <Button size="sm" variant="secondary" leftIcon={<Check className="h-4 w-4" />} onClick={markAllRead}>Mark all read</Button>
        )}
      </div>

      {loading ? (
        <div className="flex justify-center py-12"><Spinner className="h-6 w-6" /></div>
      ) : items.length === 0 ? (
        <Card>
          <EmptyState
            icon={<Bell className="h-10 w-10" />}
            title="No notifications"
            description="You are all caught up."
          />
        </Card>
      ) : (
        <div className="space-y-3">
          {items.map((n) => (
            <Card key={n.id} className={`!py-4 ${!n.read ? 'border-secondary-500/30' : ''}`}>
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-start gap-3 min-w-0 flex-1">
                  {!n.read && <span className="mt-2 h-2 w-2 rounded-full bg-secondary-400 shrink-0" />}
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-white">{n.title}</h3>
                      {!n.read && <Badge variant="info">New</Badge>}
                    </div>
                    <p className="mt-1 text-sm text-neutral-400">{n.body}</p>
                    <p className="mt-2 text-xs text-neutral-500">{new Date(n.created_at).toLocaleString()}</p>
                  </div>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  {!n.read && (
                    <button onClick={() => markRead(n.id)} className="p-2 text-neutral-400 hover:text-success-400 transition-colors" aria-label="Mark read">
                      <Check className="h-4 w-4" />
                    </button>
                  )}
                  <button onClick={() => removeNotification(n.id)} className="p-2 text-neutral-400 hover:text-error-400 transition-colors" aria-label="Delete">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </>
  );
}
