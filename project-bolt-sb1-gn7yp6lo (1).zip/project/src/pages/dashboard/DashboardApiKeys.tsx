import { useEffect, useState } from 'react';
import { KeyRound, Plus, Copy, Trash2, Check, AlertTriangle, Activity } from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Card, Badge, EmptyState, Spinner } from '@/components/ui';
import { Button } from '@/components/Button';
import { useAuth } from '@/auth/AuthContext';
import { useToast } from '@/components/Toast';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import type { ApiApp } from '@/types';

const API_KEY_PREFIX = 'blc_';

async function generateSecureApiKey(): Promise<{ full: string; display: string; hash: string }> {
  const randomBytes = new Uint8Array(32);
  crypto.getRandomValues(randomBytes);
  const hex = Array.from(randomBytes).map((b) => b.toString(16).padStart(2, '0')).join('');
  const full = API_KEY_PREFIX + hex;
  const display = API_KEY_PREFIX + hex.slice(0, 8) + '••••';
  const hashBuffer = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(full));
  const hash = Array.from(new Uint8Array(hashBuffer)).map((b) => b.toString(16).padStart(2, '0')).join('');
  return { full, display, hash };
}

export default function DashboardApiKeys() {
  const { user } = useAuth();
  const toast = useToast();
  const [keys, setKeys] = useState<ApiApp[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [appName, setAppName] = useState('');
  const [newKey, setNewKey] = useState<string | null>(null);
  const [confirmRevoke, setConfirmRevoke] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  async function load() {
    if (!isSupabaseConfigured || !user) {
      setLoading(false);
      return;
    }
    try {
      const { data, error } = await supabase
        .from('api_apps')
        .select('id, user_id, name, key_prefix, key_hash, last_used_at, revoked, created_at')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      if (error) throw error;
      setKeys((data ?? []) as ApiApp[]);
    } catch (err) {
      console.warn('Failed to load API keys', err);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, [user]);

  async function createKey(e: React.FormEvent) {
    e.preventDefault();
    if (!appName.trim() || !user) return;
    setCreating(true);
    try {
      const { full, display, hash } = await generateSecureApiKey();
      const { data, error } = await supabase
        .from('api_apps')
        .insert({ name: appName.trim(), key_prefix: display, key_hash: hash, revoked: false })
        .select('id, user_id, name, key_prefix, key_hash, last_used_at, revoked, created_at')
        .single();
      if (error) throw error;
      setKeys((prev) => [data as ApiApp, ...prev]);
      setNewKey(full);
      setAppName('');
      toast.push({ title: 'API key created', description: 'Copy it now — it will not be shown again.', variant: 'success' });
    } catch (err) {
      toast.push({ title: 'Could not create key', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    } finally {
      setCreating(false);
    }
  }

  async function revokeKey(id: string) {
    try {
      const { error } = await supabase.from('api_apps').update({ revoked: true }).eq('id', id);
      if (error) throw error;
      setKeys((prev) => prev.map((k) => (k.id === id ? { ...k, revoked: true } : k)));
      setConfirmRevoke(null);
      toast.push({ title: 'Key revoked', variant: 'success' });
    } catch (err) {
      toast.push({ title: 'Revoke failed', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    }
  }

  function copyKey() {
    if (!newKey) return;
    navigator.clipboard.writeText(newKey);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <>
      <Seo title="API Keys" />
      <h1 className="text-2xl font-bold text-white mb-6">API Keys</h1>

      {newKey && (
        <Card className="mb-6 border-success-500/30">
          <div className="flex items-start gap-3">
            <AlertTriangle className="h-5 w-5 text-warning-400 shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-white">Your new API key</h3>
              <p className="mt-1 text-sm text-neutral-400">Copy this key now. For security, it will not be shown again. Only a SHA-256 hash is stored.</p>
              <div className="mt-3 flex items-center gap-2">
                <code className="flex-1 rounded-lg bg-blc-navy-900 border border-neutral-800 px-3 py-2 text-xs text-secondary-300 font-mono break-all">{newKey}</code>
                <Button size="sm" variant="secondary" leftIcon={copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />} onClick={copyKey}>
                  {copied ? 'Copied' : 'Copy'}
                </Button>
              </div>
              <Button size="sm" variant="ghost" className="mt-3" onClick={() => setNewKey(null)}>Dismiss</Button>
            </div>
          </div>
        </Card>
      )}

      <Card className="mb-6">
        <div className="flex items-center gap-3 mb-4">
          <Plus className="h-5 w-5 text-secondary-400" />
          <h2 className="font-semibold text-white">Create an API key</h2>
        </div>
        <form onSubmit={createKey} className="space-y-4">
          <div>
            <label className="label" htmlFor="appname">Application name</label>
            <input id="appname" className="input" value={appName} onChange={(e) => setAppName(e.target.value)} placeholder="My Application" required />
          </div>
          <Button type="submit" loading={creating} leftIcon={!creating ? <KeyRound className="h-4 w-4" /> : undefined}>Generate key</Button>
        </form>
      </Card>

      <div className="flex items-center justify-between mb-3">
        <h2 className="font-semibold text-white">Your keys</h2>
        {keys.length > 0 && <Badge variant="neutral">{keys.length} total</Badge>}
      </div>
      {loading ? (
        <div className="flex justify-center py-12"><Spinner className="h-6 w-6" /></div>
      ) : keys.length === 0 ? (
        <Card>
          <EmptyState
            icon={<KeyRound className="h-10 w-10" />}
            title="No API keys"
            description="Create your first API key to start using the developer platform."
          />
        </Card>
      ) : (
        <div className="space-y-3">
          {keys.map((k) => (
            <Card key={k.id} className="!py-4">
              <div className="flex items-center justify-between gap-4 flex-wrap">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-white">{k.name}</h3>
                    <Badge variant={k.revoked ? 'error' : 'success'}>{k.revoked ? 'Revoked' : 'Active'}</Badge>
                  </div>
                  <p className="mt-1 text-xs text-neutral-500 font-mono">{k.key_prefix}</p>
                  <div className="flex items-center gap-3 mt-1">
                    <p className="text-xs text-neutral-500">Created {new Date(k.created_at).toLocaleDateString()}</p>
                    {k.last_used_at && (
                      <p className="text-xs text-neutral-500 flex items-center gap-1">
                        <Activity className="h-3 w-3" /> Last used {new Date(k.last_used_at).toLocaleDateString()}
                      </p>
                    )}
                  </div>
                </div>
                {!k.revoked && (
                  confirmRevoke === k.id ? (
                    <div className="flex items-center gap-2">
                      <Button size="sm" variant="danger" onClick={() => void revokeKey(k.id)}>Confirm revoke</Button>
                      <Button size="sm" variant="ghost" onClick={() => setConfirmRevoke(null)}>Cancel</Button>
                    </div>
                  ) : (
                    <Button size="sm" variant="ghost" leftIcon={<Trash2 className="h-3.5 w-3.5" />} onClick={() => setConfirmRevoke(k.id)}>Revoke</Button>
                  )
                )}
              </div>
            </Card>
          ))}
        </div>
      )}

      <Card className="mt-6 border-secondary-500/20">
        <div className="flex items-start gap-3">
          <KeyRound className="h-5 w-5 text-secondary-400 shrink-0 mt-0.5" />
          <div className="text-sm text-neutral-300">
            <p className="font-medium text-white">Security notes</p>
            <ul className="mt-2 space-y-1 text-neutral-400 text-xs">
              <li>Keys are generated using cryptographically secure randomness (256-bit)</li>
              <li>Only a SHA-256 hash and a non-sensitive prefix are stored</li>
              <li>Full key secrets are shown once at creation — store them securely</li>
              <li>Revoked keys cannot be restored</li>
            </ul>
          </div>
        </div>
      </Card>

      {!isSupabaseConfigured && (
        <Card className="mt-6 border-warning-500/20">
          <p className="text-sm text-warning-300">Backend not configured. API keys require Supabase to persist.</p>
        </Card>
      )}
    </>
  );
}
