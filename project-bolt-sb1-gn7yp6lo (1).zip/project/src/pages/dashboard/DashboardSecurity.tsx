import { useState } from 'react';
import { ShieldCheck, KeyRound, LogOut, Monitor } from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Card, Badge } from '@/components/ui';
import { Button } from '@/components/Button';
import { useAuth } from '@/auth/AuthContext';
import { useToast } from '@/components/Toast';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { useNavigate } from 'react-router-dom';

export default function DashboardSecurity() {
  const { user, profile, isAdmin, signOut } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [signingOut, setSigningOut] = useState(false);

  async function handleSignOutAll() {
    setSigningOut(true);
    try {
      if (isSupabaseConfigured) {
        await supabase.auth.signOut({ scope: 'global' });
      }
      await signOut();
      toast.push({ title: 'Signed out everywhere', variant: 'success' });
      navigate('/');
    } catch (err) {
      toast.push({ title: 'Sign out failed', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    } finally {
      setSigningOut(false);
    }
  }

  return (
    <>
      <Seo title="Security" />
      <h1 className="text-2xl font-bold text-white mb-6">Security settings</h1>

      <div className="space-y-6 max-w-2xl">
        <Card>
          <div className="flex items-center gap-3 mb-4">
            <ShieldCheck className="h-5 w-5 text-secondary-400" />
            <h2 className="font-semibold text-white">Account security</h2>
          </div>
          <dl className="space-y-3 text-sm">
            <div className="flex justify-between"><dt className="text-neutral-400">Account ID</dt><dd className="text-neutral-200 font-mono text-xs">{user?.id ?? '—'}</dd></div>
            <div className="flex justify-between"><dt className="text-neutral-400">Email</dt><dd className="text-neutral-200">{profile?.email ?? user?.email}</dd></div>
            <div className="flex justify-between"><dt className="text-neutral-400">Role</dt><dd><Badge variant={isAdmin ? 'accent' : 'neutral'}>{isAdmin ? 'admin' : 'user'}</Badge></dd></div>
            <div className="flex justify-between"><dt className="text-neutral-400">Status</dt><dd><Badge variant={profile?.suspended ? 'error' : 'success'}>{profile?.suspended ? 'Suspended' : 'Active'}</Badge></dd></div>
          </dl>
        </Card>

        <Card>
          <div className="flex items-center gap-3 mb-4">
            <KeyRound className="h-5 w-5 text-secondary-400" />
            <h2 className="font-semibold text-white">Password</h2>
          </div>
          <p className="text-sm text-neutral-400">
            Passwords are managed securely by our authentication provider. To reset your password, use the password reset flow.
          </p>
          <a href="/reset-password" className="inline-block mt-4">
            <Button variant="secondary" size="sm">Reset password</Button>
          </a>
        </Card>

        <Card>
          <div className="flex items-center gap-3 mb-4">
            <Monitor className="h-5 w-5 text-secondary-400" />
            <h2 className="font-semibold text-white">Active sessions</h2>
          </div>
          <p className="text-sm text-neutral-400">
            Sign out of all sessions across every device. This will end your current session too.
          </p>
          <Button variant="danger" size="sm" className="mt-4" loading={signingOut} leftIcon={!signingOut ? <LogOut className="h-4 w-4" /> : undefined} onClick={handleSignOutAll}>
            Sign out everywhere
          </Button>
        </Card>

        {!isSupabaseConfigured && (
          <Card className="border-warning-500/20">
            <p className="text-sm text-warning-300">Backend not configured. Security features require Supabase.</p>
          </Card>
        )}
      </div>
    </>
  );
}
