import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  User, FolderKanban, Bell, KeyRound, LifeBuoy, ArrowRight, ShieldCheck, Activity,
  HardDrive, BrainCircuit, Server, FileCode, Cpu,
} from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Card, Badge, EmptyState, Spinner } from '@/components/ui';
import { Button } from '@/components/Button';
import { useAuth } from '@/auth/AuthContext';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { cn } from '@/lib/utils';

type RecentProject = { id: string; name: string; status: string; updated_at: string };
type RecentActivity = { id: string; title: string; body: string; created_at: string; read: boolean };

export default function DashboardHome() {
  const { profile, user, isAdmin } = useAuth();
  const [stats, setStats] = useState({ projects: 0, notifications: 0, apiKeys: 0, tickets: 0, aiRequests: 0, storageBytes: 0, files: 0 });
  const [recentProjects, setRecentProjects] = useState<RecentProject[]>([]);
  const [recentActivity, setRecentActivity] = useState<RecentActivity[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isSupabaseConfigured || !user) {
      setLoading(false);
      return;
    }
    (async () => {
      try {
        const [p, n, a, t, ai, files, recentP, recentN] = await Promise.all([
          supabase.from('projects').select('id', { count: 'exact', head: true }).eq('user_id', user.id),
          supabase.from('notifications').select('id', { count: 'exact', head: true }).eq('user_id', user.id).eq('read', false),
          supabase.from('api_apps').select('id', { count: 'exact', head: true }).eq('user_id', user.id).eq('revoked', false),
          supabase.from('support_tickets').select('id', { count: 'exact', head: true }).eq('user_id', user.id),
          supabase.from('ai_usage_tracking').select('request_count').eq('user_id', user.id),
          supabase.from('project_files').select('size_bytes').eq('user_id', user.id),
          supabase.from('projects').select('id, name, status, updated_at').eq('user_id', user.id).order('updated_at', { ascending: false }).limit(5),
          supabase.from('notifications').select('id, title, body, created_at, read').eq('user_id', user.id).order('created_at', { ascending: false }).limit(5),
        ]);

        const aiTotal = (ai.data as { request_count: number }[] | null)?.reduce((sum, r) => sum + (r.request_count ?? 0), 0) ?? 0;
        const storageTotal = (files.data as { size_bytes: number }[] | null)?.reduce((sum, f) => sum + (f.size_bytes ?? 0), 0) ?? 0;

        setStats({
          projects: p.count ?? 0,
          notifications: n.count ?? 0,
          apiKeys: a.count ?? 0,
          tickets: t.count ?? 0,
          aiRequests: aiTotal,
          storageBytes: storageTotal,
          files: files.data?.length ?? 0,
        });
        setRecentProjects((recentP.data as RecentProject[] | null) ?? []);
        setRecentActivity((recentN.data as RecentActivity[] | null) ?? []);
      } catch (err) {
        console.warn('Failed to load stats', err);
      } finally {
        setLoading(false);
      }
    })();
  }, [user]);

  const services = [
    { name: 'Authentication', status: 'operational' },
    { name: 'Database', status: 'operational' },
    { name: 'AI Lab', status: 'degraded' },
    { name: 'BLC Studio', status: 'operational' },
    { name: 'BLC Cloud', status: 'operational' },
    { name: 'API Gateway', status: 'operational' },
  ];

  return (
    <>
      <Seo title="Dashboard" />
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white">
          Welcome back, {profile?.display_name ?? profile?.email ?? 'developer'}
        </h1>
        <p className="mt-1 text-sm text-neutral-400">Here is an overview of your BLC account and platform activity.</p>
      </div>

      {profile?.suspended && (
        <Card className="mb-6 border-error-500/30">
          <div className="flex items-center gap-3">
            <ShieldCheck className="h-5 w-5 text-error-400" />
            <p className="text-sm text-error-300">Your account is suspended. Some features may be unavailable.</p>
          </div>
        </Card>
      )}

      {/* Stat tiles */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatTile icon={FolderKanban} label="My Projects" value={stats.projects} to="/dashboard/projects" loading={loading} />
        <StatTile icon={BrainCircuit} label="AI Usage (requests)" value={stats.aiRequests} to="/ai-lab" loading={loading} />
        <StatTile icon={KeyRound} label="Active API Keys" value={stats.apiKeys} to="/dashboard/api-keys" loading={loading} />
        <StatTile icon={Bell} label="Unread Notifications" value={stats.notifications} to="/dashboard/notifications" loading={loading} />
      </div>

      <div className="grid lg:grid-cols-3 gap-6 mt-6">
        {/* Recent Projects */}
        <Card className="lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <FolderKanban className="h-5 w-5 text-secondary-400" />
              <h2 className="font-semibold text-white">Recent Projects</h2>
            </div>
            <Link to="/dashboard/projects" className="text-xs text-secondary-400 hover:text-secondary-300">View all</Link>
          </div>
          {loading ? (
            <div className="flex justify-center py-8"><Spinner className="h-5 w-5" /></div>
          ) : recentProjects.length === 0 ? (
            <EmptyState
              icon={<FolderKanban className="h-8 w-8" />}
              title="No projects yet"
              description="Create your first project in BLC Studio to get started."
              action={<Link to="/dashboard/studio"><Button size="sm" rightIcon={<ArrowRight className="h-4 w-4" />}>Open BLC Studio</Button></Link>}
            />
          ) : (
            <div className="space-y-2">
              {recentProjects.map((p) => (
                <Link key={p.id} to="/dashboard/projects" className="flex items-center gap-3 rounded-lg p-3 hover:bg-neutral-800/50 transition-colors">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-secondary-500/10 border border-secondary-500/20">
                    <FileCode className="h-4 w-4 text-secondary-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white truncate">{p.name}</p>
                    <p className="text-xs text-neutral-500">Updated {new Date(p.updated_at).toLocaleDateString()}</p>
                  </div>
                  <Badge variant={p.status === 'active' ? 'success' : 'neutral'}>{p.status}</Badge>
                </Link>
              ))}
            </div>
          )}
        </Card>

        {/* Service Status */}
        <Card>
          <div className="flex items-center gap-3 mb-4">
            <Server className="h-5 w-5 text-secondary-400" />
            <h2 className="font-semibold text-white">Service Status</h2>
          </div>
          <div className="space-y-2.5">
            {services.map((s) => (
              <div key={s.name} className="flex items-center justify-between">
                <span className="text-sm text-neutral-300">{s.name}</span>
                <span className="flex items-center gap-1.5">
                  <span className={cnDot(s.status === 'operational' ? 'bg-success-400' : s.status === 'degraded' ? 'bg-warning-400' : 'bg-error-400')} />
                  <span className={cn('text-xs', s.status === 'operational' ? 'text-success-400' : s.status === 'degraded' ? 'text-warning-400' : 'text-error-400')}>
                    {s.status === 'operational' ? 'Operational' : s.status === 'degraded' ? 'Degraded' : 'Down'}
                  </span>
                </span>
              </div>
            ))}
          </div>
          <Link to="/status" className="mt-4 inline-flex items-center gap-1 text-xs text-secondary-400 hover:text-secondary-300">
            View status page <ArrowRight className="h-3 w-3" />
          </Link>
        </Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-6 mt-6">
        {/* Recent Activity */}
        <Card className="lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <Activity className="h-5 w-5 text-secondary-400" />
              <h2 className="font-semibold text-white">Recent Activity</h2>
            </div>
            <Link to="/dashboard/notifications" className="text-xs text-secondary-400 hover:text-secondary-300">View all</Link>
          </div>
          {loading ? (
            <div className="flex justify-center py-8"><Spinner className="h-5 w-5" /></div>
          ) : recentActivity.length === 0 ? (
            <EmptyState
              icon={<Bell className="h-8 w-8" />}
              title="No recent activity"
              description="Notifications and account activity will appear here."
            />
          ) : (
            <div className="space-y-2">
              {recentActivity.map((a) => (
                <div key={a.id} className="flex items-start gap-3 rounded-lg p-3 hover:bg-neutral-800/50 transition-colors">
                  <div className={cn('mt-1.5 h-2 w-2 rounded-full shrink-0', a.read ? 'bg-neutral-600' : 'bg-secondary-400')} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white truncate">{a.title}</p>
                    <p className="text-xs text-neutral-500 line-clamp-2">{a.body}</p>
                    <p className="text-[10px] text-neutral-600 mt-0.5">{timeAgo(a.created_at)}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        {/* Storage Usage */}
        <Card>
          <div className="flex items-center gap-3 mb-4">
            <HardDrive className="h-5 w-5 text-secondary-400" />
            <h2 className="font-semibold text-white">Storage Usage</h2>
          </div>
          {loading ? (
            <div className="flex justify-center py-8"><Spinner className="h-5 w-5" /></div>
          ) : (
            <>
              <div className="flex items-end justify-between mb-2">
                <span className="text-2xl font-bold text-white">{formatBytes(stats.storageBytes)}</span>
                <span className="text-xs text-neutral-500">of 500 MB</span>
              </div>
              <div className="h-2 rounded-full bg-neutral-800 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-secondary-500 to-accent-500 transition-all"
                  style={{ width: `${Math.min(100, (stats.storageBytes / (500 * 1024 * 1024)) * 100)}%` }}
                />
              </div>
              <dl className="mt-4 space-y-2 text-sm">
                <div className="flex justify-between"><dt className="text-neutral-400">Files</dt><dd className="text-neutral-200">{stats.files}</dd></div>
                <div className="flex justify-between"><dt className="text-neutral-400">Plan</dt><dd className="text-neutral-200">Free</dd></div>
              </dl>
              <Link to="/dashboard/cloud" className="mt-4 inline-flex items-center gap-1 text-xs text-secondary-400 hover:text-secondary-300">
                Manage storage <ArrowRight className="h-3 w-3" />
              </Link>
            </>
          )}
        </Card>
      </div>

      {/* Account status + quick actions */}
      <div className="grid lg:grid-cols-3 gap-6 mt-6">
        <Card className="lg:col-span-2">
          <div className="flex items-center gap-3 mb-4">
            <User className="h-5 w-5 text-secondary-400" />
            <h2 className="font-semibold text-white">Account Status</h2>
          </div>
          <dl className="grid sm:grid-cols-2 gap-x-6 gap-y-3 text-sm">
            <div className="flex justify-between"><dt className="text-neutral-400">Email</dt><dd className="text-neutral-200 truncate ml-2">{profile?.email ?? user?.email}</dd></div>
            <div className="flex justify-between"><dt className="text-neutral-400">Display name</dt><dd className="text-neutral-200">{profile?.display_name ?? 'Not set'}</dd></div>
            <div className="flex justify-between"><dt className="text-neutral-400">Role</dt><dd><Badge variant={isAdmin ? 'accent' : 'neutral'}>{isAdmin ? 'admin' : 'user'}</Badge></dd></div>
            <div className="flex justify-between"><dt className="text-neutral-400">Status</dt><dd><Badge variant={profile?.suspended ? 'error' : 'success'}>{profile?.suspended ? 'Suspended' : 'Active'}</Badge></dd></div>
            <div className="flex justify-between"><dt className="text-neutral-400">Joined</dt><dd className="text-neutral-200">{profile?.created_at ? new Date(profile.created_at).toLocaleDateString() : '—'}</dd></div>
            <div className="flex justify-between"><dt className="text-neutral-400">Support tickets</dt><dd className="text-neutral-200">{stats.tickets}</dd></div>
          </dl>
          <Link to="/dashboard/profile" className="inline-block mt-6">
            <Button variant="secondary" size="sm" rightIcon={<ArrowRight className="h-4 w-4" />}>Edit profile</Button>
          </Link>
        </Card>

        <Card>
          <div className="flex items-center gap-3 mb-4">
            <Cpu className="h-5 w-5 text-secondary-400" />
            <h2 className="font-semibold text-white">Quick Actions</h2>
          </div>
          <div className="space-y-2">
            <QuickAction to="/dashboard/projects" icon={FolderKanban} label="Manage projects" />
            <QuickAction to="/dashboard/api-keys" icon={KeyRound} label="Create API key" />
            <QuickAction to="/dashboard/support" icon={LifeBuoy} label="Open support ticket" />
            <QuickAction to="/ai-lab" icon={BrainCircuit} label="Open AI Lab" />
            <QuickAction to="/dashboard/studio" icon={FileCode} label="Open BLC Studio" />
          </div>
        </Card>
      </div>

      {!isSupabaseConfigured && (
        <Card className="mt-6 border-warning-500/20">
          <EmptyState
            title="Backend not configured"
            description="Some dashboard data requires Supabase. Configure it to see live stats."
          />
        </Card>
      )}
    </>
  );
}

function StatTile({ icon: Icon, label, value, to, loading }: { icon: typeof User; label: string; value: number; to: string; loading: boolean }) {
  return (
    <Link to={to}>
      <div className="stat-tile">
        <div className="flex items-center justify-between">
          <Icon className="h-5 w-5 text-secondary-400" />
          {loading ? <Spinner className="h-4 w-4" /> : <span className="text-2xl font-bold text-white">{value}</span>}
        </div>
        <p className="mt-3 text-sm text-neutral-400">{label}</p>
      </div>
    </Link>
  );
}

function QuickAction({ to, icon: Icon, label }: { to: string; icon: typeof User; label: string }) {
  return (
    <Link to={to} className="flex items-center gap-3 rounded-lg p-3 text-sm text-neutral-300 hover:bg-neutral-800/50 hover:text-white transition-colors">
      <Icon className="h-4 w-4 text-secondary-400" />
      <span className="flex-1">{label}</span>
      <ArrowRight className="h-3.5 w-3.5 text-neutral-600" />
    </Link>
  );
}

function cnDot(colorClass: string) {
  return `h-2 w-2 rounded-full ${colorClass}`;
}

function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

function timeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}d ago`;
  return new Date(dateStr).toLocaleDateString();
}
