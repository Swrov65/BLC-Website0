import { useEffect, useRef, useState, useCallback } from 'react';
import { Link } from 'react-router-dom';
import {
  BrainCircuit, Send, Plus, Copy, Trash2, Loader2, AlertCircle, MessageSquare, Settings, X,
  PenLine, Code2, Search, GraduationCap, Zap, Image, Clapperboard, ChevronDown,
} from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Card, EmptyState, Badge } from '@/components/ui';
import { Button } from '@/components/Button';
import { useAuth } from '@/auth/AuthContext';
import { useToast } from '@/components/Toast';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { cn } from '@/lib/utils';

type Msg = { id: string; role: 'user' | 'assistant'; content: string; created_at: string };
type Conv = { id: string; title: string; updated_at: string };

type ToolType = 'chat' | 'writing' | 'code' | 'research' | 'learning' | 'productivity' | 'image_prompt' | 'av_planning';

const tools: { type: ToolType; label: string; icon: typeof BrainCircuit; desc: string; placeholder: string }[] = [
  { type: 'chat', label: 'Chat', icon: MessageSquare, desc: 'General AI assistant', placeholder: 'Ask anything...' },
  { type: 'writing', label: 'Writing', icon: PenLine, desc: 'Improve your writing', placeholder: 'Paste text to improve, or ask for help writing...' },
  { type: 'code', label: 'Code', icon: Code2, desc: 'Write and debug code', placeholder: 'Describe what you want to build, or paste code to debug...' },
  { type: 'research', label: 'Research', icon: Search, desc: 'Find and synthesize info', placeholder: 'What topic do you want to explore?' },
  { type: 'learning', label: 'Learning', icon: GraduationCap, desc: 'Learn new topics', placeholder: 'What do you want to learn?' },
  { type: 'productivity', label: 'Productivity', icon: Zap, desc: 'Plan and organize', placeholder: 'What do you need help organizing?' },
  { type: 'image_prompt', label: 'Image Prompts', icon: Image, desc: 'Generate image prompts', placeholder: 'Describe the image you want to create...' },
  { type: 'av_planning', label: 'AV Planning', icon: Clapperboard, desc: 'Plan audio/video content', placeholder: 'What content are you planning?' },
];

export default function AiLab() {
  const { session } = useAuth();
  const toast = useToast();
  const [activeTool, setActiveTool] = useState<ToolType>('chat');
  const [conversations, setConversations] = useState<Conv[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [loadingConvs, setLoadingConvs] = useState(false);
  const [providerStatus, setProviderStatus] = useState<'unknown' | 'configured' | 'not_configured'>('unknown');
  const [providerInfo, setProviderInfo] = useState<{ model?: string; daily_limit?: number }>({});
  const [usage, setUsage] = useState<{ used: number; limit: number } | null>(null);
  const [showMobileConvList, setShowMobileConvList] = useState(false);
  const [showToolMenu, setShowToolMenu] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const requiresAuth = !session;
  const backendReady = isSupabaseConfigured && Boolean(session);

  const activeToolDef = tools.find((t) => t.type === activeTool) ?? tools[0];

  const checkProvider = useCallback(async () => {
    try {
      const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-chat/status`;
      const res = await fetch(url, {
        headers: { Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}` },
      });
      if (res.ok) {
        const data = await res.json();
        setProviderStatus(data.configured ? 'configured' : 'not_configured');
        setProviderInfo({ model: data.model, daily_limit: data.daily_limit });
      } else {
        setProviderStatus('not_configured');
      }
    } catch {
      setProviderStatus('unknown');
    }
  }, []);

  const loadConversations = useCallback(async () => {
    setLoadingConvs(true);
    try {
      const { data, error } = await supabase
        .from('ai_conversations')
        .select('id, title, updated_at')
        .order('updated_at', { ascending: false })
        .limit(50);
      if (error) throw error;
      setConversations((data ?? []) as Conv[]);
      if (data && data.length > 0 && !activeId) setActiveId(data[0].id);
    } catch (err) {
      console.warn('Failed to load conversations', err);
    } finally {
      setLoadingConvs(false);
    }
  }, [activeId]);

  const loadMessages = useCallback(async (convId: string) => {
    try {
      const { data, error } = await supabase
        .from('ai_messages')
        .select('id, role, content, created_at')
        .eq('conversation_id', convId)
        .order('created_at', { ascending: true })
        .limit(100);
      if (error) throw error;
      setMessages((data ?? []) as Msg[]);
    } catch (err) {
      console.warn('Failed to load messages', err);
    }
  }, []);

  useEffect(() => {
    if (!backendReady) return;
    void loadConversations();
    void checkProvider();
  }, [backendReady, loadConversations, checkProvider]);

  useEffect(() => {
    if (activeId && backendReady) void loadMessages(activeId);
  }, [activeId, backendReady, loadMessages]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, sending]);

  async function createConversation(tool: ToolType = activeTool) {
    try {
      const toolLabel = tools.find((t) => t.type === tool)?.label ?? 'Chat';
      const { data, error } = await supabase
        .from('ai_conversations')
        .insert({ title: `${toolLabel} — ${new Date().toLocaleDateString()}` })
        .select('id, title, updated_at')
        .single();
      if (error) throw error;
      const conv = data as Conv;
      setConversations((prev) => [conv, ...prev]);
      setActiveId(conv.id);
      setMessages([]);
      setShowMobileConvList(false);
    } catch (err) {
      toast.push({ title: 'Could not create conversation', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    }
  }

  async function deleteConversation(id: string) {
    try {
      const { error } = await supabase.from('ai_conversations').delete().eq('id', id);
      if (error) throw error;
      setConversations((prev) => prev.filter((c) => c.id !== id));
      if (activeId === id) {
        setActiveId(null);
        setMessages([]);
      }
      toast.push({ title: 'Conversation cleared', variant: 'success' });
    } catch (err) {
      toast.push({ title: 'Could not delete', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    }
  }

  async function sendMessage(e: React.FormEvent) {
    e.preventDefault();
    const text = input.trim();
    if (!text || sending || !activeId) return;
    if (providerStatus === 'not_configured') {
      toast.push({ title: 'AI provider not configured', description: 'An admin must set an AI API key in Edge Function secrets.', variant: 'warning' });
      return;
    }

    const userMsg: Msg = { id: `local-${Date.now()}`, role: 'user', content: text, created_at: new Date().toISOString() };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setSending(true);

    try {
      const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-chat`;
      const res = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({ conversationId: activeId, message: text, toolType: activeTool }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
      const assistantMsg: Msg = {
        id: data.messageId ?? `ai-${Date.now()}`,
        role: 'assistant',
        content: data.reply ?? '',
        created_at: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, assistantMsg]);
      if (data.usage) {
        setUsage({ used: data.usage.used, limit: data.usage.limit });
      }
    } catch (err) {
      const errorMsg: Msg = {
        id: `err-${Date.now()}`,
        role: 'assistant',
        content: `Error: ${err instanceof Error ? err.message : 'Unknown error'}`,
        created_at: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, errorMsg]);
      toast.push({ title: 'AI request failed', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    } finally {
      setSending(false);
    }
  }

  function copyMessage(content: string) {
    navigator.clipboard.writeText(content);
    toast.push({ title: 'Copied to clipboard', variant: 'success' });
  }

  function selectTool(tool: ToolType) {
    setActiveTool(tool);
    setShowToolMenu(false);
  }

  if (requiresAuth) {
    return (
      <>
        <Seo title="AI Lab" description="BLC Intelligence — an AI workspace for chat, code, research, and more." />
        <section className="section py-16">
          <EmptyState
            icon={<BrainCircuit className="h-10 w-10" />}
            title="Sign in to use the AI Lab"
            description="The AI Lab requires a BLC account. Create one to start using BLC Intelligence."
            action={
              <div className="flex gap-3">
                <Link to="/login"><Button variant="secondary">Sign in</Button></Link>
                <Link to="/signup"><Button>Sign up</Button></Link>
              </div>
            }
          />
        </section>
      </>
    );
  }

  if (!isSupabaseConfigured) {
    return (
      <>
        <Seo title="AI Lab" />
        <section className="section py-16">
          <EmptyState
            icon={<Settings className="h-10 w-10" />}
            title="Backend not configured"
            description="Supabase must be configured before the AI Lab can operate. See the README for setup instructions."
          />
        </section>
      </>
    );
  }

  return (
    <>
      <Seo title="AI Lab" description="BLC Intelligence — an AI workspace for chat, code, research, writing, and more." />
      <section className="section py-8">
        <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-secondary-500/20 to-accent-500/20 border border-secondary-500/30">
              <BrainCircuit className="h-5 w-5 text-secondary-400" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">AI Lab</h1>
              <p className="text-xs text-neutral-500">BLC Intelligence — {tools.length} tools</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {providerStatus === 'configured' && <Badge variant="success">{providerInfo.model ?? 'Provider configured'}</Badge>}
            {providerStatus === 'not_configured' && <Badge variant="warning">Not configured</Badge>}
            {providerStatus === 'unknown' && <Badge variant="neutral">Checking…</Badge>}
            {usage && providerStatus === 'configured' && (
              <Badge variant={usage.used >= usage.limit * 0.8 ? 'warning' : 'neutral'}>
                {usage.used}/{usage.limit} today
              </Badge>
            )}
            <Button variant="ghost" size="sm" className="lg:hidden" onClick={() => setShowMobileConvList(true)}>
              <MessageSquare className="h-4 w-4" /> Chats
            </Button>
          </div>
        </div>

        {providerStatus === 'not_configured' && (
          <Card className="mb-4 border-warning-500/30">
            <div className="flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-warning-400 shrink-0 mt-0.5" />
              <div className="text-sm">
                <p className="font-semibold text-warning-300">AI provider is not configured</p>
                <p className="mt-1 text-neutral-400">
                  An administrator must set <code className="text-secondary-300">AI_API_KEY</code> in the Supabase Edge Function secrets.
                  The UI is ready, but we will not generate fake AI responses.
                </p>
              </div>
            </div>
          </Card>
        )}

        {/* Tool selector */}
        <div className="mb-4">
          <div className="hidden sm:flex flex-wrap gap-2">
            {tools.map((t) => (
              <button
                key={t.type}
                onClick={() => selectTool(t.type)}
                className={cn(
                  'flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors border',
                  activeTool === t.type
                    ? 'bg-secondary-500/15 text-secondary-300 border-secondary-500/30'
                    : 'text-neutral-400 border-neutral-800 hover:text-white hover:border-neutral-700',
                )}
              >
                <t.icon className="h-4 w-4" />
                {t.label}
              </button>
            ))}
          </div>
          <div className="sm:hidden relative">
            <button
              onClick={() => setShowToolMenu(!showToolMenu)}
              className="flex items-center gap-2 w-full rounded-lg px-3 py-2 text-sm font-medium bg-blc-navy-700/60 text-white border border-neutral-800"
            >
              <activeToolDef.icon className="h-4 w-4 text-secondary-400" />
              <span className="flex-1 text-left">{activeToolDef.label}</span>
              <span className="text-xs text-neutral-500">{activeToolDef.desc}</span>
              <ChevronDown className="h-4 w-4 text-neutral-500" />
            </button>
            {showToolMenu && (
              <div className="absolute z-30 mt-1 w-full glass rounded-lg border border-neutral-800 p-1 max-h-64 overflow-y-auto">
                {tools.map((t) => (
                  <button
                    key={t.type}
                    onClick={() => selectTool(t.type)}
                    className={cn(
                      'flex items-center gap-2 w-full rounded-md px-3 py-2 text-sm text-left transition-colors',
                      activeTool === t.type ? 'bg-secondary-500/15 text-secondary-300' : 'text-neutral-300 hover:bg-neutral-800/50',
                    )}
                  >
                    <t.icon className="h-4 w-4 shrink-0" />
                    <div className="min-w-0">
                      <p className="font-medium">{t.label}</p>
                      <p className="text-xs text-neutral-500 truncate">{t.desc}</p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="grid lg:grid-cols-4 gap-6 h-[calc(100vh-18rem)] min-h-[500px]">
          {/* Conversation list - desktop */}
          <Card className="hidden lg:flex lg:flex-col !p-3">
            <Button size="sm" className="w-full" leftIcon={<Plus className="h-4 w-4" />} onClick={() => createConversation()}>
              New conversation
            </Button>
            <div className="mt-3 flex-1 overflow-y-auto space-y-1">
              {loadingConvs && <div className="flex justify-center py-8"><Loader2 className="h-5 w-5 animate-spin text-neutral-500" /></div>}
              {!loadingConvs && conversations.length === 0 && (
                <p className="text-xs text-neutral-500 text-center py-8">No conversations yet.</p>
              )}
              {conversations.map((c) => (
                <div
                  key={c.id}
                  className={cn(
                    'group flex items-center justify-between rounded-lg px-3 py-2 cursor-pointer transition-colors',
                    activeId === c.id ? 'bg-blc-navy-700 text-white' : 'text-neutral-400 hover:bg-neutral-800/50 hover:text-white',
                  )}
                  onClick={() => setActiveId(c.id)}
                >
                  <span className="text-sm truncate flex-1">{c.title}</span>
                  <button
                    onClick={(e) => { e.stopPropagation(); void deleteConversation(c.id); }}
                    className="opacity-0 group-hover:opacity-100 text-neutral-500 hover:text-error-400 transition-all"
                    aria-label="Delete conversation"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </Card>

          {/* Mobile conversation drawer */}
          {showMobileConvList && (
            <div className="lg:hidden fixed inset-0 z-50 bg-blc-navy-900/80 backdrop-blur-sm" onClick={() => setShowMobileConvList(false)}>
              <div className="absolute left-0 top-0 bottom-0 w-72 glass p-3 animate-slide-in" onClick={(e) => e.stopPropagation()}>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm font-semibold text-white">Conversations</span>
                  <button onClick={() => setShowMobileConvList(false)} className="text-neutral-400"><X className="h-5 w-5" /></button>
                </div>
                <Button size="sm" className="w-full mb-3" leftIcon={<Plus className="h-4 w-4" />} onClick={() => createConversation()}>New</Button>
                <div className="space-y-1 overflow-y-auto max-h-[calc(100vh-10rem)]">
                  {conversations.map((c) => (
                    <div
                      key={c.id}
                      className={cn(
                        'flex items-center justify-between rounded-lg px-3 py-2 cursor-pointer',
                        activeId === c.id ? 'bg-blc-navy-700 text-white' : 'text-neutral-400',
                      )}
                      onClick={() => { setActiveId(c.id); setShowMobileConvList(false); }}
                    >
                      <span className="text-sm truncate flex-1">{c.title}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Chat area */}
          <Card className="lg:col-span-3 flex flex-col !p-0 overflow-hidden">
            {!activeId ? (
              <div className="flex-1 flex items-center justify-center">
                <EmptyState
                  icon={<activeToolDef.icon className="h-10 w-10" />}
                  title={`${activeToolDef.label} Assistant`}
                  description={activeToolDef.desc}
                  action={<Button leftIcon={<Plus className="h-4 w-4" />} onClick={() => createConversation()}>New conversation</Button>}
                />
              </div>
            ) : (
              <>
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {messages.length === 0 && !sending && (
                    <div className="text-center py-12 text-neutral-500 text-sm">
                      Send a message to start the conversation. Using <span className="text-secondary-400 font-medium">{activeToolDef.label}</span> assistant.
                    </div>
                  )}
                  {messages.map((m) => (
                    <div key={m.id} className={cn('flex', m.role === 'user' ? 'justify-end' : 'justify-start')}>
                      <div
                        className={cn(
                          'group max-w-[85%] rounded-2xl px-4 py-3 text-sm',
                          m.role === 'user'
                            ? 'bg-primary-600/30 text-white rounded-br-sm'
                            : 'glass text-neutral-200 rounded-bl-sm',
                        )}
                      >
                        <p className="whitespace-pre-wrap break-words">{m.content}</p>
                        {m.role === 'assistant' && (
                          <button
                            onClick={() => copyMessage(m.content)}
                            className="mt-2 inline-flex items-center gap-1 text-xs text-neutral-500 hover:text-secondary-400 transition-colors"
                          >
                            <Copy className="h-3 w-3" /> Copy
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                  {sending && (
                    <div className="flex justify-start">
                      <div className="glass rounded-2xl rounded-bl-sm px-4 py-3">
                        <Loader2 className="h-4 w-4 animate-spin text-secondary-400" />
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>

                <form onSubmit={sendMessage} className="border-t border-neutral-800 p-4 flex items-end gap-3">
                  <textarea
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void sendMessage(e); }
                    }}
                    placeholder={activeToolDef.placeholder}
                    rows={1}
                    className="input flex-1 resize-none max-h-32"
                    disabled={sending}
                  />
                  <Button type="submit" loading={sending} leftIcon={!sending ? <Send className="h-4 w-4" /> : undefined}>
                    Send
                  </Button>
                </form>
              </>
            )}
          </Card>
        </div>
      </section>
    </>
  );
}
