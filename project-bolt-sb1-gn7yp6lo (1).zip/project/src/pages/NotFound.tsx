import { Link } from 'react-router-dom';
import { Home, Compass } from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Button } from '@/components/Button';
import { TechBackground } from '@/components/TechBackground';

export default function NotFound() {
  return (
    <>
      <Seo title="Page not found" description="The page you are looking for does not exist." />
      <section className="relative overflow-hidden min-h-[70vh] flex items-center justify-center">
        <TechBackground />
        <div className="section relative text-center py-20">
          <p className="text-7xl sm:text-9xl font-extrabold heading-gradient">404</p>
          <h1 className="mt-4 text-2xl font-bold text-white">Page not found</h1>
          <p className="mt-3 text-neutral-400 max-w-md mx-auto">
            The page you are looking for may have been moved, deleted, or never existed.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/"><Button size="lg" leftIcon={<Home className="h-5 w-5" />}>Back home</Button></Link>
            <Link to="/docs"><Button variant="secondary" size="lg" leftIcon={<Compass className="h-5 w-5" />}>Browse docs</Button></Link>
          </div>
        </div>
      </section>
    </>
  );
}
