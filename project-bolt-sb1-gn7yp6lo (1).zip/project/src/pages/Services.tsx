import { Link } from 'react-router-dom';
import { ArrowRight, Globe, LayoutDashboard, Smartphone, PenTool, BrainCircuit, Webhook, Database, CloudUpload, ShieldCheck, Wrench } from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Card, SectionHeading } from '@/components/ui';
import { Button } from '@/components/Button';
import { SERVICES } from '@/lib/data';

const icons: Record<string, typeof Globe> = {
  Globe, LayoutDashboard, Smartphone, PenTool, BrainCircuit, Webhook, Database, CloudUpload, ShieldCheck, Wrench,
};

export default function Services() {
  return (
    <>
      <Seo title="Services" description="Website, web app, Android, UI/UX, AI integration, API, database, cloud, security, and maintenance services by BLC." />
      <section className="section py-16">
        <SectionHeading
          center
          eyebrow="Services"
          title="End-to-end software engineering"
          subtitle="From idea to deployment — BLC offers services covering the full software lifecycle."
        />
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((s) => {
            const Icon = icons[s.icon] ?? Globe;
            return (
              <Card key={s.slug} className="flex flex-col h-full">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-secondary-500/20 to-accent-500/20 border border-secondary-500/30">
                  <Icon className="h-6 w-6 text-secondary-400" />
                </div>
                <h3 className="mt-4 text-lg font-bold text-white">{s.name}</h3>
                <p className="mt-2 text-sm text-neutral-400 leading-relaxed flex-1">{s.description}</p>
                <ul className="mt-4 space-y-2">
                  {s.benefits.map((b) => (
                    <li key={b} className="flex items-center gap-2 text-xs text-neutral-300">
                      <span className="h-1.5 w-1.5 rounded-full bg-success-400" />
                      {b}
                    </li>
                  ))}
                </ul>
              </Card>
            );
          })}
        </div>

        <Card className="mt-12 text-center">
          <h3 className="text-2xl font-bold text-white">Have a project in mind?</h3>
          <p className="mt-3 text-neutral-400">Tell us about it and we will get back to you.</p>
          <Link to="/contact" className="inline-block mt-6">
            <Button size="lg" rightIcon={<ArrowRight className="h-5 w-5" />}>Contact us</Button>
          </Link>
        </Card>
      </section>
    </>
  );
}
