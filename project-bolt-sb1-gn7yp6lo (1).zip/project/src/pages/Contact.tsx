import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Send, Mail, MapPin, MessageSquare } from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Card, SectionHeading } from '@/components/ui';
import { Button } from '@/components/Button';
import { useToast } from '@/components/Toast';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';

const schema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters').max(80),
  email: z.string().email('Enter a valid email'),
  subject: z.string().min(3, 'Subject must be at least 3 characters').max(120),
  message: z.string().min(10, 'Message must be at least 10 characters').max(2000),
});

type FormData = z.infer<typeof schema>;

export default function Contact() {
  const toast = useToast();
  const [submitting, setSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FormData>({ resolver: zodResolver(schema) });

  const onSubmit = async (data: FormData) => {
    setSubmitting(true);
    try {
      if (!isSupabaseConfigured) {
        toast.push({
          title: 'Backend not configured',
          description: 'Supabase is not set up. Contact submissions require a configured backend.',
          variant: 'error',
        });
        return;
      }
      const { error } = await supabase.from('contact_submissions').insert({
        name: data.name,
        email: data.email,
        subject: data.subject,
        message: data.message,
        status: 'new',
      });
      if (error) throw error;
      toast.push({ title: 'Message sent', description: 'We will get back to you soon.', variant: 'success' });
      reset();
    } catch (err) {
      toast.push({
        title: 'Could not send message',
        description: err instanceof Error ? err.message : 'Please try again later.',
        variant: 'error',
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      <Seo title="Contact" description="Get in touch with Bangladesh Logic Code." />
      <section className="section py-16">
        <SectionHeading center eyebrow="Contact" title="Let's build something" subtitle="Tell us about your project, request a service, or report a security issue." />

        <div className="grid lg:grid-cols-3 gap-8 mt-12">
          <div className="space-y-6">
            <Card>
              <Mail className="h-6 w-6 text-secondary-400" />
              <h3 className="mt-3 font-semibold text-white">Email</h3>
              <p className="mt-1 text-sm text-neutral-400">founder@blc.dev</p>
            </Card>
            <Card>
              <MapPin className="h-6 w-6 text-secondary-400" />
              <h3 className="mt-3 font-semibold text-white">Location</h3>
              <p className="mt-1 text-sm text-neutral-400">Bangladesh · Remote-first</p>
            </Card>
            <Card>
              <MessageSquare className="h-6 w-6 text-secondary-400" />
              <h3 className="mt-3 font-semibold text-white">Response time</h3>
              <p className="mt-1 text-sm text-neutral-400">Usually within 1–2 business days.</p>
            </Card>
          </div>

          <div className="lg:col-span-2">
            <Card>
              {!isSupabaseConfigured && (
                <div className="mb-6 rounded-lg border border-warning-500/30 bg-warning-500/10 p-4 text-sm text-warning-300">
                  Supabase is not configured. Submissions will not be stored. See the README for setup instructions.
                </div>
              )}
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-5" noValidate>
                <div className="grid sm:grid-cols-2 gap-5">
                  <div>
                    <label className="label" htmlFor="name">Name</label>
                    <input id="name" className="input" placeholder="Your name" {...register('name')} aria-invalid={!!errors.name} />
                    {errors.name && <p className="mt-1 text-xs text-error-400">{errors.name.message}</p>}
                  </div>
                  <div>
                    <label className="label" htmlFor="email">Email</label>
                    <input id="email" type="email" className="input" placeholder="you@example.com" {...register('email')} aria-invalid={!!errors.email} />
                    {errors.email && <p className="mt-1 text-xs text-error-400">{errors.email.message}</p>}
                  </div>
                </div>
                <div>
                  <label className="label" htmlFor="subject">Subject</label>
                  <input id="subject" className="input" placeholder="What is this about?" {...register('subject')} aria-invalid={!!errors.subject} />
                  {errors.subject && <p className="mt-1 text-xs text-error-400">{errors.subject.message}</p>}
                </div>
                <div>
                  <label className="label" htmlFor="message">Message</label>
                  <textarea id="message" rows={6} className="input resize-y" placeholder="Tell us more..." {...register('message')} aria-invalid={!!errors.message} />
                  {errors.message && <p className="mt-1 text-xs text-error-400">{errors.message.message}</p>}
                </div>
                <Button type="submit" loading={submitting} leftIcon={!submitting ? <Send className="h-4 w-4" /> : undefined}>
                  Send message
                </Button>
              </form>
            </Card>
          </div>
        </div>
      </section>
    </>
  );
}
