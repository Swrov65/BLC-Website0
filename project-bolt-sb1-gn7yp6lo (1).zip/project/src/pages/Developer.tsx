import { Link } from 'react-router-dom';
import {
  Terminal, KeyRound, BarChart3, BookOpen, Webhook, Code2, Bell, ArrowRight, CheckCircle2,
} from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Card, SectionHeading, Badge, EmptyState } from '@/components/ui';
import { Button } from '@/components/Button';
import { useAuth } from '@/auth/AuthContext';

export default function Developer() {
  const { session } = useAuth();

  const features = [
    { icon: KeyRound, title: 'API key management', desc: 'Create and revoke API keys for your applications. Full secrets shown only once.' },
    { icon: BarChart3, title: 'Usage statistics', desc: 'Monitor API usage per key. Real data is shown only when a backend records it.' },
    { icon: Code2, title: 'Project management', desc: 'Register and manage your developer projects from the dashboard.' },
    { icon: Webhook, title: 'Webhooks', desc: 'Receive signed event notifications at your configured endpoints.' },
    { icon: BookOpen, title: 'Integration guides', desc: 'Step-by-step guides and SDK documentation.' },
    { icon: Bell, title: 'Developer announcements', desc: 'Stay informed about platform changes and new features.' },
  ];

  return (
    <>
      <Seo title="Developer Center" description="BLC Developer Center — APIs, SDKs, webhooks, API keys, and documentation." />
      <section className="section py-16">
        <SectionHeading
          center
          eyebrow="Developer Center"
          title="Build on the BLC platform"
          subtitle="Secure APIs, SDKs, webhooks, and tooling for developers who want to integrate BLC into their applications."
        />

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-12">
          {features.map((f) => (
            <Card key={f.title}>
              <f.icon className="h-7 w-7 text-secondary-400" />
              <h3 className="mt-4 font-semibold text-white">{f.title}</h3>
              <p className="mt-2 text-sm text-neutral-400">{f.desc}</p>
            </Card>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-6 mt-8">
          <Card>
            <div className="flex items-center gap-3">
              <Terminal className="h-6 w-6 text-secondary-400" />
              <h3 className="font-semibold text-white">Quick start</h3>
            </div>
            <div className="mt-4 rounded-lg bg-blc-navy-900 border border-neutral-800 p-4 font-mono text-xs text-neutral-300 overflow-x-auto">
              <p><span className="text-success-400">$</span> npm install @blc/sdk</p>
              <p><span className="text-success-400">$</span> export BLC_API_KEY=blc_••••••••</p>
              <p className="text-neutral-500">{'# Initialize the client'}</p>
              <p><span className="text-secondary-300">const</span> blc = <span className="text-secondary-300">new</span> BlcClient(process.env.BLC_API_KEY)</p>
              <p><span className="text-secondary-300">const</span> projects = <span className="text-secondary-300">await</span> blc.projects.list()</p>
            </div>
          </Card>

          <Card>
            <div className="flex items-center gap-3">
              <BookOpen className="h-6 w-6 text-secondary-400" />
              <h3 className="font-semibold text-white">SDK & guides</h3>
            </div>
            <ul className="mt-4 space-y-3">
              {[
                { label: 'Getting started guide', to: '/docs/getting-started' },
                { label: 'API authentication', to: '/docs/authentication' },
                { label: 'API keys', to: '/docs/api-keys' },
                { label: 'Webhooks', to: '/docs/webhooks' },
              ].map((l) => (
                <li key={l.to}>
                  <Link to={l.to} className="flex items-center justify-between text-sm text-neutral-300 hover:text-secondary-400 transition-colors group">
                    {l.label}
                    <ArrowRight className="h-4 w-4 text-neutral-600 group-hover:text-secondary-400 group-hover:translate-x-1 transition-all" />
                  </Link>
                </li>
              ))}
            </ul>
          </Card>
        </div>

        <Card className="mt-8">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <h3 className="font-semibold text-white">Register a developer application</h3>
              <p className="mt-1 text-sm text-neutral-400">Create an app and generate API keys from your dashboard.</p>
            </div>
            {session ? (
              <Link to="/dashboard/api-keys"><Button rightIcon={<ArrowRight className="h-4 w-4" />}>Manage API keys</Button></Link>
            ) : (
              <Link to="/signup"><Button rightIcon={<ArrowRight className="h-4 w-4" />}>Sign up to get keys</Button></Link>
            )}
          </div>
        </Card>

        <Card className="mt-4">
          <Badge variant="warning">Developer announcements</Badge>
          <div className="mt-4">
            <EmptyState
              icon={<Bell className="h-8 w-8" />}
              title="No announcements yet"
              description="Developer announcements will appear here when published. We do not fabricate announcements."
            />
          </div>
        </Card>

        <Card className="mt-4 border-secondary-500/20">
          <div className="flex items-start gap-3">
            <CheckCircle2 className="h-5 w-5 text-success-400 shrink-0 mt-0.5" />
            <p className="text-sm text-neutral-300">
              API keys are managed securely. Full key secrets are shown only once at creation.
              We store only a non-sensitive prefix for identification.
            </p>
          </div>
        </Card>
      </section>
    </>
  );
}
