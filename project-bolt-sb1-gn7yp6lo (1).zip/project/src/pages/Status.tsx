import { Activity, CheckCircle2, AlertTriangle, Wrench, XCircle } from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Card, SectionHeading, Badge } from '@/components/ui';
import { SERVICE_STATUSES } from '@/lib/data';
import { cn } from '@/lib/utils';

const statusConfig = {
  operational: { label: 'Operational', color: 'text-success-400', dot: 'bg-success-400', badge: 'success' as const, icon: CheckCircle2 },
  degraded: { label: 'Degraded', color: 'text-warning-400', dot: 'bg-warning-400', badge: 'warning' as const, icon: AlertTriangle },
  partial_outage: { label: 'Partial outage', color: 'text-warning-400', dot: 'bg-warning-400', badge: 'warning' as const, icon: AlertTriangle },
  major_outage: { label: 'Major outage', color: 'text-error-400', dot: 'bg-error-400', badge: 'error' as const, icon: XCircle },
  maintenance: { label: 'Maintenance', color: 'text-secondary-400', dot: 'bg-secondary-400', badge: 'info' as const, icon: Wrench },
  in_development: { label: 'In development', color: 'text-neutral-400', dot: 'bg-neutral-500', badge: 'neutral' as const, icon: Activity },
};

export default function Status() {
  const allOperational = SERVICE_STATUSES.every((s) => s.status === 'operational');
  return (
    <>
      <Seo title="Status" description="BLC service status — honest, real-time availability of platform components." />
      <section className="section py-16">
        <SectionHeading center eyebrow="Status" title="Service status" subtitle="An honest view of platform component availability. We do not display fake uptime percentages." />

        <Card className={cn('mt-8 text-center', allOperational ? 'border-success-500/30' : 'border-warning-500/30')}>
          <div className="flex items-center justify-center gap-3">
            {allOperational ? (
              <CheckCircle2 className="h-8 w-8 text-success-400" />
            ) : (
              <AlertTriangle className="h-8 w-8 text-warning-400" />
            )}
            <div>
              <h3 className="text-xl font-bold text-white">
                {allOperational ? 'All systems operational' : 'Some systems are degraded'}
              </h3>
              <p className="text-sm text-neutral-400 mt-1">Last updated: {new Date().toLocaleString()}</p>
            </div>
          </div>
        </Card>

        <div className="mt-8 space-y-3">
          {SERVICE_STATUSES.map((s) => {
            const cfg = statusConfig[s.status];
            const Icon = cfg.icon;
            return (
              <Card key={s.name} className="!py-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Icon className={cn('h-5 w-5', cfg.color)} />
                  <div>
                    <p className="font-semibold text-white">{s.name}</p>
                    <p className="text-xs text-neutral-500">{s.description}</p>
                  </div>
                </div>
                <Badge variant={cfg.badge}>
                  <span className={cn('h-1.5 w-1.5 rounded-full', cfg.dot)} />
                  {cfg.label}
                </Badge>
              </Card>
            );
          })}
        </div>

        <p className="mt-8 text-center text-xs text-neutral-500">
          This status page reflects actual component states. We do not fabricate uptime metrics.
        </p>
      </section>
    </>
  );
}
