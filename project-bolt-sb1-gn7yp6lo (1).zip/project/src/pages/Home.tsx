import { Link } from 'react-router-dom';
import {
  ArrowRight, BrainCircuit, Code2, Cloud, ShieldCheck, Terminal, Zap, Globe, Lock,
  CheckCircle2, ChevronDown, Sparkles, Rocket, Server, Cpu, Search, KeyRound, Webhook,
  BookOpen, LifeBuoy, Bell, type LucideIcon,
  MessageSquare, PenLine, Image, Video, Mic, Languages, FileText, FileCode,
  BarChart3, Presentation, Palette, Calculator, GraduationCap, Headphones, Plug,
} from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Button } from '@/components/Button';
import { Card, Badge, SectionHeading, StatusBadge } from '@/components/ui';
import { TechBackground } from '@/components/TechBackground';
import { AiNetwork } from '@/components/AiNetwork';
import { PRODUCTS, SERVICES } from '@/lib/data';
import { isSupabaseConfigured } from '@/lib/supabase';
import { useAuth } from '@/auth/AuthContext';
import { useState, useMemo } from 'react';
import { cn } from '@/lib/utils';

const productIcons: Record<string, typeof BrainCircuit> = {
  BrainCircuit, Code2, Cloud, AppWindow: Terminal, Terminal, ShieldCheck,
};

type PlatformCard = {
  id: string;
  title: string;
  description: string;
  icon: LucideIcon;
  to: string;
  status: 'live' | 'beta' | 'planned' | 'in_development';
  category: 'Build' | 'AI' | 'Cloud' | 'Developer' | 'Security';
  features: string[];
};

const platformCards: PlatformCard[] = [
  {
    id: 'intelligence',
    title: 'BLC Intelligence',
    description: 'AI chat, writing assistance, coding assistance, research, learning, and productivity tools.',
    icon: BrainCircuit,
    to: '/ai-lab',
    status: 'in_development',
    category: 'AI',
    features: ['Chat Assistant', 'Writing Assistant', 'Code Assistant', 'Research Tools', 'Learning Tools', 'Productivity Tools'],
  },
  {
    id: 'studio',
    title: 'BLC Studio',
    description: 'Code editor, project creation, editing, and supported project previews.',
    icon: Code2,
    to: '/dashboard/studio',
    status: 'beta',
    category: 'Build',
    features: ['Code Editor', 'File Explorer', 'Project Management', 'HTML Preview', 'Import / Export'],
  },
  {
    id: 'cloud',
    title: 'BLC Cloud',
    description: 'Project storage, file management, and available deployment tools.',
    icon: Cloud,
    to: '/dashboard/cloud',
    status: 'beta',
    category: 'Cloud',
    features: ['File Upload', 'File Download', 'Storage Usage', 'Project Files', 'Deployment Config'],
  },
  {
    id: 'apis',
    title: 'BLC APIs',
    description: 'API documentation, API key management, and API usage tools.',
    icon: KeyRound,
    to: '/dashboard/api-keys',
    status: 'beta',
    category: 'Developer',
    features: ['API Key Creation', 'Key Revocation', 'Usage Logs', 'Webhooks', 'Documentation'],
  },
  {
    id: 'developer',
    title: 'BLC Developer Platform',
    description: 'Developer dashboard, projects, documentation, and developer tools.',
    icon: Terminal,
    to: '/developer',
    status: 'beta',
    category: 'Developer',
    features: ['Developer Dashboard', 'Project Management', 'SDK Docs', 'Usage Stats', 'Webhook Config'],
  },
  {
    id: 'security',
    title: 'BLC Security',
    description: 'Security settings, account protection, and available security features.',
    icon: ShieldCheck,
    to: '/security',
    status: 'live',
    category: 'Security',
    features: ['Row Level Security', 'Server-Side Auth', 'Password Protection', 'Audit Logs', 'Secure Sessions'],
  },
];

const categories = ['All', 'AI', 'Build', 'Cloud', 'Developer', 'Security'] as const;

type AiTool = {
  id: string;
  name: string;
  description: string;
  icon: LucideIcon;
  to: string;
  status: 'live' | 'beta' | 'planned' | 'in_development';
  category: string;
  requiresProvider?: string;
};

const aiTools: AiTool[] = [
  { id: 'ai-chatbot', name: 'AI Chatbot', description: 'Answer questions, explain concepts, brainstorm ideas, and assist through conversation.', icon: MessageSquare, to: '/ai-lab?tool=chat', status: 'beta', category: 'Chat & Writing', requiresProvider: 'AI_API_KEY' },
  { id: 'ai-writing', name: 'AI Writing Assistant', description: 'Write, rewrite, summarize, proofread, and improve text, emails, articles, and posts.', icon: PenLine, to: '/ai-lab?tool=writing', status: 'beta', category: 'Chat & Writing', requiresProvider: 'AI_API_KEY' },
  { id: 'ai-image', name: 'AI Image Generator', description: 'Generate images from text prompts using a real image-generation provider.', icon: Image, to: '/ai/image', status: 'planned', category: 'Image & Video', requiresProvider: 'Image generation API' },
  { id: 'ai-video', name: 'AI Video Generator', description: 'Generate videos from text or image prompts using a video-generation provider.', icon: Video, to: '/ai/video', status: 'planned', category: 'Image & Video', requiresProvider: 'Video generation API' },
  { id: 'ai-voice', name: 'AI Voice Generator', description: 'Convert text into natural-sounding speech using a text-to-speech provider.', icon: Mic, to: '/ai/voice', status: 'planned', category: 'Voice & Translation', requiresProvider: 'TTS API' },
  { id: 'ai-translator', name: 'AI Translator', description: 'Translate text between supported languages, including Bengali and English.', icon: Languages, to: '/ai/translator', status: 'beta', category: 'Voice & Translation', requiresProvider: 'AI_API_KEY' },
  { id: 'ai-coding', name: 'AI Coding Assistant', description: 'Explain code, generate code, debug errors, and help with programming tasks.', icon: Code2, to: '/ai-lab?tool=code', status: 'beta', category: 'Coding & Development', requiresProvider: 'AI_API_KEY' },
  { id: 'ai-website-builder', name: 'AI Website Builder', description: 'Create website layouts and generate website code from descriptions.', icon: Globe, to: '/ai/website-builder', status: 'beta', category: 'Coding & Development', requiresProvider: 'AI_API_KEY' },
  { id: 'ai-app-builder', name: 'AI App Builder', description: 'Plan and generate application code, project structures, and implementation guides.', icon: Code2, to: '/ai/app-builder', status: 'beta', category: 'Coding & Development', requiresProvider: 'AI_API_KEY' },
  { id: 'ai-doc-reader', name: 'AI Document Reader', description: 'Summarize text from documents and answer questions about their contents.', icon: FileText, to: '/ai/document-reader', status: 'beta', category: 'Documents & Research', requiresProvider: 'AI_API_KEY' },
  { id: 'ai-pdf', name: 'AI PDF Assistant', description: 'Summarize PDF content and answer questions about it.', icon: FileText, to: '/ai/pdf', status: 'beta', category: 'Documents & Research', requiresProvider: 'AI_API_KEY' },
  { id: 'ai-research', name: 'AI Research Assistant', description: 'Investigate topics, organize findings, and summarize sources with clear sourcing.', icon: Search, to: '/ai-lab?tool=research', status: 'beta', category: 'Documents & Research', requiresProvider: 'AI_API_KEY + Search API' },
  { id: 'ai-data-analyst', name: 'AI Data Analyst', description: 'Analyze data, calculate statistics, identify trends, and suggest visualizations.', icon: BarChart3, to: '/ai/data-analyst', status: 'beta', category: 'Data & Education', requiresProvider: 'AI_API_KEY' },
  { id: 'ai-presentation', name: 'AI Presentation Maker', description: 'Generate presentation outlines, slide content, and speaker notes.', icon: Presentation, to: '/ai/presentation', status: 'beta', category: 'Data & Education', requiresProvider: 'AI_API_KEY' },
  { id: 'ai-logo', name: 'AI Logo Designer', description: 'Generate logo concepts from text descriptions using an image-generation provider.', icon: Palette, to: '/ai/logo', status: 'planned', category: 'Image & Video', requiresProvider: 'Image generation API' },
  { id: 'ai-math', name: 'AI Math Solver', description: 'Explain mathematical problems step by step and help understand calculations.', icon: Calculator, to: '/ai/math', status: 'beta', category: 'Data & Education', requiresProvider: 'AI_API_KEY' },
  { id: 'ai-education', name: 'AI Education Assistant', description: 'Support learning, explain lessons, generate practice questions, and study help.', icon: GraduationCap, to: '/ai-lab?tool=learning', status: 'beta', category: 'Data & Education', requiresProvider: 'AI_API_KEY' },
  { id: 'ai-support', name: 'AI Customer Support', description: 'AI support assistant answering questions about the BLC platform.', icon: Headphones, to: '/ai/support', status: 'beta', category: 'Business & Support', requiresProvider: 'AI_API_KEY' },
  { id: 'ai-search', name: 'AI Search Engine', description: 'Search the web with a real search API. Display source links alongside summaries.', icon: Search, to: '/ai/search', status: 'planned', category: 'Business & Support', requiresProvider: 'Search API' },
  { id: 'ai-api-platform', name: 'AI API Platform', description: 'API documentation, key management, usage info, and developer tools.', icon: Plug, to: '/dashboard/api-keys', status: 'beta', category: 'Developer Tools' },
];

const aiCategories = ['All', 'Chat & Writing', 'Image & Video', 'Voice & Translation', 'Coding & Development', 'Documents & Research', 'Data & Education', 'Business & Support', 'Developer Tools'] as const;

const faqs = [
  {
    q: 'What is Bangladesh Logic Code?',
    a: 'BLC is a technology platform founded by Soyaif that offers software development services, an AI workspace, a developer platform, and a suite of digital products.',
  },
  {
    q: 'Is BLC free to use?',
    a: 'The Free plan is available forever. Pro and Business plans are listed for reference, but payments are not collected until a payment provider is configured.',
  },
  {
    q: 'Who is the founder?',
    a: 'BLC was founded and is developed by Soyaif. You can read more on the About page.',
  },
  {
    q: 'Is my data secure?',
    a: 'Yes. All database tables use Row Level Security, privileged operations require server-side authorization, and secrets are never exposed to the browser.',
  },
  {
    q: 'Can I use the AI Lab right now?',
    a: 'The AI Lab UI is available. It requires an AI provider to be configured server-side. If not configured, the lab shows a clear configuration message instead of fake responses.',
  },
];

export default function Home() {
  return (
    <>
      <Seo />
      <Hero />
      <PlatformGrid />
      <AiToolsGrid />
      <FeaturedProducts />
      <AiCapabilities />
      <ServicesPreview />
      <DeveloperPlatformPreview />
      <CloudPreview />
      <SecuritySection />
      <BenefitsSection />
      <FaqSection />
      <ContactCta />
    </>
  );
}

function Hero() {
  const { session, profile } = useAuth();
  return (
    <section className="relative overflow-hidden">
      <TechBackground />
      <div className="section relative pt-16 pb-20 sm:pt-24 sm:pb-28">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left: copy */}
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-xs font-medium text-secondary-300 animate-fade-in">
              <Sparkles className="h-3.5 w-3.5" />
              Founded by Soyaif · Build Beyond
            </div>

            {session && profile && (
              <p className="mt-5 text-sm text-neutral-400 animate-fade-in-up">
                Welcome back, <span className="text-secondary-300 font-medium">{profile.display_name ?? profile.email}</span>
              </p>
            )}

            <h1 className="mt-4 text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight heading-gradient animate-fade-in-up leading-[1.1]">
              Your AI Universe.<br />One Powerful Platform.
            </h1>
            <p className="mt-5 text-base sm:text-lg text-neutral-400 leading-relaxed animate-fade-in-up max-w-xl mx-auto lg:mx-0" style={{ animationDelay: '0.05s' }}>
              Bangladesh Logic Code is a technology platform for intelligent software, AI workspaces,
              cloud infrastructure, and developer tools. Intelligent Technology. Limitless Possibilities.
            </p>

            <div className="mt-8 flex flex-col sm:flex-row items-center lg:items-start justify-center lg:justify-start gap-3 animate-fade-in-up" style={{ animationDelay: '0.1s' }}>
              <a href="#ai-tools">
                <Button size="lg" rightIcon={<ArrowRight className="h-5 w-5" />}>
                  Explore AI Tools
                </Button>
              </a>
              <Link to="/dashboard/studio">
                <Button variant="secondary" size="lg" leftIcon={<Code2 className="h-5 w-5" />}>
                  Open BLC Studio
                </Button>
              </Link>
            </div>

            {!session && (
              <div className="mt-6 flex flex-col sm:flex-row items-center lg:items-start justify-center lg:justify-start gap-3 animate-fade-in-up" style={{ animationDelay: '0.15s' }}>
                <Link to="/signup"><Button variant="ghost" size="sm" rightIcon={<ArrowRight className="h-4 w-4" />}>Get Started</Button></Link>
                <Link to="/login"><Button variant="ghost" size="sm">Sign in</Button></Link>
              </div>
            )}

            <div className="mt-10 flex flex-wrap items-center justify-center lg:justify-start gap-x-6 gap-y-2 text-xs text-neutral-500">
              <span className="flex items-center gap-1.5"><CheckCircle2 className="h-4 w-4 text-success-400" /> Secure by design</span>
              <span className="flex items-center gap-1.5"><CheckCircle2 className="h-4 w-4 text-success-400" /> Developer-first</span>
              <span className="flex items-center gap-1.5"><CheckCircle2 className="h-4 w-4 text-success-400" /> Built by Soyaif</span>
            </div>
          </div>

          {/* Right: AI network illustration */}
          <div className="relative hidden lg:block animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
            <div className="relative aspect-square max-w-lg mx-auto">
              <div className="absolute inset-0 rounded-full bg-gradient-to-br from-secondary-500/10 via-transparent to-accent-500/10 blur-2xl" />
              <AiNetwork />
              {/* Floating labels */}
              <div className="absolute top-[12%] left-[8%] glass rounded-lg px-3 py-1.5 text-xs text-secondary-300 animate-float">Chat</div>
              <div className="absolute top-[18%] right-[10%] glass rounded-lg px-3 py-1.5 text-xs text-accent-300 animate-float" style={{ animationDelay: '1s' }}>Code</div>
              <div className="absolute bottom-[20%] left-[12%] glass rounded-lg px-3 py-1.5 text-xs text-secondary-300 animate-float" style={{ animationDelay: '2s' }}>Research</div>
              <div className="absolute bottom-[14%] right-[8%] glass rounded-lg px-3 py-1.5 text-xs text-accent-300 animate-float" style={{ animationDelay: '0.5s' }}>Cloud</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function PlatformGrid() {
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<(typeof categories)[number]>('All');

  const filtered = useMemo(() => {
    return platformCards.filter((c) => {
      const matchesCategory = category === 'All' || c.category === category;
      const q = query.toLowerCase();
      const matchesQuery = !q || c.title.toLowerCase().includes(q) || c.description.toLowerCase().includes(q) || c.features.some((f) => f.toLowerCase().includes(q));
      return matchesCategory && matchesQuery;
    });
  }, [query, category]);

  return (
    <section id="platforms" className="section py-20">
      <SectionHeading
        center
        eyebrow="Platform Modules"
        title="One platform, every tool you need"
        subtitle="Each BLC module is built to work together — from AI assistance to code editing, cloud storage, APIs, and security."
      />

      <div className="mb-8 flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-500" />
          <input
            type="text"
            placeholder="Search platform tools..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="input pl-10 text-sm"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setCategory(c)}
              className={cn(
                'rounded-lg px-3 py-1.5 text-xs font-medium transition-colors border',
                category === c
                  ? 'bg-secondary-500/15 text-secondary-300 border-secondary-500/30'
                  : 'text-neutral-400 border-neutral-800 hover:text-white hover:border-neutral-700',
              )}
            >
              {c}
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <Card className="text-center py-12">
          <p className="text-sm text-neutral-500">No platform modules match your search.</p>
        </Card>
      ) : (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((card) => (
            <Link key={card.id} to={card.to} className="group">
              <Card className="h-full hover:border-secondary-400/40 transition-all duration-300 hover:-translate-y-1 flex flex-col">
                <div className="flex items-start justify-between">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-secondary-500/20 to-accent-500/20 border border-secondary-500/30">
                    <card.icon className="h-6 w-6 text-secondary-400" />
                  </div>
                  <StatusBadge status={card.status} />
                </div>
                <h3 className="mt-5 text-lg font-bold text-white group-hover:text-secondary-300 transition-colors">
                  {card.title}
                </h3>
                <p className="mt-2 text-sm text-neutral-400 leading-relaxed flex-1">{card.description}</p>
                <div className="mt-4 flex flex-wrap gap-1.5">
                  {card.features.slice(0, 4).map((f) => (
                    <span key={f} className="text-xs rounded-md bg-neutral-800/60 px-2 py-0.5 text-neutral-400">{f}</span>
                  ))}
                  {card.features.length > 4 && (
                    <span className="text-xs rounded-md bg-neutral-800/60 px-2 py-0.5 text-neutral-500">+{card.features.length - 4} more</span>
                  )}
                </div>
                <span className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-secondary-400">
                  Open module <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </span>
              </Card>
            </Link>
          ))}
        </div>
      )}

      <div className="mt-8 text-center">
        <p className="text-xs text-neutral-500">
          <span className="inline-flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-success-400" /> Live</span>
          {' · '}
          <span className="inline-flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-secondary-400" /> Beta</span>
          {' · '}
          <span className="inline-flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-warning-400" /> In Development</span>
          {' · '}
          <span className="inline-flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-neutral-500" /> Planned</span>
        </p>
      </div>
    </section>
  );
}

function AiToolsGrid() {
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<(typeof aiCategories)[number]>('All');

  const filtered = useMemo(() => {
    return aiTools.filter((t) => {
      const matchesCategory = category === 'All' || t.category === category;
      const q = query.toLowerCase();
      const matchesQuery = !q || t.name.toLowerCase().includes(q) || t.description.toLowerCase().includes(q);
      return matchesCategory && matchesQuery;
    });
  }, [query, category]);

  return (
    <section id="ai-tools" className="relative section py-20 overflow-hidden">
      <div className="absolute inset-0 bg-radial-glow opacity-40" />
      <div className="relative">
        <SectionHeading
          center
          eyebrow="BLC AI Tools"
          title="BLC AI TOOLS"
          subtitle="Your AI workspace for creativity, productivity, learning, and development."
        />

        <div className="mb-8 flex flex-col sm:flex-row gap-3 items-center justify-between">
          <div className="relative w-full sm:max-w-xs">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-500" />
            <input
              type="text"
              placeholder="Search AI tools..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="input pl-10 text-sm"
            />
          </div>
          <div className="flex flex-wrap gap-2 max-w-full overflow-x-auto">
            {aiCategories.map((c) => (
              <button
                key={c}
                onClick={() => setCategory(c)}
                className={cn(
                  'rounded-lg px-3 py-1.5 text-xs font-medium transition-colors border whitespace-nowrap',
                  category === c
                    ? 'bg-secondary-500/15 text-secondary-300 border-secondary-500/30'
                    : 'text-neutral-400 border-neutral-800 hover:text-white hover:border-neutral-700',
                )}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        {filtered.length === 0 ? (
          <Card className="text-center py-12">
            <p className="text-sm text-neutral-500">No AI tools match your search.</p>
          </Card>
        ) : (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filtered.map((tool) => (
              <Link key={tool.id} to={tool.to} className="group">
                <div className="ai-card h-full flex flex-col">
                  <div className="flex items-start justify-between">
                    <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-secondary-500/20 to-accent-500/20 border border-secondary-500/30 group-hover:from-secondary-500/30 group-hover:to-accent-500/30 transition-all">
                      <tool.icon className="h-5 w-5 text-secondary-400" />
                    </div>
                    <StatusBadge status={tool.status} />
                  </div>
                  <h3 className="mt-4 text-base font-bold text-white group-hover:text-secondary-300 transition-colors">
                    {tool.name}
                  </h3>
                  <p className="mt-2 text-sm text-neutral-400 leading-relaxed flex-1">{tool.description}</p>
                  {tool.requiresProvider && (tool.status === 'planned' || tool.status === 'in_development') && (
                    <div className="mt-3 inline-flex items-center gap-1.5 text-xs text-warning-400">
                      <span className="h-1.5 w-1.5 rounded-full bg-warning-400" />
                      Setup Required: {tool.requiresProvider}
                    </div>
                  )}
                  <span className="mt-3 inline-flex items-center gap-1 text-sm font-medium text-secondary-400">
                    Open tool <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </span>
                </div>
              </Link>
            ))}
          </div>
        )}

        <div className="mt-8 text-center">
          <p className="text-xs text-neutral-500">
            {aiTools.length} AI tools · Tools marked <span className="text-warning-400">Setup Required</span> need a configured provider to generate real output.
          </p>
        </div>
      </div>
    </section>
  );
}

function FeaturedProducts() {
  return (
    <section className="section py-20">
      <SectionHeading
        center
        eyebrow="Products"
        title="A platform of connected products"
        subtitle="Six products spanning AI, development tools, cloud, apps, developer APIs, and security — each with honest availability status."
      />
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {PRODUCTS.map((p) => {
          const Icon = productIcons[p.icon] ?? Code2;
          return (
            <Link key={p.id} to={`/products/${p.slug}`} className="group">
              <Card className="h-full hover:border-secondary-400/40 transition-all duration-300 hover:-translate-y-1">
                <div className="flex items-start justify-between">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-secondary-500/20 to-accent-500/20 border border-secondary-500/30">
                    <Icon className="h-6 w-6 text-secondary-400" />
                  </div>
                  <StatusBadge status={p.availability} />
                </div>
                <h3 className="mt-5 text-lg font-bold text-white group-hover:text-secondary-300 transition-colors">
                  {p.name}
                </h3>
                <p className="mt-2 text-sm text-neutral-400 leading-relaxed">{p.tagline}</p>
                <span className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-secondary-400">
                  Learn more <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </span>
              </Card>
            </Link>
          );
        })}
      </div>
    </section>
  );
}

function AiCapabilities() {
  const features = [
    { icon: BrainCircuit, title: 'Context-aware chat', desc: 'Conversations that understand your project context.' },
    { icon: Code2, title: 'Code generation', desc: 'Generate, explain, and debug code with an AI assistant.' },
    { icon: Zap, title: 'Fast responses', desc: 'Server-side inference with low-latency delivery.' },
    { icon: Lock, title: 'Private by design', desc: 'API keys stay server-side. Your data is never exposed.' },
  ];
  return (
    <section className="relative py-24 overflow-hidden">
      <div className="absolute inset-0 bg-radial-glow" />
      <div className="section relative">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <SectionHeading
              eyebrow="AI Lab"
              title="Intelligence built into your workflow"
              subtitle="BLC Intelligence brings AI chat, code assistance, and research into a single secure workspace."
            />
            <div className="grid sm:grid-cols-2 gap-4">
              {features.map((f) => (
                <div key={f.title} className="glass rounded-xl p-5">
                  <f.icon className="h-6 w-6 text-secondary-400" />
                  <h4 className="mt-3 font-semibold text-white">{f.title}</h4>
                  <p className="mt-1 text-sm text-neutral-400">{f.desc}</p>
                </div>
              ))}
            </div>
            <Link to="/ai-lab" className="inline-block mt-6">
              <Button rightIcon={<ArrowRight className="h-4 w-4" />}>Open AI Lab</Button>
            </Link>
          </div>
          <div className="glass-card p-6">
            <div className="flex items-center gap-2 pb-4 border-b border-neutral-800">
              <div className="flex gap-1.5">
                <span className="h-3 w-3 rounded-full bg-error-500/60" />
                <span className="h-3 w-3 rounded-full bg-warning-500/60" />
                <span className="h-3 w-3 rounded-full bg-success-500/60" />
              </div>
              <span className="text-xs text-neutral-500 ml-2 font-mono">blc-intelligence</span>
            </div>
            <div className="space-y-4 py-4">
              <div className="flex justify-end">
                <span className="rounded-2xl rounded-br-sm bg-primary-600/30 px-4 py-2 text-sm text-white max-w-[80%]">
                  Explain how row-level security works.
                </span>
              </div>
              <div className="flex justify-start">
                <span className="rounded-2xl rounded-bl-sm glass px-4 py-2 text-sm text-neutral-200 max-w-[80%]">
                  Row Level Security restricts which rows a role can read or write, evaluated per request using policies.
                </span>
              </div>
              <div className="flex justify-end">
                <span className="rounded-2xl rounded-br-sm bg-primary-600/30 px-4 py-2 text-sm text-white max-w-[80%]">
                  Show me a policy example.
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs text-neutral-500">
                <span className="h-2 w-2 rounded-full bg-secondary-400 animate-pulse" />
                Generating response…
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function ServicesPreview() {
  const preview = SERVICES.slice(0, 6);
  const icons: Record<string, typeof Globe> = { Globe, LayoutDashboard: Globe, Smartphone: Globe, PenTool: Globe, BrainCircuit, Webhook: Globe, Database: Globe, CloudUpload: Globe, ShieldCheck, Wrench: Globe };
  return (
    <section className="section py-20">
      <SectionHeading
        center
        eyebrow="Services"
        title="Software development services"
        subtitle="From websites to AI integration, BLC offers end-to-end engineering services."
      />
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {preview.map((s) => {
          const Icon = icons[s.icon] ?? Globe;
          return (
            <Card key={s.slug} className="hover:border-secondary-400/40 transition-colors">
              <Icon className="h-6 w-6 text-secondary-400" />
              <h3 className="mt-4 font-semibold text-white">{s.name}</h3>
              <p className="mt-2 text-sm text-neutral-400 leading-relaxed">{s.description}</p>
            </Card>
          );
        })}
      </div>
      <div className="text-center mt-10">
        <Link to="/services">
          <Button variant="secondary" rightIcon={<ArrowRight className="h-4 w-4" />}>View all services</Button>
        </Link>
      </div>
    </section>
  );
}

function DeveloperPlatformPreview() {
  return (
    <section className="section py-20">
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="glass-card p-6 order-2 lg:order-1">
          <div className="font-mono text-xs text-neutral-400 space-y-1">
            <p><span className="text-success-400">$</span> curl https://api.blc.dev/v1/projects \</p>
            <p className="pl-4">-H <span className="text-secondary-300">"Authorization: Bearer blc_••••"</span></p>
            <p className="text-neutral-500">{`{`}</p>
            <p className="pl-2 text-neutral-300">"projects": [</p>
            <p className="pl-4 text-neutral-300">{`{ "id": "prj_8f2a", "name": "web-app" }`}</p>
            <p className="pl-2 text-neutral-300">]</p>
            <p className="text-neutral-500">{`}`}</p>
          </div>
        </div>
        <div className="order-1 lg:order-2">
          <SectionHeading
            eyebrow="Developer Platform"
            title="APIs, SDKs, and webhooks"
            subtitle="Integrate BLC services into your own applications with secure, documented APIs and real-time webhooks."
          />
          <ul className="space-y-3">
            {['API key management', 'Usage analytics', 'Webhook delivery with signatures', 'SDK documentation'].map((item) => (
              <li key={item} className="flex items-center gap-3 text-sm text-neutral-300">
                <CheckCircle2 className="h-5 w-5 text-success-400 shrink-0" />
                {item}
              </li>
            ))}
          </ul>
          <Link to="/developer" className="inline-block mt-6">
            <Button rightIcon={<ArrowRight className="h-4 w-4" />}>Visit Developer Center</Button>
          </Link>
        </div>
      </div>
    </section>
  );
}

function CloudPreview() {
  return (
    <section className="relative py-24 overflow-hidden">
      <div className="absolute inset-0 bg-grid-pattern bg-[size:80px_80px] opacity-20" />
      <div className="section relative text-center">
        <SectionHeading
          center
          eyebrow="Cloud"
          title="Cloud infrastructure, concepted for scale"
          subtitle="BLC Cloud is a planned infrastructure service to host applications, databases, and serverless functions with a focus on developer experience."
        />
        <div className="grid sm:grid-cols-3 gap-6 mt-12">
          {[
            { icon: Server, title: 'Managed hosting', desc: 'Deploy without managing servers.' },
            { icon: Cpu, title: 'Serverless functions', desc: 'Run code on demand, scale to zero.' },
            { icon: Globe, title: 'Edge delivery', desc: 'Serve users globally with low latency.' },
          ].map((f) => (
            <Card key={f.title}>
              <f.icon className="h-8 w-8 text-secondary-400 mx-auto" />
              <h4 className="mt-4 font-semibold text-white">{f.title}</h4>
              <p className="mt-2 text-sm text-neutral-400">{f.desc}</p>
            </Card>
          ))}
        </div>
        <Badge variant="warning" className="mt-8">Planned · In concept stage</Badge>
      </div>
    </section>
  );
}

function SecuritySection() {
  return (
    <section className="section py-20">
      <Card className="overflow-hidden">
        <div className="grid lg:grid-cols-2 gap-8 items-center">
          <div>
            <Badge variant="success"><ShieldCheck className="h-3.5 w-3.5" /> Security & Privacy</Badge>
            <h2 className="mt-4 text-3xl font-bold text-white">Security is not a feature. It is the foundation.</h2>
            <p className="mt-4 text-neutral-400 leading-relaxed">
              Every table uses Row Level Security. Privileged operations require server-side authorization.
              Secrets never reach the browser. We follow responsible disclosure and never claim certifications we do not hold.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link to="/security"><Button variant="secondary" rightIcon={<ArrowRight className="h-4 w-4" />}>Security overview</Button></Link>
              <Link to="/privacy"><Button variant="ghost">Privacy policy</Button></Link>
            </div>
          </div>
          <div className="grid gap-3">
            {[
              { icon: Lock, label: 'Row Level Security on every table' },
              { icon: Server, label: 'Server-side authorization for admin access' },
              { icon: ShieldCheck, label: 'Responsible disclosure program' },
              { icon: CheckCircle2, label: 'Input validation on every form' },
            ].map((item) => (
              <div key={item.label} className="flex items-center gap-3 glass rounded-lg p-4">
                <item.icon className="h-5 w-5 text-success-400 shrink-0" />
                <span className="text-sm text-neutral-200">{item.label}</span>
              </div>
            ))}
          </div>
        </div>
      </Card>
    </section>
  );
}

function BenefitsSection() {
  const benefits = [
    { icon: Rocket, title: 'Ship faster', desc: 'Tools and services that accelerate your development cycle.' },
    { icon: ShieldCheck, title: 'Trust by design', desc: 'Security and privacy are built in from day one.' },
    { icon: Cpu, title: 'AI-powered', desc: 'Intelligent assistance woven through the platform.' },
    { icon: Globe, title: 'Built for everyone', desc: 'Responsive, accessible, and works on any device.' },
  ];
  return (
    <section className="section py-20">
      <SectionHeading center eyebrow="Why BLC" title="Benefits that matter" />
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {benefits.map((b) => (
          <Card key={b.title} className="text-center">
            <b.icon className="h-8 w-8 text-secondary-400 mx-auto" />
            <h4 className="mt-4 font-semibold text-white">{b.title}</h4>
            <p className="mt-2 text-sm text-neutral-400">{b.desc}</p>
          </Card>
        ))}
      </div>
    </section>
  );
}

function FaqSection() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section className="section py-20">
      <SectionHeading center eyebrow="FAQ" title="Frequently asked questions" />
      <div className="max-w-3xl mx-auto space-y-3">
        {faqs.map((f, i) => (
          <Card key={i} className="!p-0 overflow-hidden">
            <button
              onClick={() => setOpen(open === i ? null : i)}
              className="w-full flex items-center justify-between p-5 text-left"
              aria-expanded={open === i}
            >
              <span className="font-semibold text-white">{f.q}</span>
              <ChevronDown className={`h-5 w-5 text-neutral-400 transition-transform ${open === i ? 'rotate-180' : ''}`} />
            </button>
            {open === i && (
              <div className="px-5 pb-5 text-sm text-neutral-400 leading-relaxed animate-fade-in">{f.a}</div>
            )}
          </Card>
        ))}
      </div>
    </section>
  );
}

function ContactCta() {
  return (
    <section className="section py-20">
      <Card className="text-center overflow-hidden relative">
        <TechBackground />
        <div className="relative">
          <h2 className="text-3xl sm:text-4xl font-bold text-white">Ready to build beyond?</h2>
          <p className="mt-4 text-neutral-400 max-w-xl mx-auto">
            Get in touch to discuss your project, request a service, or join the platform.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/contact"><Button size="lg" rightIcon={<ArrowRight className="h-5 w-5" />}>Contact us</Button></Link>
            <Link to="/signup"><Button variant="secondary" size="lg">Create an account</Button></Link>
          </div>
          {!isSupabaseConfigured && (
            <p className="mt-6 text-xs text-warning-400">
              Note: Supabase is not yet configured. Account features require configuration. See the README.
            </p>
          )}
        </div>
      </Card>
    </section>
  );
}
