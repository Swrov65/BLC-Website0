import { Code2 } from 'lucide-react';
import { AiToolChat } from '@/components/AiToolChat';

export default function AiAppBuilder() {
  return (
    <AiToolChat
      config={{
        toolType: 'app_builder',
        title: 'AI App Builder',
        description: 'Plan and generate application code and project structures',
        icon: Code2,
        placeholder: 'Describe the app you want to build, e.g. "A todo app with React and Supabase"...',
      }}
    />
  );
}
