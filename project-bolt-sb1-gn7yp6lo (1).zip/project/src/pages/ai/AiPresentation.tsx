import { Presentation } from 'lucide-react';
import { AiToolChat } from '@/components/AiToolChat';

export default function AiPresentation() {
  return (
    <AiToolChat
      config={{
        toolType: 'presentation',
        title: 'AI Presentation Maker',
        description: 'Generate presentation outlines with slide content',
        icon: Presentation,
        placeholder: 'Describe your presentation topic, e.g. "Create a 10-slide presentation about climate change"...',
      }}
    />
  );
}
