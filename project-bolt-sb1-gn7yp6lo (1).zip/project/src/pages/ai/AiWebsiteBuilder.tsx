import { Globe } from 'lucide-react';
import { AiToolChat } from '@/components/AiToolChat';

export default function AiWebsiteBuilder() {
  return (
    <AiToolChat
      config={{
        toolType: 'website_builder',
        title: 'AI Website Builder',
        description: 'Generate website layouts and code from descriptions',
        icon: Globe,
        placeholder: 'Describe the website you want to build, e.g. "A landing page for a coffee shop with hero, menu, and contact section"...',
      }}
    />
  );
}
