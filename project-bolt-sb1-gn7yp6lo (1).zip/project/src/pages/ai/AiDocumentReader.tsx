import { FileText } from 'lucide-react';
import { AiToolChat } from '@/components/AiToolChat';

export default function AiDocumentReader() {
  return (
    <AiToolChat
      config={{
        toolType: 'document',
        title: 'AI Document Reader',
        description: 'Summarize and answer questions about document text',
        icon: FileText,
        placeholder: 'Paste text from your document, then ask a question about it...',
      }}
    />
  );
}
