import { Headphones } from 'lucide-react';
import { AiToolChat } from '@/components/AiToolChat';

export default function AiSupport() {
  return (
    <AiToolChat
      config={{
        toolType: 'support',
        title: 'AI Customer Support',
        description: 'Get help with the BLC platform from an AI assistant',
        icon: Headphones,
        placeholder: 'Ask a question about BLC, e.g. "How do I create an API key?" or "How does BLC Cloud work?"...',
      }}
    />
  );
}
