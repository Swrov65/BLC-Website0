import { Calculator } from 'lucide-react';
import { AiToolChat } from '@/components/AiToolChat';

export default function AiMath() {
  return (
    <AiToolChat
      config={{
        toolType: 'math',
        title: 'AI Math Solver',
        description: 'Solve math problems with step-by-step explanations',
        icon: Calculator,
        placeholder: 'Enter a math problem, e.g. "Solve 2x + 5 = 15" or "Find the derivative of x³"...',
      }}
    />
  );
}
