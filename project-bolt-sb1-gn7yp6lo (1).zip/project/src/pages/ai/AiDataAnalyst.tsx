import { BarChart3 } from 'lucide-react';
import { AiToolChat } from '@/components/AiToolChat';

export default function AiDataAnalyst() {
  return (
    <AiToolChat
      config={{
        toolType: 'data_analyst',
        title: 'AI Data Analyst',
        description: 'Analyze data, calculate statistics, and suggest insights',
        icon: BarChart3,
        placeholder: 'Paste or describe your data, then ask for analysis...',
      }}
    />
  );
}
