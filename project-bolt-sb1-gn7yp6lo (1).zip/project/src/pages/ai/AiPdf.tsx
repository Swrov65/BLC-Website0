import { FileText } from 'lucide-react';
import { AiToolChat } from '@/components/AiToolChat';

export default function AiPdf() {
  return (
    <AiToolChat
      config={{
        toolType: 'pdf',
        title: 'AI PDF Assistant',
        description: 'Summarize and answer questions about PDF text',
        icon: FileText,
        placeholder: 'Paste text from your PDF, then ask a question about it...',
      }}
    />
  );
}
