import { Languages } from 'lucide-react';
import { AiToolChat } from '@/components/AiToolChat';

export default function AiTranslator() {
  return (
    <AiToolChat
      config={{
        toolType: 'translator',
        title: 'AI Translator',
        description: 'Translate text between languages including Bengali and English',
        icon: Languages,
        placeholder: 'Paste text to translate and specify the target language...',
      }}
    />
  );
}
