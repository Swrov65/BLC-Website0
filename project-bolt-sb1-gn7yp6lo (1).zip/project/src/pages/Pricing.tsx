import { Link } from 'react-router-dom';
import { Check, ArrowRight, Sparkles } from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Card, SectionHeading, Badge } from '@/components/ui';
import { Button } from '@/components/Button';
import { PRICING_PLANS } from '@/lib/data';

export default function Pricing() {
  return (
    <>
      <Seo title="Pricing" description="BLC pricing plans — Free, Pro, and Business. No payments collected until a provider is configured." />
      <section className="section py-16">
        <SectionHeading
          center
          eyebrow="Pricing"
          title="Simple, transparent pricing"
          subtitle="Start free. Upgrade when you need more. Payments are not collected until a payment provider is configured."
        />

        <div className="grid lg:grid-cols-3 gap-6 mt-12">
          {PRICING_PLANS.map((plan) => (
            <Card
              key={plan.id}
              className={plan.highlighted ? 'border-secondary-400/60 shadow-glow relative' : 'relative'}
            >
              {plan.highlighted && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <Badge variant="info"><Sparkles className="h-3 w-3" /> Most popular</Badge>
                </div>
              )}
              <h3 className="text-lg font-bold text-white">{plan.name}</h3>
              <div className="mt-3 flex items-baseline gap-1">
                <span className="text-4xl font-extrabold text-white">{plan.price}</span>
                <span className="text-sm text-neutral-500">/ {plan.period}</span>
              </div>
              <p className="mt-3 text-sm text-neutral-400">{plan.description}</p>
              <ul className="mt-6 space-y-3">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-sm text-neutral-300">
                    <Check className="h-4 w-4 text-success-400 shrink-0 mt-0.5" />
                    {f}
                  </li>
                ))}
              </ul>
              <Link to={plan.id === 'business' ? '/contact' : '/signup'} className="block mt-8">
                <Button
                  variant={plan.highlighted ? 'primary' : 'secondary'}
                  className="w-full"
                  rightIcon={<ArrowRight className="h-4 w-4" />}
                >
                  {plan.cta}
                </Button>
              </Link>
            </Card>
          ))}
        </div>

        <Card className="mt-10 text-center">
          <p className="text-sm text-warning-400">
            Payments are not being collected yet. Paid plans are listed for reference only.
            Subscriptions will activate once a payment provider is configured.
          </p>
        </Card>
      </section>
    </>
  );
}
