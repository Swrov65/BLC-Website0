import { useEffect, useState, useRef } from 'react';
import { Megaphone, Plus, Trash2, Upload, FileText, Image as ImageIcon, Loader2, FileCheck } from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Card, Badge, EmptyState, Spinner, StatusBadge } from '@/components/ui';
import { Button } from '@/components/Button';
import { useToast } from '@/components/Toast';
import { useAuth } from '@/auth/AuthContext';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { PRODUCTS, SERVICES } from '@/lib/data';
import type { Announcement, SiteContent } from '@/types';

const MAX_FILE_SIZE = 5 * 1024 * 1024;
const ALLOWED_FILE_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'application/pdf', 'text/plain', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];

export default function AdminContent() {
  const toast = useToast();
  const { user } = useAuth();
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [siteContents, setSiteContents] = useState<SiteContent[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [severity, setSeverity] = useState<Announcement['severity']>('info');
  const [uploading, setUploading] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<{ name: string; path: string }[]>([]);
  const [loadingFiles, setLoadingFiles] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);

  async function load() {
    if (!isSupabaseConfigured) {
      setLoading(false);
      setLoadingFiles(false);
      return;
    }
    try {
      const [ann, content] = await Promise.all([
        supabase.from('announcements').select('*').order('created_at', { ascending: false }).limit(50),
        supabase.from('site_content').select('*').order('updated_at', { ascending: false }).limit(50),
      ]);
      if (ann.error) throw ann.error;
      if (content.error) throw content.error;
      setAnnouncements((ann.data ?? []) as Announcement[]);
      setSiteContents((content.data ?? []) as SiteContent[]);
    } catch (err) {
      console.warn('Failed to load content', err);
    } finally {
      setLoading(false);
    }
  }

  async function loadFiles() {
    if (!isSupabaseConfigured) {
      setLoadingFiles(false);
      return;
    }
    try {
      const { data, error } = await supabase.storage.from('admin_uploads').list('admin', { limit: 20, sortBy: { column: 'created_at', order: 'desc' } });
      if (error) throw error;
      setUploadedFiles((data ?? []).map((f) => ({ name: f.name, path: `admin/${f.name}` })));
    } catch (err) {
      console.warn('Failed to load uploaded files', err);
    } finally {
      setLoadingFiles(false);
    }
  }

  useEffect(() => {
    void load();
    void loadFiles();
  }, []);

  async function createAnnouncement(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim() || !body.trim()) return;
    setCreating(true);
    try {
      const { data, error } = await supabase
        .from('announcements')
        .insert({ title: title.trim(), body: body.trim(), severity, published: false })
        .select('*')
        .single();
      if (error) throw error;
      await supabase.from('admin_audit_logs').insert({ action: 'create_announcement', target_id: (data as Announcement).id, details: `Created: ${title}` });
      setAnnouncements((prev) => [data as Announcement, ...prev]);
      setTitle('');
      setBody('');
      toast.push({ title: 'Announcement created', variant: 'success' });
    } catch (err) {
      toast.push({ title: 'Create failed', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    } finally {
      setCreating(false);
    }
  }

  async function togglePublish(a: Announcement) {
    try {
      const { error } = await supabase.from('announcements').update({ published: !a.published }).eq('id', a.id);
      if (error) throw error;
      setAnnouncements((prev) => prev.map((x) => (x.id === a.id ? { ...x, published: !x.published } : x)));
      toast.push({ title: a.published ? 'Unpublished' : 'Published', variant: 'success' });
    } catch (err) {
      toast.push({ title: 'Update failed', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    }
  }

  async function deleteAnnouncement(id: string) {
    try {
      const { error } = await supabase.from('announcements').delete().eq('id', id);
      if (error) throw error;
      setAnnouncements((prev) => prev.filter((a) => a.id !== id));
      toast.push({ title: 'Announcement deleted', variant: 'success' });
    } catch (err) {
      toast.push({ title: 'Delete failed', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    }
  }

  async function handleFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    if (file.size > MAX_FILE_SIZE) {
      toast.push({ title: 'File too large', description: 'Maximum file size is 5MB.', variant: 'warning' });
      return;
    }
    if (!ALLOWED_FILE_TYPES.includes(file.type)) {
      toast.push({ title: 'File type not allowed', description: 'Allowed: JPG, PNG, WebP, GIF, PDF, TXT, DOC, DOCX.', variant: 'warning' });
      return;
    }
    setUploading(true);
    try {
      const ext = file.name.split('.').pop() ?? 'bin';
      const fileName = `${crypto.randomUUID()}.${ext}`;
      const path = `admin/${fileName}`;
      const { error: upErr } = await supabase.storage.from('admin_uploads').upload(path, file, { contentType: file.type });
      if (upErr) throw upErr;
      await supabase.from('admin_audit_logs').insert({ action: 'upload_file', target_id: path, details: `Uploaded: ${file.name}` });
      setUploadedFiles((prev) => [{ name: fileName, path }, ...prev]);
      toast.push({ title: 'File uploaded', description: file.name, variant: 'success' });
    } catch (err) {
      toast.push({ title: 'Upload failed', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  }

  async function deleteFile(path: string, name: string) {
    try {
      const { error } = await supabase.storage.from('admin_uploads').remove([path]);
      if (error) throw error;
      await supabase.from('admin_audit_logs').insert({ action: 'delete_file', target_id: path, details: `Deleted: ${name}` });
      setUploadedFiles((prev) => prev.filter((f) => f.path !== path));
      toast.push({ title: 'File deleted', variant: 'success' });
    } catch (err) {
      toast.push({ title: 'Delete failed', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    }
  }

  async function getSignedUrl(path: string) {
    try {
      const { data, error } = await supabase.storage.from('admin_uploads').createSignedUrl(path, 300);
      if (error) throw error;
      if (data?.signedUrl) window.open(data.signedUrl, '_blank');
    } catch (err) {
      toast.push({ title: 'Could not generate link', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    }
  }

  return (
    <>
      <Seo title="Admin — Content" />
      <h1 className="text-2xl font-bold text-white mb-6">Content Management</h1>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* File Uploads */}
          <Card>
            <div className="flex items-center gap-3 mb-4">
              <Upload className="h-5 w-5 text-accent-400" />
              <h2 className="font-semibold text-white">File uploads</h2>
            </div>
            <div className="flex items-center gap-4">
              <label className="cursor-pointer">
                <input ref={fileInputRef} type="file" className="hidden" onChange={handleFileUpload} disabled={uploading || !isSupabaseConfigured} />
                <Button variant="secondary" size="sm" leftIcon={uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />} disabled={uploading || !isSupabaseConfigured}>
                  {uploading ? 'Uploading...' : 'Upload file'}
                </Button>
              </label>
              <p className="text-xs text-neutral-500">Max 5MB. JPG, PNG, WebP, GIF, PDF, TXT, DOC, DOCX.</p>
            </div>

            {loadingFiles ? (
              <div className="flex justify-center py-6"><Spinner className="h-5 w-5" /></div>
            ) : uploadedFiles.length === 0 ? (
              <div className="mt-4">
                <EmptyState icon={<FileCheck className="h-8 w-8" />} title="No files uploaded" description="Upload images or documents for use across the site." />
              </div>
            ) : (
              <div className="mt-4 space-y-2">
                {uploadedFiles.map((f) => (
                  <div key={f.path} className="flex items-center justify-between rounded-lg p-3 bg-blc-navy-700/40">
                    <div className="flex items-center gap-2 min-w-0">
                      {f.name.match(/\.(jpg|jpeg|png|webp|gif)$/i) ? (
                        <ImageIcon className="h-4 w-4 text-secondary-400 shrink-0" />
                      ) : (
                        <FileText className="h-4 w-4 text-accent-400 shrink-0" />
                      )}
                      <span className="text-sm text-neutral-300 truncate font-mono">{f.name}</span>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <Button size="sm" variant="ghost" onClick={() => void getSignedUrl(f.path)}>View</Button>
                      <button onClick={() => void deleteFile(f.path, f.name)} className="p-2 text-neutral-400 hover:text-error-400 transition-colors" aria-label="Delete file">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>

          {/* Products catalog */}
          <Card>
            <h2 className="font-semibold text-white mb-4">Products catalog</h2>
            <div className="space-y-2">
              {PRODUCTS.map((p) => (
                <div key={p.id} className="flex items-center justify-between rounded-lg p-3 bg-blc-navy-700/40">
                  <div>
                    <p className="text-sm font-medium text-white">{p.name}</p>
                    <p className="text-xs text-neutral-500">{p.slug}</p>
                  </div>
                  <StatusBadge status={p.availability} />
                </div>
              ))}
            </div>
            <p className="mt-4 text-xs text-neutral-500">Product catalog is defined in application code. Availability labels are honest and not editable from the UI.</p>
          </Card>

          {/* Services catalog */}
          <Card>
            <h2 className="font-semibold text-white mb-4">Services catalog</h2>
            <div className="grid sm:grid-cols-2 gap-2">
              {SERVICES.map((s) => (
                <div key={s.slug} className="rounded-lg p-3 bg-blc-navy-700/40">
                  <p className="text-sm font-medium text-white">{s.name}</p>
                  <p className="text-xs text-neutral-500">{s.slug}</p>
                </div>
              ))}
            </div>
          </Card>

          {/* Announcements */}
          <Card>
            <h2 className="font-semibold text-white mb-4">Announcements</h2>
            {loading ? (
              <div className="flex justify-center py-8"><Spinner className="h-5 w-5" /></div>
            ) : announcements.length === 0 ? (
              <EmptyState icon={<Megaphone className="h-8 w-8" />} title="No announcements" description="Create one to publish to the developer center." />
            ) : (
              <div className="space-y-2">
                {announcements.map((a) => (
                  <div key={a.id} className="rounded-lg p-3 bg-blc-navy-700/40">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-medium text-white">{a.title}</h4>
                          <Badge variant={a.severity === 'critical' ? 'error' : a.severity === 'warning' ? 'warning' : 'info'}>{a.severity}</Badge>
                          <Badge variant={a.published ? 'success' : 'neutral'}>{a.published ? 'Published' : 'Draft'}</Badge>
                        </div>
                        <p className="mt-1 text-xs text-neutral-400">{a.body}</p>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <Button size="sm" variant="ghost" onClick={() => void togglePublish(a)}>{a.published ? 'Unpublish' : 'Publish'}</Button>
                        <button onClick={() => void deleteAnnouncement(a.id)} className="p-2 text-neutral-400 hover:text-error-400 transition-colors" aria-label="Delete">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>

        <div className="lg:col-span-1">
          {/* New announcement form */}
          <Card>
            <div className="flex items-center gap-3 mb-4">
              <Plus className="h-5 w-5 text-accent-400" />
              <h2 className="font-semibold text-white">New announcement</h2>
            </div>
            <form onSubmit={createAnnouncement} className="space-y-4">
              <div>
                <label className="label" htmlFor="atitle">Title</label>
                <input id="atitle" className="input" value={title} onChange={(e) => setTitle(e.target.value)} required />
              </div>
              <div>
                <label className="label" htmlFor="abody">Body</label>
                <textarea id="abody" rows={4} className="input resize-y" value={body} onChange={(e) => setBody(e.target.value)} required />
              </div>
              <div>
                <label className="label" htmlFor="asev">Severity</label>
                <select id="asev" className="input" value={severity} onChange={(e) => setSeverity(e.target.value as Announcement['severity'])}>
                  <option value="info">Info</option>
                  <option value="warning">Warning</option>
                  <option value="critical">Critical</option>
                </select>
              </div>
              <Button type="submit" loading={creating} className="w-full">Create as draft</Button>
            </form>
          </Card>

          {!isSupabaseConfigured && (
            <Card className="mt-4 border-warning-500/20">
              <p className="text-sm text-warning-300">Announcements and file uploads require Supabase to persist.</p>
            </Card>
          )}
        </div>
      </div>
    </>
  );
}
