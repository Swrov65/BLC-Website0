import { useEffect, useState } from 'react';
import { MessageSquare, Mail, Archive, Eye } from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Card, Badge, EmptyState, Spinner } from '@/components/ui';
import { Button } from '@/components/Button';
import { useToast } from '@/components/Toast';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import type { ContactSubmission } from '@/types';

export default function AdminContact() {
  const toast = useToast();
  const [items, setItems] = useState<ContactSubmission[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<ContactSubmission | null>(null);

  async function load() {
    if (!isSupabaseConfigured) {
      setLoading(false);
      return;
    }
    try {
      const { data, error } = await supabase
        .from('contact_submissions')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);
      if (error) throw error;
      setItems((data ?? []) as ContactSubmission[]);
    } catch (err) {
      console.warn('Failed to load contact submissions', err);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  async function updateStatus(id: string, status: ContactSubmission['status']) {
    try {
      const { error } = await supabase.from('contact_submissions').update({ status }).eq('id', id);
      if (error) throw error;
      await supabase.from('admin_audit_logs').insert({ action: 'update_contact_status', target_id: id, details: `Status set to ${status}` });
      setItems((prev) => prev.map((i) => (i.id === id ? { ...i, status } : i)));
      if (selected?.id === id) setSelected((prev) => prev ? { ...prev, status } : prev);
      toast.push({ title: 'Status updated', variant: 'success' });
    } catch (err) {
      toast.push({ title: 'Update failed', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    }
  }

  const statusVariant = (s: ContactSubmission['status']) =>
    s === 'new' ? 'info' : s === 'read' ? 'warning' : s === 'responded' ? 'success' : 'neutral';

  return (
    <>
      <Seo title="Admin — Contact" />
      <h1 className="text-2xl font-bold text-white mb-6">Contact Submissions</h1>

      {!isSupabaseConfigured && (
        <Card className="mb-6 border-warning-500/20">
          <p className="text-sm text-warning-300">Backend not configured. Contact submissions require Supabase.</p>
        </Card>
      )}

      {loading ? (
        <div className="flex justify-center py-12"><Spinner className="h-6 w-6" /></div>
      ) : items.length === 0 ? (
        <Card>
          <EmptyState icon={<MessageSquare className="h-10 w-10" />} title="No submissions" description="Contact form submissions will appear here." />
        </Card>
      ) : (
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-3">
            {items.map((i) => (
              <Card key={i.id} className="!py-4 cursor-pointer hover:border-accent-400/40 transition-colors" onClick={() => { setSelected(i); if (i.status === 'new') void updateStatus(i.id, 'read'); }}>
                <div className="flex items-start justify-between gap-4">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-white truncate">{i.subject}</h3>
                      <Badge variant={statusVariant(i.status)}>{i.status}</Badge>
                    </div>
                    <p className="mt-1 text-xs text-neutral-500">{i.name} · {i.email}</p>
                    <p className="mt-1 text-sm text-neutral-400 line-clamp-2">{i.message}</p>
                    <p className="mt-2 text-xs text-neutral-500">{new Date(i.created_at).toLocaleString()}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          <div className="lg:col-span-1">
            {selected ? (
              <Card>
                <h3 className="font-semibold text-white">{selected.subject}</h3>
                <div className="mt-3 space-y-2 text-sm">
                  <p className="text-neutral-400"><span className="text-neutral-500">From:</span> {selected.name}</p>
                  <p className="text-neutral-400"><span className="text-neutral-500">Email:</span> {selected.email}</p>
                  <p className="text-neutral-400"><span className="text-neutral-500">Date:</span> {new Date(selected.created_at).toLocaleString()}</p>
                </div>
                <div className="mt-4 rounded-lg bg-blc-navy-700/40 p-4 text-sm text-neutral-300 whitespace-pre-wrap">{selected.message}</div>
                <div className="mt-4 flex flex-wrap gap-2">
                  <Button size="sm" variant="secondary" leftIcon={<Mail className="h-3.5 w-3.5" />} onClick={() => void updateStatus(selected.id, 'responded')}>Mark responded</Button>
                  <Button size="sm" variant="ghost" leftIcon={<Archive className="h-3.5 w-3.5" />} onClick={() => void updateStatus(selected.id, 'archived')}>Archive</Button>
                </div>
              </Card>
            ) : (
              <Card>
                <EmptyState icon={<Eye className="h-8 w-8" />} title="Select a submission" description="Click a submission to view details." />
              </Card>
            )}
          </div>
        </div>
      )}
    </>
  );
}
