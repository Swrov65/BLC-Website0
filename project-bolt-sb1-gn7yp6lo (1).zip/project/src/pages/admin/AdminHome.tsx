import { useEffect, useState } from 'react';
import { Users, MessageSquare, FolderKanban, ScrollText, Activity, AlertCircle, ShieldCheck } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Seo } from '@/components/Seo';
import { Card, Badge, EmptyState, Spinner } from '@/components/ui';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';

export default function AdminHome() {
  const [stats, setStats] = useState({ users: 0, contacts: 0, projects: 0, auditLogs: 0 });
  const [recentUsers, setRecentUsers] = useState<{ id: string; email: string | null; display_name: string | null; created_at: string; role: string; suspended: boolean }[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isSupabaseConfigured) {
      setLoading(false);
      return;
    }
    (async () => {
      try {
        const [u, c, p, a, ru] = await Promise.all([
          supabase.from('profiles').select('id', { count: 'exact', head: true }),
          supabase.from('contact_submissions').select('id', { count: 'exact', head: true }),
          supabase.from('projects').select('id', { count: 'exact', head: true }),
          supabase.from('admin_audit_logs').select('id', { count: 'exact', head: true }),
          supabase.from('profiles').select('id, email, display_name, created_at, role, suspended').order('created_at', { ascending: false }).limit(5),
        ]);
        setStats({
          users: u.count ?? 0,
          contacts: c.count ?? 0,
          projects: p.count ?? 0,
          auditLogs: a.count ?? 0,
        });
        setRecentUsers((ru.data ?? []) as typeof recentUsers);
      } catch (err) {
        console.warn('Failed to load admin stats', err);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  return (
    <>
      <Seo title="Admin Overview" />
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white">Admin Dashboard</h1>
        <p className="mt-1 text-sm text-neutral-400">Platform overview and administrative controls.</p>
      </div>

      {!isSupabaseConfigured && (
        <Card className="mb-6 border-warning-500/30">
          <div className="flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-warning-400 shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-warning-300">Backend not configured</h3>
              <p className="mt-1 text-sm text-neutral-400">
                Admin operations require Supabase with RLS policies and an admin role assigned server-side.
                Until configured, statistics show zero and management actions are disabled.
              </p>
            </div>
          </div>
        </Card>
      )}

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Total users', value: stats.users, icon: Users, to: '/admin/users' },
          { label: 'Contact submissions', value: stats.contacts, icon: MessageSquare, to: '/admin/contact' },
          { label: 'Projects', value: stats.projects, icon: FolderKanban, to: '/admin/content' },
          { label: 'Audit log entries', value: stats.auditLogs, icon: ScrollText, to: '/admin/audit' },
        ].map((s) => (
          <Link key={s.label} to={s.to}>
            <Card className="hover:border-accent-400/40 transition-colors">
              <div className="flex items-center justify-between">
                <s.icon className="h-6 w-6 text-accent-400" />
                {loading ? <Spinner className="h-4 w-4" /> : <span className="text-2xl font-bold text-white">{s.value}</span>}
              </div>
              <p className="mt-3 text-sm text-neutral-400">{s.label}</p>
            </Card>
          </Link>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6 mt-8">
        <Card>
          <div className="flex items-center gap-3 mb-4">
            <Activity className="h-5 w-5 text-accent-400" />
            <h2 className="font-semibold text-white">Recent registrations</h2>
          </div>
          {recentUsers.length === 0 ? (
            <EmptyState title="No users yet" description="New registrations will appear here." />
          ) : (
            <div className="space-y-2">
              {recentUsers.map((u) => (
                <div key={u.id} className="flex items-center justify-between rounded-lg p-3 bg-blc-navy-700/40">
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-white truncate">{u.display_name ?? u.email ?? 'Unknown'}</p>
                    <p className="text-xs text-neutral-500">{u.email}</p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <Badge variant={u.role === 'admin' ? 'accent' : 'neutral'}>{u.role}</Badge>
                    {u.suspended && <Badge variant="error">Suspended</Badge>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        <Card>
          <div className="flex items-center gap-3 mb-4">
            <ShieldCheck className="h-5 w-5 text-accent-400" />
            <h2 className="font-semibold text-white">Service health</h2>
          </div>
          <div className="space-y-2">
            {[
              { name: 'Website', status: 'Operational' },
              { name: 'Authentication', status: isSupabaseConfigured ? 'Operational' : 'Not configured' },
              { name: 'Database', status: isSupabaseConfigured ? 'Operational' : 'Not configured' },
              { name: 'AI Lab', status: 'Requires provider key' },
            ].map((s) => (
              <div key={s.name} className="flex items-center justify-between rounded-lg p-3 bg-blc-navy-700/40">
                <span className="text-sm text-neutral-300">{s.name}</span>
                <Badge variant={s.status === 'Operational' ? 'success' : 'warning'}>{s.status}</Badge>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </>
  );
}
