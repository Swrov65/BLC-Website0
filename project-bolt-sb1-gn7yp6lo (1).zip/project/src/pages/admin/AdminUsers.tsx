import { useEffect, useState, useMemo } from 'react';
import { Search, Users, ShieldCheck, Ban, RotateCcw } from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Card, Badge, EmptyState, Spinner } from '@/components/ui';
import { Button } from '@/components/Button';
import { useToast } from '@/components/Toast';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import type { Profile } from '@/types';

type Row = Profile;

export default function AdminUsers() {
  const toast = useToast();
  const [users, setUsers] = useState<Row[]>([]);
  const [adminIds, setAdminIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<'all' | 'admin' | 'suspended' | 'active'>('all');
  const [acting, setActing] = useState<string | null>(null);

  async function load() {
    if (!isSupabaseConfigured) {
      setLoading(false);
      return;
    }
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);
      if (error) throw error;
      const profiles = (data ?? []) as Row[];
      setUsers(profiles);

      // Get admin user IDs via the dedicated SECURITY DEFINER function
      const { data: adminData, error: adminErr } = await supabase.rpc('get_admin_user_ids');
      if (!adminErr && adminData) {
        setAdminIds(new Set((adminData as { user_id: string }[]).map((r) => r.user_id)));
      }
    } catch (err) {
      console.warn('Failed to load users', err);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  const filtered = useMemo(() => {
    let list = users;
    if (filter === 'admin') list = list.filter((u) => adminIds.has(u.id));
    else if (filter === 'suspended') list = list.filter((u) => u.suspended);
    else if (filter === 'active') list = list.filter((u) => !u.suspended);
    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter((u) => (u.email ?? '').toLowerCase().includes(q) || (u.display_name ?? '').toLowerCase().includes(q));
    }
    return list;
  }, [users, filter, query, adminIds]);

  async function toggleSuspend(targetUser: Row) {
    setActing(targetUser.id);
    try {
      const newSuspended = !targetUser.suspended;
      const { error } = await supabase.from('profiles').update({ suspended: newSuspended }).eq('id', targetUser.id);
      if (error) throw error;
      await supabase.from('admin_audit_logs').insert({
        action: newSuspended ? 'suspend_user' : 'restore_user',
        target_id: targetUser.id,
        details: `User ${targetUser.email} ${newSuspended ? 'suspended' : 'restored'}`,
      });
      setUsers((prev) => prev.map((u) => (u.id === targetUser.id ? { ...u, suspended: newSuspended } : u)));
      toast.push({ title: newSuspended ? 'User suspended' : 'User restored', variant: 'success' });
    } catch (err) {
      toast.push({ title: 'Action failed', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    } finally {
      setActing(null);
    }
  }

  return (
    <>
      <Seo title="Admin — Users" />
      <h1 className="text-2xl font-bold text-white mb-6">User Management</h1>

      {!isSupabaseConfigured && (
        <Card className="mb-6 border-warning-500/20">
          <p className="text-sm text-warning-300">Backend not configured. User management requires Supabase with admin policies.</p>
        </Card>
      )}

      <Card className="mb-6">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-500" />
            <input className="input pl-10" placeholder="Search by name or email..." value={query} onChange={(e) => setQuery(e.target.value)} />
          </div>
          <select className="input sm:w-48" value={filter} onChange={(e) => setFilter(e.target.value as typeof filter)}>
            <option value="all">All users</option>
            <option value="active">Active</option>
            <option value="suspended">Suspended</option>
            <option value="admin">Admins</option>
          </select>
        </div>
      </Card>

      {loading ? (
        <div className="flex justify-center py-12"><Spinner className="h-6 w-6" /></div>
      ) : filtered.length === 0 ? (
        <Card>
          <EmptyState
            icon={<Users className="h-10 w-10" />}
            title="No users found"
            description={users.length === 0 ? 'No users have registered yet.' : 'Try adjusting your search or filter.'}
          />
        </Card>
      ) : (
        <Card className="!p-0 overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-neutral-800 text-left text-xs uppercase tracking-wider text-neutral-500">
                <th className="px-4 py-3 font-medium">User</th>
                <th className="px-4 py-3 font-medium">Role</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3 font-medium">Joined</th>
                <th className="px-4 py-3 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((u) => {
                const isAdmin = adminIds.has(u.id);
                return (
                  <tr key={u.id} className="border-b border-neutral-800/50 last:border-0">
                    <td className="px-4 py-3">
                      <p className="font-medium text-white">{u.display_name ?? 'Unknown'}</p>
                      <p className="text-xs text-neutral-500">{u.email}</p>
                    </td>
                    <td className="px-4 py-3"><Badge variant={isAdmin ? 'accent' : 'neutral'}>{isAdmin ? 'admin' : 'user'}</Badge></td>
                    <td className="px-4 py-3"><Badge variant={u.suspended ? 'error' : 'success'}>{u.suspended ? 'Suspended' : 'Active'}</Badge></td>
                    <td className="px-4 py-3 text-neutral-400 text-xs">{new Date(u.created_at).toLocaleDateString()}</td>
                    <td className="px-4 py-3 text-right">
                      {!isAdmin && (
                        <Button
                          size="sm"
                          variant="ghost"
                          loading={acting === u.id}
                          leftIcon={!u.suspended ? <Ban className="h-3.5 w-3.5" /> : <RotateCcw className="h-3.5 w-3.5" />}
                          onClick={() => void toggleSuspend(u)}
                        >
                          {u.suspended ? 'Restore' : 'Suspend'}
                        </Button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </Card>
      )}

      <Card className="mt-6 border-accent-500/20">
        <div className="flex items-start gap-3">
          <ShieldCheck className="h-5 w-5 text-accent-400 shrink-0 mt-0.5" />
          <p className="text-sm text-neutral-300">
            Admin role is assigned server-side via the JWT claim and cannot be changed from this panel.
            Suspension and restoration are enforced by RLS policies and logged to the audit trail.
          </p>
        </div>
      </Card>
    </>
  );
}
