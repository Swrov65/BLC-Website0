import { useEffect, useState } from 'react';
import { Settings, Save, AlertTriangle, ToggleLeft, ToggleRight } from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Card, Badge } from '@/components/ui';
import { Button } from '@/components/Button';
import { useToast } from '@/components/Toast';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';

type SettingsMap = Record<string, string | boolean>;

export default function AdminSettings() {
  const toast = useToast();
  const [settings, setSettings] = useState<SettingsMap>({
    registration_open: true,
    maintenance_mode: false,
    promotional_banner_enabled: false,
    promotional_banner_text: '',
    ai_lab_enabled: true,
    developer_platform_enabled: true,
  });
  const [saving, setSaving] = useState(false);

  async function load() {
    if (!isSupabaseConfigured) {
      return;
    }
    try {
      const { data, error } = await supabase.from('platform_settings').select('key, value');
      if (error) throw error;
      if (data) {
        const map: SettingsMap = {};
        for (const row of data as { key: string; value: string }[]) {
          if (row.value === 'true') map[row.key] = true;
          else if (row.value === 'false') map[row.key] = false;
          else map[row.key] = row.value;
        }
        setSettings((prev) => ({ ...prev, ...map }));
      }
    } catch (err) {
      console.warn('Failed to load settings', err);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  async function save() {
    setSaving(true);
    try {
      if (!isSupabaseConfigured) {
        toast.push({ title: 'Backend not configured', description: 'Settings cannot be persisted without Supabase.', variant: 'warning' });
        setSaving(false);
        return;
      }
      const rows = Object.entries(settings).map(([key, value]) => ({ key, value: String(value) }));
      const { error } = await supabase.from('platform_settings').upsert(rows, { onConflict: 'key' });
      if (error) throw error;
      await supabase.from('admin_audit_logs').insert({ action: 'update_settings', details: 'Platform settings updated' });
      toast.push({ title: 'Settings saved', variant: 'success' });
    } catch (err) {
      toast.push({ title: 'Save failed', description: err instanceof Error ? err.message : 'Unknown error', variant: 'error' });
    } finally {
      setSaving(false);
    }
  }

  function toggle(key: string) {
    setSettings((prev) => ({ ...prev, [key]: !prev[key] }));
  }

  const toggles: { key: keyof typeof settings; label: string; desc: string }[] = [
    { key: 'registration_open', label: 'Registration open', desc: 'Allow new users to sign up.' },
    { key: 'maintenance_mode', label: 'Maintenance mode', desc: 'Show a maintenance banner across the site.' },
    { key: 'promotional_banner_enabled', label: 'Promotional banner', desc: 'Show a promotional banner. Disabled by default.' },
    { key: 'ai_lab_enabled', label: 'AI Lab enabled', desc: 'Allow users to access the AI Lab UI.' },
    { key: 'developer_platform_enabled', label: 'Developer Platform enabled', desc: 'Allow API key creation.' },
  ];

  return (
    <>
      <Seo title="Admin — Settings" />
      <h1 className="text-2xl font-bold text-white mb-6">Platform Settings</h1>

      {!isSupabaseConfigured && (
        <Card className="mb-6 border-warning-500/30">
          <div className="flex items-start gap-3">
            <AlertTriangle className="h-5 w-5 text-warning-400 shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-warning-300">Backend not configured</h3>
              <p className="mt-1 text-sm text-neutral-400">
                These controls are shown for demonstration. Without Supabase, changes are not saved.
                Promotional content is disabled by default.
              </p>
            </div>
          </div>
        </Card>
      )}

      <div className="space-y-6 max-w-2xl">
        <Card>
          <div className="flex items-center gap-3 mb-4">
            <Settings className="h-5 w-5 text-accent-400" />
            <h2 className="font-semibold text-white">Feature flags</h2>
          </div>
          <div className="space-y-3">
            {toggles.map((t) => (
              <div key={t.key} className="flex items-center justify-between rounded-lg p-3 bg-blc-navy-700/40">
                <div>
                  <p className="text-sm font-medium text-white">{t.label}</p>
                  <p className="text-xs text-neutral-500">{t.desc}</p>
                </div>
                <button onClick={() => toggle(t.key)} className="text-secondary-400 hover:text-secondary-300" aria-label={`Toggle ${t.label}`}>
                  {settings[t.key] ? <ToggleRight className="h-7 w-7" /> : <ToggleLeft className="h-7 w-7 text-neutral-600" />}
                </button>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <h2 className="font-semibold text-white mb-4">Promotional content</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between rounded-lg p-3 bg-blc-navy-700/40">
              <div>
                <p className="text-sm font-medium text-white">Enable promotional banner</p>
                <p className="text-xs text-neutral-500">Off by default. Only enable when you have something to promote.</p>
              </div>
              <Badge variant={settings.promotional_banner_enabled ? 'success' : 'neutral'}>
                {settings.promotional_banner_enabled ? 'Enabled' : 'Disabled'}
              </Badge>
            </div>
            <div>
              <label className="label" htmlFor="banner">Banner text</label>
              <input id="banner" className="input" value={settings.promotional_banner_text as string} onChange={(e) => setSettings((prev) => ({ ...prev, promotional_banner_text: e.target.value }))} placeholder="Announce something..." />
            </div>
          </div>
        </Card>

        <Button loading={saving} leftIcon={!saving ? <Save className="h-4 w-4" /> : undefined} onClick={save}>
          Save settings
        </Button>
      </div>
    </>
  );
}
