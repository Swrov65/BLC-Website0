import { useEffect, useState } from 'react';
import { ScrollText, ShieldAlert, Search } from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Card, EmptyState, Spinner } from '@/components/ui';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';

type AuditLog = {
  id: string;
  admin_id: string | null;
  action: string;
  target_id: string | null;
  details: string | null;
  created_at: string;
};

export default function AdminAudit() {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');

  async function load() {
    if (!isSupabaseConfigured) {
      setLoading(false);
      return;
    }
    try {
      const { data, error } = await supabase
        .from('admin_audit_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(200);
      if (error) throw error;
      setLogs((data ?? []) as AuditLog[]);
    } catch (err) {
      console.warn('Failed to load audit logs', err);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  const filtered = query.trim()
    ? logs.filter((l) => l.action.toLowerCase().includes(query.toLowerCase()) || (l.details ?? '').toLowerCase().includes(query.toLowerCase()))
    : logs;

  return (
    <>
      <Seo title="Admin — Audit Logs" />
      <h1 className="text-2xl font-bold text-white mb-6">Security & Audit Logs</h1>

      {!isSupabaseConfigured && (
        <Card className="mb-6 border-warning-500/20">
          <p className="text-sm text-warning-300">Backend not configured. Audit logs require Supabase.</p>
        </Card>
      )}

      <Card className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-500" />
          <input className="input pl-10" placeholder="Search logs by action or details..." value={query} onChange={(e) => setQuery(e.target.value)} />
        </div>
      </Card>

      {loading ? (
        <div className="flex justify-center py-12"><Spinner className="h-6 w-6" /></div>
      ) : filtered.length === 0 ? (
        <Card>
          <EmptyState
            icon={<ScrollText className="h-10 w-10" />}
            title="No audit log entries"
            description="Administrative actions will be recorded here."
          />
        </Card>
      ) : (
        <Card className="!p-0 overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-neutral-800 text-left text-xs uppercase tracking-wider text-neutral-500">
                <th className="px-4 py-3 font-medium">Action</th>
                <th className="px-4 py-3 font-medium">Details</th>
                <th className="px-4 py-3 font-medium">Target</th>
                <th className="px-4 py-3 font-medium">Date</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((l) => (
                <tr key={l.id} className="border-b border-neutral-800/50 last:border-0">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <ShieldAlert className="h-3.5 w-3.5 text-accent-400" />
                      <code className="text-secondary-300 text-xs">{l.action}</code>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-neutral-400">{l.details ?? '—'}</td>
                  <td className="px-4 py-3 text-neutral-500 font-mono text-xs">{l.target_id ?? '—'}</td>
                  <td className="px-4 py-3 text-neutral-400 text-xs">{new Date(l.created_at).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      <Card className="mt-6 border-accent-500/20">
        <div className="flex items-start gap-3">
          <ShieldAlert className="h-5 w-5 text-accent-400 shrink-0 mt-0.5" />
          <p className="text-sm text-neutral-300">
            All privileged admin actions — user suspension, role changes, settings updates, content moderation —
            are recorded in this audit log. Logs are enforced server-side and cannot be modified from the frontend.
          </p>
        </div>
      </Card>
    </>
  );
}
