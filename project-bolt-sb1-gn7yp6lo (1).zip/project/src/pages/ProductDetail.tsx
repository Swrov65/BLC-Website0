import { Link, useParams } from 'react-router-dom';
import {
  ArrowLeft, ArrowRight, CheckCircle2, BookOpen, Code2, BrainCircuit, Cloud, ShieldCheck, Terminal, AppWindow,
} from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Card, Badge, StatusBadge, EmptyState } from '@/components/ui';
import { Button } from '@/components/Button';
import { PRODUCTS } from '@/lib/data';

const productIcons: Record<string, typeof BrainCircuit> = {
  BrainCircuit, Code2, Cloud, AppWindow, Terminal, ShieldCheck,
};

export default function ProductDetail() {
  const { slug } = useParams<{ slug: string }>();
  const product = PRODUCTS.find((p) => p.slug === slug);

  if (!product) {
    return (
      <section className="section py-20">
        <EmptyState
          icon={<Code2 className="h-10 w-10" />}
          title="Product not found"
          description="The product you are looking for does not exist."
          action={<Link to="/products"><Button>Back to products</Button></Link>}
        />
      </section>
    );
  }

  const Icon = productIcons[product.icon] ?? Code2;

  return (
    <>
      <Seo title={product.name} description={product.tagline} />
      <section className="section py-12">
        <Link to="/products" className="inline-flex items-center gap-2 text-sm text-neutral-400 hover:text-secondary-400 transition-colors">
          <ArrowLeft className="h-4 w-4" /> All products
        </Link>

        <div className="mt-8 grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <Card>
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-gradient-to-br from-secondary-500/20 to-accent-500/20 border border-secondary-500/30">
                    <Icon className="h-7 w-7 text-secondary-400" />
                  </div>
                  <div>
                    <h1 className="text-2xl font-bold text-white">{product.name}</h1>
                    <p className="text-sm text-neutral-400">{product.tagline}</p>
                  </div>
                </div>
                <StatusBadge status={product.availability} />
              </div>
              <p className="mt-6 text-neutral-300 leading-relaxed">{product.description}</p>
            </Card>

            <Card>
              <h2 className="text-lg font-bold text-white">Features</h2>
              <ul className="mt-4 grid sm:grid-cols-2 gap-3">
                {product.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-sm text-neutral-300">
                    <CheckCircle2 className="h-5 w-5 text-success-400 shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
            </Card>

            <Card>
              <h2 className="text-lg font-bold text-white">Use cases</h2>
              <ul className="mt-4 space-y-3">
                {product.use_cases.map((u) => (
                  <li key={u} className="flex items-start gap-2 text-sm text-neutral-300">
                    <ArrowRight className="h-4 w-4 text-secondary-400 shrink-0 mt-0.5" />
                    {u}
                  </li>
                ))}
              </ul>
            </Card>

            <Card>
              <h2 className="text-lg font-bold text-white">Illustration</h2>
              <div className="mt-4 rounded-xl bg-blc-navy-700/50 border border-neutral-800 p-8 flex items-center justify-center min-h-[200px]">
                <div className="text-center">
                  <Icon className="h-16 w-16 text-secondary-400/60 mx-auto" />
                  <p className="mt-3 text-xs text-neutral-500 font-mono">{product.slug}.preview</p>
                </div>
              </div>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <h3 className="font-semibold text-white">Availability</h3>
              <div className="mt-3"><StatusBadge status={product.availability} /></div>
              {product.availability !== 'live' && (
                <p className="mt-3 text-xs text-neutral-500">
                  This product is {product.availability === 'planned' ? 'in the planning stage' : 'under active development'}.
                  We do not claim it is ready for production use.
                </p>
              )}
            </Card>

            <Card>
              <h3 className="font-semibold text-white">Get started</h3>
              <p className="mt-2 text-sm text-neutral-400">
                {product.availability === 'live'
                  ? 'This product is available. Sign up to begin.'
                  : 'Sign up to be notified when this product becomes available.'}
              </p>
              <Link to="/signup" className="block mt-4">
                <Button className="w-full" rightIcon={<ArrowRight className="h-4 w-4" />}>Get Started</Button>
              </Link>
              {product.docs_url && (
                <Link to={product.docs_url} className="block mt-2">
                  <Button variant="secondary" className="w-full" leftIcon={<BookOpen className="h-4 w-4" />}>Documentation</Button>
                </Link>
              )}
            </Card>

            <Card>
              <h3 className="font-semibold text-white">Status</h3>
              <div className="mt-3 flex items-center gap-2 text-sm text-neutral-400">
                <Badge variant="info">Platform</Badge>
                <span>BLC Suite</span>
              </div>
            </Card>
          </div>
        </div>
      </section>
    </>
  );
}
