import { Link } from 'react-router-dom';
import { ShieldCheck, Lock, Server, Bug, FileText, ArrowRight, KeyRound, Database } from 'lucide-react';
import { Seo } from '@/components/Seo';
import { Card, SectionHeading, Badge } from '@/components/ui';
import { Button } from '@/components/Button';

export default function Security() {
  return (
    <>
      <Seo title="Security" description="How BLC protects your data and how to report vulnerabilities responsibly." />
      <section className="section py-16">
        <SectionHeading center eyebrow="Security" title="Security overview" subtitle="Security is the foundation of BLC — not an afterthought." />

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-12">
          {[
            { icon: Database, title: 'Row Level Security', desc: 'Every database table has RLS enabled with ownership-scoped policies.' },
            { icon: Server, title: 'Server-side authorization', desc: 'Admin access is enforced on the server, never by client-side checks alone.' },
            { icon: Lock, title: 'Secrets stay server-side', desc: 'Service-role keys and API keys never reach the browser.' },
            { icon: KeyRound, title: 'Secure auth', desc: 'Email/password auth with hashed passwords via Supabase.' },
            { icon: Bug, title: 'Input validation', desc: 'Every form and API input is validated with Zod schemas.' },
            { icon: FileText, title: 'Audit logging', desc: 'Privileged admin actions are recorded in audit logs.' },
          ].map((s) => (
            <Card key={s.title}>
              <s.icon className="h-7 w-7 text-secondary-400" />
              <h3 className="mt-4 font-semibold text-white">{s.title}</h3>
              <p className="mt-2 text-sm text-neutral-400">{s.desc}</p>
            </Card>
          ))}
        </div>

        <Card className="mt-12">
          <Badge variant="success"><ShieldCheck className="h-3.5 w-3.5" /> Responsible disclosure</Badge>
          <h2 className="mt-4 text-2xl font-bold text-white">Report a vulnerability</h2>
          <p className="mt-3 text-neutral-400 leading-relaxed">
            If you believe you have found a security vulnerability in BLC, we want to hear from you.
            Report it responsibly through the Contact page with the subject "Security Report".
            We acknowledge all legitimate reports and work with researchers to fix issues.
          </p>
          <p className="mt-3 text-sm text-neutral-500">
            Please do not publicly disclose vulnerabilities before we have had a chance to address them.
          </p>
          <Link to="/contact" className="inline-block mt-6">
            <Button rightIcon={<ArrowRight className="h-4 w-4" />}>Report a vulnerability</Button>
          </Link>
        </Card>

        <Card className="mt-6 border-warning-500/20">
          <h3 className="font-semibold text-white">Honesty about certifications</h3>
          <p className="mt-2 text-sm text-neutral-400">
            BLC has not obtained formal security certifications (such as SOC 2 or ISO 27001).
            We do not claim certifications we do not hold. The security measures above are the ones we actually implement.
          </p>
        </Card>
      </section>
    </>
  );
}
