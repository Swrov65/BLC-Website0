import { useState } from 'react';
import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, Users, MessageSquare, FileText, Settings, ScrollText, LogOut, Menu, X, ArrowLeft, ShieldCheck,
} from 'lucide-react';
import { Logo } from '@/components/Logo';
import { Badge } from '@/components/ui';
import { useAuth } from '@/auth/AuthContext';
import { cn } from '@/lib/utils';

const nav = [
  { to: '/admin', label: 'Overview', icon: LayoutDashboard, end: true },
  { to: '/admin/users', label: 'Users', icon: Users },
  { to: '/admin/contact', label: 'Contact', icon: MessageSquare },
  { to: '/admin/content', label: 'Content', icon: FileText },
  { to: '/admin/settings', label: 'Settings', icon: Settings },
  { to: '/admin/audit', label: 'Audit Logs', icon: ScrollText },
];

export function AdminLayout() {
  const { signOut, profile } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  async function handleSignOut() {
    await signOut();
    navigate('/');
  }

  return (
    <div className="min-h-screen flex">
      <aside className="hidden lg:flex w-64 flex-col border-r border-neutral-800 bg-blc-navy-900/50 sticky top-0 h-screen">
        <div className="p-5 border-b border-neutral-800">
          <Link to="/"><Logo showText={false} /></Link>
          <div className="mt-3 flex items-center gap-2">
            <p className="text-sm font-semibold text-white">Admin Panel</p>
            <Badge variant="accent"><ShieldCheck className="h-3 w-3" /> Admin</Badge>
          </div>
          <p className="text-xs text-neutral-500 truncate mt-1">{profile?.email ?? 'Administrator'}</p>
        </div>
        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {nav.map((n) => (
            <NavLink
              key={n.to}
              to={n.to}
              end={n.end}
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors',
                  isActive ? 'bg-accent-500/10 text-accent-400 border border-accent-500/20' : 'text-neutral-400 hover:text-white hover:bg-neutral-800/50',
                )
              }
            >
              <n.icon className="h-4 w-4" />
              {n.label}
            </NavLink>
          ))}
        </nav>
        <div className="p-3 border-t border-neutral-800 space-y-1">
          <Link to="/dashboard" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-neutral-400 hover:text-white hover:bg-neutral-800/50 transition-colors">
            <ArrowLeft className="h-4 w-4" /> User dashboard
          </Link>
          <button onClick={handleSignOut} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-neutral-400 hover:text-error-400 hover:bg-error-500/10 transition-colors">
            <LogOut className="h-4 w-4" /> Sign out
          </button>
        </div>
      </aside>

      <div className="lg:hidden fixed top-0 left-0 right-0 z-40 h-14 border-b border-neutral-800 bg-blc-navy-900/90 backdrop-blur-xl flex items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <Logo showText={false} className="!gap-0" />
          <Badge variant="accent">Admin</Badge>
        </div>
        <button onClick={() => setOpen(true)} className="text-neutral-300"><Menu className="h-6 w-6" /></button>
      </div>

      {open && (
        <div className="lg:hidden fixed inset-0 z-50 bg-blc-navy-900/80 backdrop-blur-sm" onClick={() => setOpen(false)}>
          <div className="absolute right-0 top-0 bottom-0 w-72 glass p-4 animate-slide-in" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-6">
              <span className="text-sm font-semibold text-white">Admin</span>
              <button onClick={() => setOpen(false)} className="text-neutral-400"><X className="h-5 w-5" /></button>
            </div>
            <nav className="space-y-1">
              {nav.map((n) => (
                <NavLink key={n.to} to={n.to} end={n.end} onClick={() => setOpen(false)}
                  className={({ isActive }) => cn('flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm', isActive ? 'bg-accent-500/10 text-accent-400' : 'text-neutral-400 hover:text-white')}>
                  <n.icon className="h-4 w-4" /> {n.label}
                </NavLink>
              ))}
              <Link to="/dashboard" onClick={() => setOpen(false)} className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-neutral-400">
                <ArrowLeft className="h-4 w-4" /> User dashboard
              </Link>
              <button onClick={handleSignOut} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-error-400">
                <LogOut className="h-4 w-4" /> Sign out
              </button>
            </nav>
          </div>
        </div>
      )}

      <main className="flex-1 pt-14 lg:pt-0 min-w-0">
        <div className="p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto">
          <Outlet />
        </div>
      </main>
    </div>
  );
}

export default AdminLayout;
