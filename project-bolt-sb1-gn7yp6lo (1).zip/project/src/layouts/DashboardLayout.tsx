import { useState, useEffect } from 'react';
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import {
  Home, BrainCircuit, LayoutGrid, Code2, Cloud, KeyRound, Terminal, FolderKanban,
  BarChart3, Bell, ShieldCheck, LifeBuoy, Settings, User, LogOut, Menu, X,
  ArrowLeft, ChevronLeft, Search, ExternalLink, PanelLeftClose, PanelLeftOpen,
} from 'lucide-react';
import { Logo } from '@/components/Logo';
import { useAuth } from '@/auth/AuthContext';
import { cn } from '@/lib/utils';

const nav = [
  { section: 'Main', items: [
    { to: '/', label: 'Home', icon: Home },
    { to: '/ai-lab', label: 'BLC Intelligence', icon: BrainCircuit },
    { to: '/#ai-tools', label: 'AI Tools', icon: LayoutGrid },
  ]},
  { section: 'Platform', items: [
    { to: '/dashboard/studio', label: 'BLC Studio', icon: Code2 },
    { to: '/dashboard/cloud', label: 'BLC Cloud', icon: Cloud },
    { to: '/dashboard/api-keys', label: 'BLC APIs', icon: KeyRound },
    { to: '/developer', label: 'Developer Platform', icon: Terminal },
  ]},
  { section: 'Workspace', items: [
    { to: '/dashboard/projects', label: 'Projects', icon: FolderKanban },
    { to: '/dashboard/notifications', label: 'Notifications', icon: Bell },
    { to: '/dashboard/security', label: 'Security', icon: ShieldCheck },
    { to: '/dashboard/support', label: 'Support', icon: LifeBuoy },
  ]},
];

const collapsedKey = 'blc-sidebar-collapsed';

export function DashboardLayout() {
  const { profile, isAdmin, signOut } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [open, setOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(false);

  useEffect(() => {
    try {
      setCollapsed(localStorage.getItem(collapsedKey) === '1');
    } catch { /* ignore */ }
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [location.pathname]);

  function toggleCollapse() {
    setCollapsed((c) => {
      const next = !c;
      try { localStorage.setItem(collapsedKey, next ? '1' : '0'); } catch { /* ignore */ }
      return next;
    });
  }

  async function handleSignOut() {
    await signOut();
    navigate('/');
  }

  return (
    <div className="min-h-screen flex bg-blc-navy-900">
      {/* Desktop sidebar */}
      <aside
        className={cn(
          'hidden lg:flex flex-col border-r border-neutral-800/80 bg-blc-navy-900/60 backdrop-blur-xl sticky top-0 h-screen transition-all duration-300',
          collapsed ? 'w-[68px]' : 'w-64',
        )}
      >
        <div className={cn('p-4 border-b border-neutral-800/80 flex items-center', collapsed ? 'justify-center' : 'justify-between')}>
          <Link to="/" className="flex items-center gap-2.5 min-w-0">
            <Logo showText={false} />
            {!collapsed && (
              <span className="flex flex-col leading-none min-w-0">
                <span className="text-sm font-extrabold tracking-tight text-white truncate">Bangladesh Logic Code</span>
                <span className="text-[9px] font-medium uppercase tracking-[0.2em] text-secondary-400">Build Beyond</span>
              </span>
            )}
          </Link>
        </div>

        {!collapsed && (
          <div className="px-3 pt-3">
            <div className="flex items-center gap-2.5 rounded-lg bg-blc-navy-700/40 px-3 py-2.5 border border-neutral-800">
              <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-primary-600 to-secondary-500 text-xs font-bold text-white">
                {(profile?.display_name ?? profile?.email ?? 'U').charAt(0).toUpperCase()}
              </span>
              <div className="min-w-0">
                <p className="text-xs font-medium text-white truncate max-w-[120px]">{profile?.display_name ?? 'User'}</p>
                <p className="text-[10px] text-neutral-500 truncate max-w-[120px]">{profile?.email}</p>
              </div>
            </div>
          </div>
        )}

        <nav className="flex-1 px-3 py-3 space-y-4 overflow-y-auto">
          {nav.map((group) => (
            <div key={group.section}>
              {!collapsed && (
                <p className="px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-neutral-600">{group.section}</p>
              )}
              <div className="space-y-1 mt-1">
                {group.items.map((item) => (
                  <SidebarLink key={item.to} to={item.to} label={item.label} icon={item.icon} collapsed={collapsed} />
                ))}
              </div>
            </div>
          ))}

          {isAdmin && (
            <div>
              {!collapsed && <p className="px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-neutral-600">Admin</p>}
              <div className="space-y-1 mt-1">
                <Link to="/admin" className="nav-item nav-item-idle text-accent-400 hover:bg-accent-500/10">
                  <ShieldCheck className="h-4 w-4 shrink-0" />
                  {!collapsed && <span>Admin Panel</span>}
                </Link>
              </div>
            </div>
          )}
        </nav>

        <div className="p-3 border-t border-neutral-800/80 space-y-1">
          <button onClick={toggleCollapse} className="nav-item nav-item-idle w-full">
            {collapsed ? <PanelLeftOpen className="h-4 w-4 shrink-0" /> : <PanelLeftClose className="h-4 w-4 shrink-0" />}
            {!collapsed && <span>Collapse</span>}
          </button>
          <Link to="/dashboard/profile" className="nav-item nav-item-idle">
            <User className="h-4 w-4 shrink-0" />
            {!collapsed && <span>Profile</span>}
          </Link>
          <Link to="/dashboard" className="nav-item nav-item-idle">
            <Settings className="h-4 w-4 shrink-0" />
            {!collapsed && <span>Settings</span>}
          </Link>
          <button onClick={handleSignOut} className="nav-item nav-item-idle w-full hover:text-error-400 hover:bg-error-500/10">
            <LogOut className="h-4 w-4 shrink-0" />
            {!collapsed && <span>Sign out</span>}
          </button>
        </div>
      </aside>

      {/* Mobile top bar */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-40 h-14 border-b border-neutral-800/80 bg-blc-navy-900/90 backdrop-blur-xl flex items-center justify-between px-4">
        <Link to="/"><Logo showText={false} /></Link>
        <div className="flex items-center gap-2">
          <span className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-primary-600 to-secondary-500 text-xs font-bold text-white">
            {(profile?.display_name ?? profile?.email ?? 'U').charAt(0).toUpperCase()}
          </span>
          <button onClick={() => setOpen(true)} className="text-neutral-300"><Menu className="h-6 w-6" /></button>
        </div>
      </div>

      {/* Mobile drawer */}
      {open && (
        <div className="lg:hidden fixed inset-0 z-50 bg-blc-navy-900/80 backdrop-blur-sm" onClick={() => setOpen(false)}>
          <div className="absolute right-0 top-0 bottom-0 w-72 glass p-4 animate-slide-in overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-6">
              <span className="text-sm font-semibold text-white">Navigation</span>
              <button onClick={() => setOpen(false)} className="text-neutral-400"><X className="h-5 w-5" /></button>
            </div>
            <div className="flex items-center gap-2.5 rounded-lg bg-blc-navy-700/40 px-3 py-2.5 border border-neutral-800 mb-4">
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-primary-600 to-secondary-500 text-xs font-bold text-white">
                {(profile?.display_name ?? 'U').charAt(0).toUpperCase()}
              </span>
              <div className="min-w-0">
                <p className="text-xs font-medium text-white truncate">{profile?.display_name ?? 'User'}</p>
                <p className="text-[10px] text-neutral-500 truncate">{profile?.email}</p>
              </div>
            </div>
            <nav className="space-y-4">
              {nav.map((group) => (
                <div key={group.section}>
                  <p className="px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-neutral-600">{group.section}</p>
                  <div className="space-y-1">
                    {group.items.map((item) => (
                      <SidebarLink key={item.to} to={item.to} label={item.label} icon={item.icon} collapsed={false} onNavigate={() => setOpen(false)} />
                    ))}
                  </div>
                </div>
              ))}
              {isAdmin && (
                <Link to="/admin" onClick={() => setOpen(false)} className="nav-item nav-item-idle text-accent-400">
                  <ShieldCheck className="h-4 w-4" /> Admin Panel
                </Link>
              )}
              <div className="pt-3 border-t border-neutral-800 space-y-1">
                <Link to="/dashboard/profile" onClick={() => setOpen(false)} className="nav-item nav-item-idle"><User className="h-4 w-4" /> Profile</Link>
                <Link to="/dashboard" onClick={() => setOpen(false)} className="nav-item nav-item-idle"><Settings className="h-4 w-4" /> Settings</Link>
                <button onClick={handleSignOut} className="nav-item nav-item-idle w-full text-error-400"><LogOut className="h-4 w-4" /> Sign out</button>
              </div>
            </nav>
          </div>
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Desktop top bar */}
        <div className="hidden lg:flex sticky top-0 z-30 h-14 border-b border-neutral-800/80 bg-blc-navy-900/70 backdrop-blur-xl items-center px-6 gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-500" />
            <input
              type="text"
              placeholder="Search BLC..."
              className="w-full rounded-lg bg-blc-navy-700/40 border border-neutral-800 pl-10 pr-4 py-2 text-sm text-neutral-200 placeholder-neutral-500 focus:border-secondary-400/50 focus:ring-1 focus:ring-secondary-400/30 transition-colors"
            />
          </div>
          <div className="flex items-center gap-2">
            <Link to="/dashboard/notifications" className="relative flex h-9 w-9 items-center justify-center rounded-lg glass text-neutral-400 hover:text-secondary-400 hover:border-secondary-400/40 transition-colors">
              <Bell className="h-4 w-4" />
            </Link>
            <Link to="/dashboard/support" className="flex h-9 w-9 items-center justify-center rounded-lg glass text-neutral-400 hover:text-secondary-400 hover:border-secondary-400/40 transition-colors">
              <LifeBuoy className="h-4 w-4" />
            </Link>
            <Link to="/dashboard/profile" className="flex items-center gap-2 rounded-lg glass px-3 py-1.5 text-sm font-medium text-neutral-200 hover:border-secondary-400/50 transition-colors">
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-gradient-to-br from-primary-600 to-secondary-500 text-xs font-bold text-white">
                {(profile?.display_name ?? profile?.email ?? 'U').charAt(0).toUpperCase()}
              </span>
              <span className="max-w-[100px] truncate">{profile?.display_name ?? 'Account'}</span>
            </Link>
          </div>
        </div>

        <main className="flex-1 pt-14 lg:pt-0 min-w-0">
          <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}

function SidebarLink({ to, label, icon: Icon, collapsed, onNavigate }: { to: string; label: string; icon: typeof Home; collapsed: boolean; onNavigate?: () => void }) {
  const isHashLink = to.includes('#');
  const base = cn('nav-item', collapsed && 'justify-center px-2');

  if (isHashLink) {
    return (
      <Link to="/" onClick={onNavigate} className={cn(base, 'nav-item-idle')} title={collapsed ? label : undefined}>
        <Icon className="h-4 w-4 shrink-0" />
        {!collapsed && <span>{label}</span>}
      </Link>
    );
  }

  return (
    <NavLink
      to={to}
      end={to === '/' || to === '/dashboard'}
      onClick={onNavigate}
      title={collapsed ? label : undefined}
      className={({ isActive }) => cn(base, isActive ? 'nav-item-active' : 'nav-item-idle')}
    >
      <Icon className="h-4 w-4 shrink-0" />
      {!collapsed && <span>{label}</span>}
    </NavLink>
  );
}

export default DashboardLayout;
