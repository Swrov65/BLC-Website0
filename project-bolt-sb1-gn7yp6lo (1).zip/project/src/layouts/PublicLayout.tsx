import { useState, useRef, useEffect } from 'react';
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { Menu, X, Github, Twitter, Linkedin, Mail, ShieldCheck, ChevronDown, User, Bell, LifeBuoy, LogOut, ShieldCheck as ShieldIcon } from 'lucide-react';
import { Logo } from '@/components/Logo';
import { Button } from '@/components/Button';
import { useAuth } from '@/auth/AuthContext';
import { cn } from '@/lib/utils';

const navLinks = [
  { to: '/', label: 'Home' },
  { to: '/ai-lab', label: 'AI Tools' },
  { to: '/dashboard/studio', label: 'BLC Studio' },
  { to: '/dashboard/cloud', label: 'BLC Cloud' },
  { to: '/developer', label: 'Developer' },
  { to: '/security', label: 'BLC Security' },
  { to: '/about', label: 'About' },
  { to: '/contact', label: 'Contact' },
];

export function PublicLayout() {
  const [open, setOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { session, isAdmin, profile, signOut } = useAuth();
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false);
    }
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  async function handleSignOut() {
    await signOut();
    setMenuOpen(false);
    setOpen(false);
    navigate('/');
  }

  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-50 border-b border-neutral-800/60 bg-blc-navy-900/80 backdrop-blur-xl">
        <nav className="section flex h-16 items-center justify-between" aria-label="Main">
          <Link to="/" className="shrink-0" onClick={() => setOpen(false)}>
            <Logo />
          </Link>

          <div className="hidden lg:flex items-center gap-1">
            {navLinks.map((l) => (
              <NavLink
                key={l.to}
                to={l.to}
                end={l.to === '/'}
                className={({ isActive }) =>
                  cn(
                    'px-3 py-2 text-sm font-medium rounded-md transition-colors',
                    isActive ? 'text-secondary-400' : 'text-neutral-300 hover:text-white',
                  )
                }
              >
                {l.label}
              </NavLink>
            ))}
          </div>

          <div className="hidden lg:flex items-center gap-2">
            {session ? (
              <div className="relative" ref={menuRef}>
                <button
                  onClick={() => setMenuOpen(!menuOpen)}
                  className="flex items-center gap-2 rounded-lg glass px-3 py-2 text-sm font-medium text-neutral-200 hover:border-secondary-400/50 transition-colors"
                >
                  <span className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-primary-600 to-secondary-500 text-xs font-bold text-white">
                    {(profile?.display_name ?? profile?.email ?? 'U').charAt(0).toUpperCase()}
                  </span>
                  <span className="max-w-[120px] truncate">{profile?.display_name ?? 'Account'}</span>
                  <ChevronDown className={cn('h-4 w-4 text-neutral-400 transition-transform', menuOpen && 'rotate-180')} />
                </button>
                {menuOpen && (
                  <div className="absolute right-0 mt-2 w-56 glass rounded-xl border border-neutral-800 p-2 shadow-xl animate-fade-in">
                    <div className="px-3 py-2 border-b border-neutral-800 mb-1">
                      <p className="text-sm font-medium text-white truncate">{profile?.display_name ?? 'User'}</p>
                      <p className="text-xs text-neutral-500 truncate">{profile?.email}</p>
                    </div>
                    <Link to="/dashboard" onClick={() => setMenuOpen(false)} className="flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-neutral-300 hover:bg-neutral-800/50 hover:text-white transition-colors">
                      <User className="h-4 w-4" /> My Account
                    </Link>
                    <Link to="/dashboard/notifications" onClick={() => setMenuOpen(false)} className="flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-neutral-300 hover:bg-neutral-800/50 hover:text-white transition-colors">
                      <Bell className="h-4 w-4" /> Notifications
                    </Link>
                    <Link to="/dashboard/support" onClick={() => setMenuOpen(false)} className="flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-neutral-300 hover:bg-neutral-800/50 hover:text-white transition-colors">
                      <LifeBuoy className="h-4 w-4" /> Support
                    </Link>
                    {isAdmin && (
                      <Link to="/admin" onClick={() => setMenuOpen(false)} className="flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-accent-400 hover:bg-accent-500/10 transition-colors">
                        <ShieldIcon className="h-4 w-4" /> Admin Panel
                      </Link>
                    )}
                    <div className="border-t border-neutral-800 mt-1 pt-1">
                      <button onClick={handleSignOut} className="w-full flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-error-400 hover:bg-error-500/10 transition-colors">
                        <LogOut className="h-4 w-4" /> Sign out
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <>
                <Link to="/login">
                  <Button variant="ghost" size="sm">Sign in</Button>
                </Link>
                <Link to="/signup">
                  <Button size="sm">Get Started</Button>
                </Link>
              </>
            )}
          </div>

          <button
            className="lg:hidden p-2 text-neutral-300 hover:text-white"
            onClick={() => setOpen((o) => !o)}
            aria-label="Toggle menu"
            aria-expanded={open}
          >
            {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </nav>

        {open && (
          <div className="lg:hidden border-t border-neutral-800 bg-blc-navy-900 animate-slide-in max-h-[calc(100vh-4rem)] overflow-y-auto">
            <div className="section py-4 flex flex-col gap-1">
              {navLinks.map((l) => (
                <NavLink
                  key={l.to}
                  to={l.to}
                  end={l.to === '/'}
                  onClick={() => setOpen(false)}
                  className={({ isActive }) =>
                    cn(
                      'px-3 py-2.5 text-sm font-medium rounded-md transition-colors',
                      isActive ? 'text-secondary-400 bg-blc-navy-700' : 'text-neutral-300 hover:text-white hover:bg-neutral-800/50',
                    )
                  }
                >
                  {l.label}
                </NavLink>
              ))}
              <div className="mt-3 pt-3 border-t border-neutral-800 flex flex-col gap-1">
                {session ? (
                  <>
                    <p className="px-3 py-1 text-xs text-neutral-500">{profile?.email}</p>
                    <Link to="/dashboard" onClick={() => setOpen(false)} className="flex items-center gap-2.5 px-3 py-2.5 rounded-md text-sm text-neutral-300 hover:bg-neutral-800/50">
                      <User className="h-4 w-4" /> My Account
                    </Link>
                    <Link to="/dashboard/notifications" onClick={() => setOpen(false)} className="flex items-center gap-2.5 px-3 py-2.5 rounded-md text-sm text-neutral-300 hover:bg-neutral-800/50">
                      <Bell className="h-4 w-4" /> Notifications
                    </Link>
                    <Link to="/dashboard/support" onClick={() => setOpen(false)} className="flex items-center gap-2.5 px-3 py-2.5 rounded-md text-sm text-neutral-300 hover:bg-neutral-800/50">
                      <LifeBuoy className="h-4 w-4" /> Support
                    </Link>
                    {isAdmin && (
                      <Link to="/admin" onClick={() => setOpen(false)} className="flex items-center gap-2.5 px-3 py-2.5 rounded-md text-sm text-accent-400 hover:bg-accent-500/10">
                        <ShieldIcon className="h-4 w-4" /> Admin Panel
                      </Link>
                    )}
                    <button onClick={handleSignOut} className="flex items-center gap-2.5 px-3 py-2.5 rounded-md text-sm text-error-400 hover:bg-error-500/10">
                      <LogOut className="h-4 w-4" /> Sign out
                    </button>
                  </>
                ) : (
                  <>
                    <Link to="/login" onClick={() => setOpen(false)}>
                      <Button variant="secondary" className="w-full">Sign in</Button>
                    </Link>
                    <Link to="/signup" onClick={() => setOpen(false)}>
                      <Button className="w-full">Get Started</Button>
                    </Link>
                  </>
                )}
              </div>
            </div>
          </div>
        )}
      </header>

      <main className="flex-1" key={location.pathname}>
        <Outlet />
      </main>

      <Footer />
    </div>
  );
}

function Footer() {
  const cols = [
    {
      title: 'Platform',
      links: [
        { to: '/ai-lab', label: 'BLC Intelligence' },
        { to: '/dashboard/studio', label: 'BLC Studio' },
        { to: '/dashboard/cloud', label: 'BLC Cloud' },
        { to: '/developer', label: 'Developer Platform' },
      ],
    },
    {
      title: 'Developers',
      links: [
        { to: '/developer', label: 'Developer Center' },
        { to: '/docs', label: 'Documentation' },
        { to: '/dashboard/api-keys', label: 'API Keys' },
        { to: '/status', label: 'Status' },
      ],
    },
    {
      title: 'Company',
      links: [
        { to: '/about', label: 'About BLC' },
        { to: '/contact', label: 'Contact' },
        { to: '/privacy', label: 'Privacy Policy' },
        { to: '/terms', label: 'Terms of Service' },
      ],
    },
  ];
  return (
    <footer className="border-t border-neutral-800 bg-blc-navy-900">
      <div className="section py-12">
        <div className="grid gap-10 lg:grid-cols-5">
          <div className="lg:col-span-2">
            <Logo />
            <p className="mt-4 text-sm text-neutral-400 max-w-xs leading-relaxed">
              Intelligent Technology. Limitless Possibilities. A technology platform engineered and founded by Soyaif.
            </p>
            <div className="mt-5 flex items-center gap-3">
              {[Github, Twitter, Linkedin, Mail].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="flex h-9 w-9 items-center justify-center rounded-lg glass text-neutral-400 hover:text-secondary-400 hover:border-secondary-400/40 transition-colors"
                  aria-label="Social link"
                  onClick={(e) => e.preventDefault()}
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>
          {cols.map((col) => (
            <div key={col.title}>
              <h3 className="text-sm font-semibold text-white">{col.title}</h3>
              <ul className="mt-4 space-y-2.5">
                {col.links.map((l) => (
                  <li key={l.to}>
                    <Link to={l.to} className="text-sm text-neutral-400 hover:text-secondary-400 transition-colors">
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 pt-6 border-t border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-neutral-500">
            © {new Date().getFullYear()} Bangladesh Logic Code. Founded by Soyaif.
          </p>
          <div className="flex items-center gap-2 text-xs text-neutral-500">
            <ShieldCheck className="h-4 w-4 text-success-400" />
            Built with security-first principles
          </div>
        </div>
      </div>
    </footer>
  );
}
