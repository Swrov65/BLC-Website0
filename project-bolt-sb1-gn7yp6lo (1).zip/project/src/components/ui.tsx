import type { HTMLAttributes, ReactNode } from 'react';
import { cn } from '@/lib/utils';

export function Card({ className, children, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cn('glass-card p-6', className)} {...props}>
      {children}
    </div>
  );
}

export function Badge({
  children,
  variant = 'neutral',
  className,
}: {
  children: ReactNode;
  variant?: 'neutral' | 'success' | 'warning' | 'error' | 'info' | 'accent';
  className?: string;
}) {
  const variants = {
    neutral: 'bg-neutral-800 text-neutral-300',
    success: 'bg-success-500/15 text-success-400 border border-success-500/30',
    warning: 'bg-warning-500/15 text-warning-400 border border-warning-500/30',
    error: 'bg-error-500/15 text-error-400 border border-error-500/30',
    info: 'bg-secondary-500/15 text-secondary-400 border border-secondary-500/30',
    accent: 'bg-accent-500/15 text-accent-400 border border-accent-500/30',
  };
  return <span className={cn('inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium', variants[variant], className)}>{children}</span>;
}

export function SectionHeading({
  eyebrow,
  title,
  subtitle,
  center,
  className,
}: {
  eyebrow?: string;
  title: ReactNode;
  subtitle?: string;
  center?: boolean;
  className?: string;
}) {
  return (
    <div className={cn(center && 'text-center mx-auto max-w-2xl', 'mb-10', className)}>
      {eyebrow && (
        <p className="mb-3 text-xs font-semibold uppercase tracking-[0.25em] text-secondary-400">{eyebrow}</p>
      )}
      <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-white">{title}</h2>
      {subtitle && <p className="mt-4 text-neutral-400 text-lg leading-relaxed">{subtitle}</p>}
    </div>
  );
}

export function Spinner({ className }: { className?: string }) {
  return <span className={cn('inline-block animate-spin rounded-full border-2 border-secondary-400 border-t-transparent', className ?? 'h-5 w-5')} />;
}

export function EmptyState({
  icon,
  title,
  description,
  action,
}: {
  icon?: ReactNode;
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-16 px-6">
      {icon && <div className="mb-4 text-neutral-600">{icon}</div>}
      <h3 className="text-lg font-semibold text-neutral-200">{title}</h3>
      {description && <p className="mt-2 text-sm text-neutral-500 max-w-sm">{description}</p>}
      {action && <div className="mt-6">{action}</div>}
    </div>
  );
}

export function StatusBadge({ status }: { status: 'live' | 'beta' | 'planned' | 'in_development' }) {
  const map = {
    live: { label: 'Live', variant: 'success' as const, dot: 'bg-success-400' },
    beta: { label: 'Beta', variant: 'info' as const, dot: 'bg-secondary-400' },
    planned: { label: 'Planned', variant: 'neutral' as const, dot: 'bg-neutral-500' },
    in_development: { label: 'In Development', variant: 'warning' as const, dot: 'bg-warning-400' },
  };
  const s = map[status];
  return (
    <Badge variant={s.variant}>
      <span className={cn('h-1.5 w-1.5 rounded-full', s.dot)} />
      {s.label}
    </Badge>
  );
}
