export function AiNetwork() {
  return (
    <div className="pointer-events-none relative h-full w-full" aria-hidden="true">
      {/* Outer rotating ring */}
      <div className="absolute left-1/2 top-1/2 h-[120%] w-[120%] -translate-x-1/2 -translate-y-1/2 animate-spin-slow">
        <div className="h-full w-full rounded-full border border-secondary-500/10" />
      </div>
      {/* Mid ring */}
      <div className="absolute left-1/2 top-1/2 h-[90%] w-[90%] -translate-x-1/2 -translate-y-1/2 animate-spin-slow" style={{ animationDirection: 'reverse', animationDuration: '30s' }}>
        <div className="h-full w-full rounded-full border border-accent-500/10" />
      </div>

      {/* Core glow */}
      <div className="absolute left-1/2 top-1/2 h-40 w-40 -translate-x-1/2 -translate-y-1/2 rounded-full bg-gradient-to-br from-secondary-500/30 to-accent-500/30 blur-2xl animate-pulse-glow" />

      <svg viewBox="0 0 400 400" className="absolute inset-0 h-full w-full">
        <defs>
          <radialGradient id="ai-core" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#6366f1" stopOpacity="0" />
          </radialGradient>
          <linearGradient id="ai-line" x1="0" y1="0" x2="1" y2="1">
            <stop stopColor="#22d3ee" stopOpacity="0.4" />
            <stop offset="1" stopColor="#6366f1" stopOpacity="0.1" />
          </linearGradient>
        </defs>

        {/* Connection lines */}
        <g stroke="url(#ai-line)" strokeWidth="1">
          <line x1="200" y1="200" x2="60" y2="80" />
          <line x1="200" y1="200" x2="340" y2="100" />
          <line x1="200" y1="200" x2="80" y2="320" />
          <line x1="200" y1="200" x2="330" y2="310" />
          <line x1="200" y1="200" x2="200" y2="40" />
          <line x1="200" y1="200" x2="200" y2="360" />
          <line x1="60" y1="80" x2="200" y2="40" />
          <line x1="340" y1="100" x2="200" y2="40" />
          <line x1="80" y1="320" x2="200" y2="360" />
          <line x1="330" y1="310" x2="200" y2="360" />
          <line x1="60" y1="80" x2="80" y2="320" />
          <line x1="340" y1="100" x2="330" y2="310" />
        </g>

        {/* Core circle */}
        <circle cx="200" cy="200" r="24" fill="url(#ai-core)" />
        <circle cx="200" cy="200" r="14" fill="#0a0e1c" stroke="#22d3ee" strokeWidth="1.5" />
        <circle cx="200" cy="200" r="3" fill="#22d3ee" className="animate-pulse" />

        {/* Orbit nodes */}
        {[
          { x: 60, y: 80, d: '0s' },
          { x: 340, y: 100, d: '0.4s' },
          { x: 80, y: 320, d: '0.8s' },
          { x: 330, y: 310, d: '1.2s' },
          { x: 200, y: 40, d: '1.6s' },
          { x: 200, y: 360, d: '2s' },
        ].map((n, i) => (
          <g key={i}>
            <circle cx={n.x} cy={n.y} r="10" fill="#0a0e1c" stroke="#6366f1" strokeWidth="1" />
            <circle cx={n.x} cy={n.y} r="3" fill="#22d3ee">
              <animate attributeName="opacity" values="0.3;1;0.3" dur="3s" repeatCount="indefinite" begin={n.d} />
            </circle>
          </g>
        ))}
      </svg>
    </div>
  );
}
