import { cn } from '@/lib/utils';

export function Logo({ className, showText = true }: { className?: string; showText?: boolean }) {
  return (
    <span className={cn('inline-flex items-center gap-2.5', className)}>
      <svg viewBox="0 0 64 64" className="h-9 w-9" fill="none" aria-hidden="true">
        <rect width="64" height="64" rx="14" fill="#05070f" />
        <rect x="1" y="1" width="62" height="62" rx="13" stroke="url(#blc-g)" strokeWidth="1.5" />
        <path d="M14 46V18h12c7 0 12 4 12 11s-5 11-12 11h-4v6h-8zm8-14h4c2.5 0 4-1.5 4-3.5S28.5 25 26 25h-4v7z" fill="#22d3ee" />
        <path d="M34 46V18h6v22h12v6H34z" fill="#6366f1" />
        <circle cx="50" cy="18" r="3" fill="#22d3ee" />
        <defs>
          <linearGradient id="blc-g" x1="0" y1="0" x2="64" y2="64">
            <stop stopColor="#22d3ee" />
            <stop offset="1" stopColor="#6366f1" />
          </linearGradient>
        </defs>
      </svg>
      {showText && (
        <span className="flex flex-col leading-none">
          <span className="text-base font-extrabold tracking-tight text-white">
            Bangladesh Logic Code
          </span>
          <span className="text-[10px] font-medium uppercase tracking-[0.2em] text-secondary-400">
            Build Beyond
          </span>
        </span>
      )}
    </span>
  );
}

export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} fill="none" aria-hidden="true">
      <rect width="64" height="64" rx="14" fill="#05070f" />
      <rect x="1" y="1" width="62" height="62" rx="13" stroke="url(#blc-g2)" strokeWidth="1.5" />
      <path d="M14 46V18h12c7 0 12 4 12 11s-5 11-12 11h-4v6h-8zm8-14h4c2.5 0 4-1.5 4-3.5S28.5 25 26 25h-4v7z" fill="#22d3ee" />
      <path d="M34 46V18h6v22h12v6H34z" fill="#6366f1" />
      <circle cx="50" cy="18" r="3" fill="#22d3ee" />
      <defs>
        <linearGradient id="blc-g2" x1="0" y1="0" x2="64" y2="64">
          <stop stopColor="#22d3ee" />
          <stop offset="1" stopColor="#6366f1" />
        </linearGradient>
      </defs>
    </svg>
  );
}
