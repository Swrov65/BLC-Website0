import { createContext, useCallback, useContext, useState, type ReactNode } from 'react';
import { CheckCircle2, AlertCircle, Info, X, XCircle } from 'lucide-react';

type ToastVariant = 'success' | 'error' | 'info' | 'warning';
type Toast = { id: number; title: string; description?: string; variant: ToastVariant };

const ToastContext = createContext<{ push: (t: Omit<Toast, 'id'>) => void } | undefined>(undefined);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const push = useCallback((t: Omit<Toast, 'id'>) => {
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev, { ...t, id }]);
    setTimeout(() => setToasts((prev) => prev.filter((x) => x.id !== id)), 5000);
  }, []);

  const remove = (id: number) => setToasts((prev) => prev.filter((x) => x.id !== id));

  return (
    <ToastContext.Provider value={{ push }}>
      {children}
      <div className="fixed top-4 right-4 z-[100] flex flex-col gap-2 w-full max-w-sm pointer-events-none">
        {toasts.map((t) => (
          <ToastItem key={t.id} toast={t} onClose={() => remove(t.id)} />
        ))}
      </div>
    </ToastContext.Provider>
  );
}

function ToastItem({ toast, onClose }: { toast: Toast; onClose: () => void }) {
  const icons = {
    success: <CheckCircle2 className="h-5 w-5 text-success-400" />,
    error: <XCircle className="h-5 w-5 text-error-400" />,
    info: <Info className="h-5 w-5 text-secondary-400" />,
    warning: <AlertCircle className="h-5 w-5 text-warning-400" />,
  };
  const borders = {
    success: 'border-success-500/40',
    error: 'border-error-500/40',
    info: 'border-secondary-500/40',
    warning: 'border-warning-500/40',
  };
  return (
    <div
      role="status"
      className={`glass ${borders[toast.variant]} rounded-xl p-4 shadow-card animate-slide-in pointer-events-auto flex items-start gap-3`}
    >
      <span className="mt-0.5 shrink-0">{icons[toast.variant]}</span>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-white">{toast.title}</p>
        {toast.description && <p className="mt-0.5 text-xs text-neutral-400">{toast.description}</p>}
      </div>
      <button onClick={onClose} className="text-neutral-500 hover:text-white transition-colors" aria-label="Dismiss">
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within ToastProvider');
  return ctx;
}
