import { useEffect } from 'react';

export type SeoProps = {
  title?: string;
  description?: string;
  canonical?: string;
};

const BASE_TITLE = 'Bangladesh Logic Code — Build Beyond.';
const BASE_DESC =
  'Bangladesh Logic Code (BLC) — Intelligent technology, software development services, AI workspaces, cloud infrastructure, and a developer platform by Soyaif.';

export function Seo({ title, description, canonical }: SeoProps) {
  useEffect(() => {
    document.title = title ? `${title} — BLC` : BASE_TITLE;
    const setMeta = (name: string, content: string, attr: 'name' | 'property' = 'name') => {
      let el = document.querySelector(`meta[${attr}="${name}"]`) as HTMLMetaElement | null;
      if (!el) {
        el = document.createElement('meta');
        el.setAttribute(attr, name);
        document.head.appendChild(el);
      }
      el.content = content;
    };
    const desc = description ?? BASE_DESC;
    setMeta('description', desc);
    setMeta('og:title', title ? `${title} — BLC` : BASE_TITLE, 'property');
    setMeta('og:description', desc, 'property');
    setMeta('twitter:title', title ? `${title} — BLC` : BASE_TITLE);
    setMeta('twitter:description', desc);
    if (canonical) {
      let link = document.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
      if (!link) {
        link = document.createElement('link');
        link.rel = 'canonical';
        document.head.appendChild(link);
      }
      link.href = canonical;
    }
  }, [title, description, canonical]);
  return null;
}

export default Seo;
