import { lazy, Suspense, Component, type ReactNode } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '@/auth/AuthContext';
import { ToastProvider } from '@/components/Toast';
import { PublicLayout } from '@/layouts/PublicLayout';
import { ProtectedRoute, AdminRoute } from '@/auth/RouteGuards';
import { Loader2 } from 'lucide-react';

const Home = lazy(() => import('@/pages/Home'));
const About = lazy(() => import('@/pages/About'));
const Products = lazy(() => import('@/pages/Products'));
const ProductDetail = lazy(() => import('@/pages/ProductDetail'));
const Services = lazy(() => import('@/pages/Services'));
const Developer = lazy(() => import('@/pages/Developer'));
const AiLab = lazy(() => import('@/pages/AiLab'));
const AiToolPlaceholder = lazy(() => import('@/pages/AiToolPlaceholder'));
const AiMath = lazy(() => import('@/pages/ai/AiMath'));
const AiTranslator = lazy(() => import('@/pages/ai/AiTranslator'));
const AiPresentation = lazy(() => import('@/pages/ai/AiPresentation'));
const AiWebsiteBuilder = lazy(() => import('@/pages/ai/AiWebsiteBuilder'));
const AiAppBuilder = lazy(() => import('@/pages/ai/AiAppBuilder'));
const AiSupport = lazy(() => import('@/pages/ai/AiSupport'));
const AiDocumentReader = lazy(() => import('@/pages/ai/AiDocumentReader'));
const AiPdf = lazy(() => import('@/pages/ai/AiPdf'));
const AiDataAnalyst = lazy(() => import('@/pages/ai/AiDataAnalyst'));
const Docs = lazy(() => import('@/pages/Docs'));
const Pricing = lazy(() => import('@/pages/Pricing'));
const Contact = lazy(() => import('@/pages/Contact'));
const Status = lazy(() => import('@/pages/Status'));
const Security = lazy(() => import('@/pages/Security'));
const Privacy = lazy(() => import('@/pages/Privacy'));
const Terms = lazy(() => import('@/pages/Terms'));
const NotFound = lazy(() => import('@/pages/NotFound'));

const Login = lazy(() => import('@/pages/auth/Login'));
const Signup = lazy(() => import('@/pages/auth/Signup'));
const ResetPassword = lazy(() => import('@/pages/auth/ResetPassword'));

const DashboardLayout = lazy(() => import('@/layouts/DashboardLayout'));
const DashboardHome = lazy(() => import('@/pages/dashboard/DashboardHome'));
const DashboardProfile = lazy(() => import('@/pages/dashboard/DashboardProfile'));
const DashboardProjects = lazy(() => import('@/pages/dashboard/DashboardProjects'));
const DashboardNotifications = lazy(() => import('@/pages/dashboard/DashboardNotifications'));
const DashboardSecurity = lazy(() => import('@/pages/dashboard/DashboardSecurity'));
const DashboardSupport = lazy(() => import('@/pages/dashboard/DashboardSupport'));
const DashboardApiKeys = lazy(() => import('@/pages/dashboard/DashboardApiKeys'));
const DashboardStudio = lazy(() => import('@/pages/dashboard/DashboardStudio'));
const DashboardCloud = lazy(() => import('@/pages/dashboard/DashboardCloud'));
const DashboardWebhooks = lazy(() => import('@/pages/dashboard/DashboardWebhooks'));

const AdminLayout = lazy(() => import('@/layouts/AdminLayout'));
const AdminHome = lazy(() => import('@/pages/admin/AdminHome'));
const AdminUsers = lazy(() => import('@/pages/admin/AdminUsers'));
const AdminContact = lazy(() => import('@/pages/admin/AdminContact'));
const AdminContent = lazy(() => import('@/pages/admin/AdminContent'));
const AdminSettings = lazy(() => import('@/pages/admin/AdminSettings'));
const AdminAudit = lazy(() => import('@/pages/admin/AdminAudit'));

function PageLoader() {
  return (
    <div className="min-h-[60vh] flex items-center justify-center">
      <Loader2 className="h-8 w-8 animate-spin text-secondary-400" />
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <ToastProvider>
          <ErrorBoundary>
            <Suspense fallback={<PageLoader />}>
              <Routes>
                <Route element={<PublicLayout />}>
                  <Route index element={<Home />} />
                  <Route path="about" element={<About />} />
                  <Route path="products" element={<Products />} />
                  <Route path="products/:slug" element={<ProductDetail />} />
                  <Route path="services" element={<Services />} />
                  <Route path="developer" element={<Developer />} />
                  <Route path="ai-lab" element={<AiLab />} />
                  <Route path="ai/math" element={<AiMath />} />
                  <Route path="ai/translator" element={<AiTranslator />} />
                  <Route path="ai/presentation" element={<AiPresentation />} />
                  <Route path="ai/website-builder" element={<AiWebsiteBuilder />} />
                  <Route path="ai/app-builder" element={<AiAppBuilder />} />
                  <Route path="ai/support" element={<AiSupport />} />
                  <Route path="ai/document-reader" element={<AiDocumentReader />} />
                  <Route path="ai/pdf" element={<AiPdf />} />
                  <Route path="ai/data-analyst" element={<AiDataAnalyst />} />
                  <Route path="ai/:tool" element={<AiToolPlaceholder />} />
                  <Route path="docs" element={<Docs />} />
                  <Route path="docs/:slug" element={<Docs />} />
                  <Route path="pricing" element={<Pricing />} />
                  <Route path="contact" element={<Contact />} />
                  <Route path="status" element={<Status />} />
                  <Route path="security" element={<Security />} />
                  <Route path="privacy" element={<Privacy />} />
                  <Route path="terms" element={<Terms />} />
                </Route>

                <Route path="login" element={<Login />} />
                <Route path="signup" element={<Signup />} />
                <Route path="reset-password" element={<ResetPassword />} />

                <Route
                  path="dashboard"
                  element={
                    <ProtectedRoute>
                      <DashboardLayout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<DashboardHome />} />
                  <Route path="profile" element={<DashboardProfile />} />
                  <Route path="projects" element={<DashboardProjects />} />
                  <Route path="notifications" element={<DashboardNotifications />} />
                  <Route path="security" element={<DashboardSecurity />} />
                  <Route path="support" element={<DashboardSupport />} />
                  <Route path="api-keys" element={<DashboardApiKeys />} />
                  <Route path="studio" element={<DashboardStudio />} />
                  <Route path="cloud" element={<DashboardCloud />} />
                  <Route path="webhooks" element={<DashboardWebhooks />} />
                </Route>

                <Route
                  path="admin"
                  element={
                    <AdminRoute>
                      <AdminLayout />
                    </AdminRoute>
                  }
                >
                  <Route index element={<AdminHome />} />
                  <Route path="users" element={<AdminUsers />} />
                  <Route path="contact" element={<AdminContact />} />
                  <Route path="content" element={<AdminContent />} />
                  <Route path="settings" element={<AdminSettings />} />
                  <Route path="audit" element={<AdminAudit />} />
                </Route>

                <Route path="*" element={<NotFound />} />
              </Routes>
            </Suspense>
          </ErrorBoundary>
        </ToastProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}

class ErrorBoundary extends Component<{ children: ReactNode }, { hasError: boolean; message: string }> {
  state = { hasError: false, message: '' };
  static getDerivedStateFromError(error: Error) {
    return { hasError: true, message: error.message };
  }
  componentDidCatch(error: Error) {
    console.error('Unhandled error:', error);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center p-6">
          <div className="glass-card max-w-md p-8 text-center">
            <h1 className="text-xl font-bold text-white">Something went wrong</h1>
            <p className="mt-2 text-sm text-neutral-400">{this.state.message}</p>
            <button
              onClick={() => window.location.reload()}
              className="btn-primary mt-6"
            >
              Reload page
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
