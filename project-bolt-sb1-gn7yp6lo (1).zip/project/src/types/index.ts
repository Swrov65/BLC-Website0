export type AppRole = 'user' | 'admin';

export type Availability = 'live' | 'beta' | 'planned' | 'in_development';

export type Profile = {
  id: string;
  email: string | null;
  display_name: string | null;
  full_name: string | null;
  bio: string | null;
  avatar_url: string | null;
  role: AppRole;
  suspended: boolean;
  created_at: string;
  updated_at: string;
};

export type Product = {
  id: string;
  slug: string;
  name: string;
  tagline: string;
  description: string;
  icon: string;
  features: string[];
  use_cases: string[];
  availability: Availability;
  docs_url: string | null;
  sort_order: number;
  created_at: string;
  updated_at: string;
};

export type Announcement = {
  id: string;
  title: string;
  body: string;
  severity: 'info' | 'warning' | 'critical';
  published: boolean;
  created_at: string;
};

export type ContactSubmission = {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  status: 'new' | 'read' | 'responded' | 'archived';
  created_at: string;
};

export type Project = {
  id: string;
  user_id: string;
  name: string;
  description: string | null;
  status: 'active' | 'paused' | 'archived';
  created_at: string;
  updated_at: string;
};

export type ApiApp = {
  id: string;
  user_id: string;
  name: string;
  key_prefix: string;
  last_used_at: string | null;
  revoked: boolean;
  created_at: string;
};

export type Notification = {
  id: string;
  user_id: string;
  title: string;
  body: string;
  read: boolean;
  created_at: string;
};

export type SupportTicket = {
  id: string;
  user_id: string;
  subject: string;
  message: string;
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  created_at: string;
};

export type DocArticle = {
  slug: string;
  title: string;
  category: string;
  excerpt: string;
  body: string;
  order: number;
};

export type ServiceItem = {
  slug: string;
  name: string;
  description: string;
  benefits: string[];
  icon: string;
};

export type PricingPlan = {
  id: string;
  name: string;
  price: string;
  period: string;
  description: string;
  features: string[];
  cta: string;
  highlighted: boolean;
};

export type ServiceStatus = {
  name: string;
  status: 'operational' | 'degraded' | 'partial_outage' | 'major_outage' | 'maintenance' | 'in_development';
  description: string;
};

export type SiteContent = {
  id: string;
  key: string;
  title: string;
  body: string | null;
  image_url: string | null;
  published: boolean;
  updated_at: string;
  updated_by: string | null;
};

export type AiMessage = {
  id: string;
  conversation_id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  created_at: string;
};

export type AiConversation = {
  id: string;
  user_id: string;
  title: string;
  created_at: string;
  updated_at: string;
};

export type AiUsageTracking = {
  id: string;
  user_id: string;
  date_used: string;
  request_count: number;
  tool_type: string;
  created_at: string;
  updated_at: string;
};

export type ApiUsageLog = {
  id: string;
  user_id: string | null;
  api_app_id: string | null;
  endpoint: string;
  method: string;
  status_code: number | null;
  request_size: number | null;
  response_time_ms: number | null;
  error_message: string | null;
  created_at: string;
};

export type Webhook = {
  id: string;
  user_id: string;
  url: string;
  description: string | null;
  events: string[];
  secret: string | null;
  active: boolean;
  created_at: string;
  updated_at: string;
};

export type WebhookDelivery = {
  id: string;
  webhook_id: string;
  event: string;
  payload: unknown;
  status_code: number | null;
  success: boolean;
  attempt: number;
  created_at: string;
};

export type ProjectFile = {
  id: string;
  project_id: string;
  user_id: string;
  filename: string;
  file_path: string;
  content: string | null;
  file_type: string | null;
  size_bytes: number;
  created_at: string;
  updated_at: string;
};
