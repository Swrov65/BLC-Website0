# Bangladesh Logic Code (BLC)

**Build Beyond.** — Intelligent Technology. Limitless Possibilities.

Founded and developed by **Soyaif**.

A complete technology platform built with React, TypeScript, Vite, Tailwind CSS, and Supabase.

## Features

- Public website: Home, About, Products, Services, Pricing, Contact, Docs, Status, Security, Privacy, Terms
- AI Lab with chat interface (server-side AI provider proxy)
- Developer Center with API key management
- User dashboard: overview, profile, projects, notifications, security, support, API keys
- Admin panel: overview, user management, contact moderation, content, settings, audit logs
- Authentication via Supabase (email/password)
- Row Level Security on every table
- Server-side admin authorization (role from JWT app_metadata)
- Responsive, accessible, dark futuristic theme
- Custom 404 page
- SEO: meta tags, sitemap, robots.txt

## Tech Stack

- React 18 + TypeScript
- Vite 7
- Tailwind CSS 3
- React Router 7
- Supabase (auth, database, storage, edge functions)
- Zod + React Hook Form for validation
- Lucide React for icons

## Getting Started

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
npm run typecheck
```

## Environment Variables

Copy `.env.example` to `.env`. Supabase variables are pre-provisioned:

- `VITE_SUPABASE_URL` — Supabase project URL (frontend)
- `VITE_SUPABASE_ANON_KEY` — Supabase anon public key (frontend)
- `SUPABASE_SERVICE_ROLE_KEY` — server-only (edge functions)
- `AI_API_KEY` — AI provider key (set in Supabase Edge Function secrets, NOT in .env)
- `AI_PROVIDER` — `openai` (default)
- `AI_MODEL` — `gpt-4o-mini` (default)

## Database

All migrations are applied via the Supabase MCP tool. The schema includes:

- `profiles` — user profile with role and suspended flag
- `projects` — user-owned projects
- `api_apps` — API key registrations
- `notifications` — per-user notifications
- `support_tickets` — support requests
- `contact_submissions` — public contact form
- `announcements` — admin-published announcements
- `ai_conversations` / `ai_messages` — AI Lab data
- `platform_settings` — key/value configuration
- `admin_audit_logs` — audit trail

All tables have RLS enabled with ownership-scoped policies.

## Admin Bootstrap

Admin access is enforced server-side. The `is_admin()` SQL function reads the `role` claim from `raw_app_meta_data` (user-immutable JWT metadata).

To provision the first admin, run this SQL in the Supabase dashboard SQL editor (requires service-role access):

```sql
-- Replace with the admin user's UUID and email
UPDATE auth.users
SET raw_app_meta_data = COALESCE(raw_app_meta_data, '{}'::jsonb) || '{"role":"admin"}'::jsonb
WHERE email = 'admin@example.com';
```

Never use a default password. Admin role is never set from the frontend.

## AI Lab Configuration

The AI Lab UI is ready. To enable real AI responses:

1. Set `AI_API_KEY` in Supabase Edge Function secrets (dashboard → Edge Functions → Secrets).
2. Optionally set `AI_PROVIDER` (default: `openai`) and `AI_MODEL` (default: `gpt-4o-mini`).

Until configured, the AI Lab shows a clear "provider not configured" message — no fake responses.

## Deployment

```bash
npm run build
```

The `dist/` folder contains the production build. Deploy to any static host with SPA fallback routing. The Supabase backend (database, auth, edge functions) is already provisioned.

## Project Structure

```
src/
  auth/          — Auth context and route guards
  components/    — Shared UI components
  layouts/       — Public, Dashboard, Admin layouts
  lib/           — Supabase client, data, utils
  pages/         — All pages (public, auth, dashboard, admin)
  types/         — TypeScript types
supabase/
  config.toml
  functions/ai-chat/
```

## Developer

Soyaif — Founder and Developer of Bangladesh Logic Code.
