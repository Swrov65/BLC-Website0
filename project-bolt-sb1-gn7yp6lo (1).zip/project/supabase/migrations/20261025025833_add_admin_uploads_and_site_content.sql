/*
# Admin uploads storage bucket and site_content table

1. New Storage Bucket
- `admin_uploads` — private bucket for admin-uploaded images and documents.
- Only admins can upload, update, delete files.
- Only admins can read files (signed URLs required; bucket is NOT public).
- File path pattern: admin/<uuid-generated-filename>

2. New Table: site_content
- `id` uuid primary key
- `key` text unique — content identifier (e.g. "hero_title", "about_body")
- `title` text — human-readable label
- `body` text — content value (text/HTML)
- `image_url` text — optional associated image (from admin_uploads bucket)
- `updated_at` timestamptz
- `updated_by` uuid — admin who last edited

3. Security
- RLS on site_content: only admins can SELECT/INSERT/UPDATE/DELETE.
- Storage policies: only admins can CRUD in admin_uploads bucket.
- Public can read published site_content (for rendering on the public site).
- File type validation is enforced in the frontend (image/pdf/docs only, max 5MB).
*/

-- ============ site_content table ============
CREATE TABLE IF NOT EXISTS public.site_content (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  title text NOT NULL,
  body text,
  image_url text,
  published boolean NOT NULL DEFAULT false,
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_site_content_key ON public.site_content(key);

ALTER TABLE public.site_content ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON public.site_content TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.site_content TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.site_content TO service_role;

-- Public can read published content
DROP POLICY IF EXISTS "public_select_site_content" ON public.site_content;
CREATE POLICY "public_select_site_content" ON public.site_content FOR SELECT
  TO anon, authenticated USING (published = true OR public.is_admin());

-- Only admins can insert
DROP POLICY IF EXISTS "admin_insert_site_content" ON public.site_content;
CREATE POLICY "admin_insert_site_content" ON public.site_content FOR INSERT
  TO authenticated WITH CHECK (public.is_admin());

-- Only admins can update
DROP POLICY IF EXISTS "admin_update_site_content" ON public.site_content;
CREATE POLICY "admin_update_site_content" ON public.site_content FOR UPDATE
  TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

-- Only admins can delete
DROP POLICY IF EXISTS "admin_delete_site_content" ON public.site_content;
CREATE POLICY "admin_delete_site_content" ON public.site_content FOR DELETE
  TO authenticated USING (public.is_admin());

-- ============ Admin uploads storage bucket ============
INSERT INTO storage.buckets (id, name, public)
VALUES ('admin_uploads', 'admin_uploads', false)
ON CONFLICT (id) DO NOTHING;

-- Admin can upload files
DROP POLICY IF EXISTS "admin_upload_files" ON storage.objects;
CREATE POLICY "admin_upload_files" ON storage.objects FOR INSERT
  TO authenticated WITH CHECK (bucket_id = 'admin_uploads' AND public.is_admin());

-- Admin can read files (for generating signed URLs)
DROP POLICY IF EXISTS "admin_read_files" ON storage.objects;
CREATE POLICY "admin_read_files" ON storage.objects FOR SELECT
  TO authenticated USING (bucket_id = 'admin_uploads' AND public.is_admin());

-- Admin can update/replace files
DROP POLICY IF EXISTS "admin_update_files" ON storage.objects;
CREATE POLICY "admin_update_files" ON storage.objects FOR UPDATE
  TO authenticated USING (bucket_id = 'admin_uploads' AND public.is_admin())
  WITH CHECK (bucket_id = 'admin_uploads' AND public.is_admin());

-- Admin can delete files
DROP POLICY IF EXISTS "admin_delete_files" ON storage.objects;
CREATE POLICY "admin_delete_files" ON storage.objects FOR DELETE
  TO authenticated USING (bucket_id = 'admin_uploads' AND public.is_admin());
