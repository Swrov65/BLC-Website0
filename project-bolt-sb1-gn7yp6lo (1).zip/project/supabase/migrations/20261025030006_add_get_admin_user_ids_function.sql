/*
# Admin user listing function

1. New Function: get_admin_user_ids
- Returns a list of user IDs that have the admin role in raw_app_meta_data.
- SECURITY DEFINER so it can read auth.users (which authenticated role cannot).
- Only callable by admins (is_admin() check inside).
- Returns TABLE(user_id uuid).

2. Security
- REVOKE EXECUTE from PUBLIC and anon.
- GRANT EXECUTE to authenticated (but function body checks is_admin()).
- search_path set to public for security.
*/

CREATE OR REPLACE FUNCTION public.get_admin_user_ids()
RETURNS TABLE(user_id uuid)
LANGUAGE sql
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
  SELECT (auth.users.id)::uuid AS user_id
  FROM auth.users
  WHERE auth.users.raw_app_meta_data->>'role' = 'admin'
  AND public.is_admin();
$$;

REVOKE EXECUTE ON FUNCTION public.get_admin_user_ids() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_admin_user_ids() TO authenticated;
