/*
# BLC Platform Expansion Schema

1. New Tables:
- ai_usage_tracking — per-user AI request counts and daily limits
- api_usage_logs — per-request API logs for developer platform
- webhooks — user-configured webhook endpoints
- webhook_deliveries — delivery attempt records
- project_files — files belonging to user projects (BLC Studio/Cloud)

2. Modified Tables:
- api_apps — add key_hash column (stores SHA-256 hash of API key for secure lookup)

3. Security:
- RLS enabled on all new tables.
- Owner-scoped policies for user tables (ai_usage_tracking, webhooks, project_files).
- api_usage_logs: user can see only their own logs.
- webhook_deliveries: user can see only their own webhook deliveries.
- Admins can read all via is_admin() checks.
- Grants are minimal: only the verbs each role needs.
*/

-- ============ ai_usage_tracking ============
CREATE TABLE IF NOT EXISTS public.ai_usage_tracking (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  date_used date NOT NULL DEFAULT CURRENT_DATE,
  request_count integer NOT NULL DEFAULT 0,
  tool_type text NOT NULL DEFAULT 'chat' CHECK (tool_type IN ('chat','writing','code','research','learning','productivity','image_prompt','av_planning')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, date_used, tool_type)
);

CREATE INDEX IF NOT EXISTS idx_ai_usage_user_date ON public.ai_usage_tracking(user_id, date_used);

ALTER TABLE public.ai_usage_tracking ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE ON public.ai_usage_tracking TO authenticated;
GRANT SELECT, INSERT, UPDATE ON public.ai_usage_tracking TO service_role;

DROP POLICY IF EXISTS "select_own_ai_usage" ON public.ai_usage_tracking;
CREATE POLICY "select_own_ai_usage" ON public.ai_usage_tracking FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_ai_usage" ON public.ai_usage_tracking;
CREATE POLICY "insert_own_ai_usage" ON public.ai_usage_tracking FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_ai_usage" ON public.ai_usage_tracking;
CREATE POLICY "update_own_ai_usage" ON public.ai_usage_tracking FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- ============ api_usage_logs ============
CREATE TABLE IF NOT EXISTS public.api_usage_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  api_app_id uuid REFERENCES public.api_apps(id) ON DELETE CASCADE,
  endpoint text NOT NULL,
  method text NOT NULL,
  status_code integer,
  request_size integer,
  response_time_ms integer,
  error_message text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_api_usage_user ON public.api_usage_logs(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_api_usage_app ON public.api_usage_logs(api_app_id, created_at DESC);

ALTER TABLE public.api_usage_logs ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON public.api_usage_logs TO authenticated;
GRANT SELECT, INSERT ON public.api_usage_logs TO service_role;

DROP POLICY IF EXISTS "select_own_api_logs" ON public.api_usage_logs;
CREATE POLICY "select_own_api_logs" ON public.api_usage_logs FOR SELECT
  TO authenticated USING (auth.uid() = user_id OR public.is_admin());

-- ============ webhooks ============
CREATE TABLE IF NOT EXISTS public.webhooks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  url text NOT NULL,
  description text,
  events text[] NOT NULL DEFAULT '{}',
  secret text,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_webhooks_user ON public.webhooks(user_id);

ALTER TABLE public.webhooks ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON public.webhooks TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.webhooks TO service_role;

DROP POLICY IF EXISTS "select_own_webhooks" ON public.webhooks;
CREATE POLICY "select_own_webhooks" ON public.webhooks FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_webhooks" ON public.webhooks;
CREATE POLICY "insert_own_webhooks" ON public.webhooks FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_webhooks" ON public.webhooks;
CREATE POLICY "update_own_webhooks" ON public.webhooks FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_webhooks" ON public.webhooks;
CREATE POLICY "delete_own_webhooks" ON public.webhooks FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============ webhook_deliveries ============
CREATE TABLE IF NOT EXISTS public.webhook_deliveries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  webhook_id uuid NOT NULL REFERENCES public.webhooks(id) ON DELETE CASCADE,
  event text NOT NULL,
  payload jsonb,
  status_code integer,
  success boolean NOT NULL DEFAULT false,
  attempt integer NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_webhook_deliveries_webhook ON public.webhook_deliveries(webhook_id, created_at DESC);

ALTER TABLE public.webhook_deliveries ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON public.webhook_deliveries TO authenticated;
GRANT SELECT, INSERT ON public.webhook_deliveries TO service_role;

DROP POLICY IF EXISTS "select_own_webhook_deliveries" ON public.webhook_deliveries;
CREATE POLICY "select_own_webhook_deliveries" ON public.webhook_deliveries FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM public.webhooks WHERE webhooks.id = webhook_deliveries.webhook_id AND webhooks.user_id = auth.uid())
  );

-- ============ project_files ============
CREATE TABLE IF NOT EXISTS public.project_files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  filename text NOT NULL,
  file_path text NOT NULL,
  content text,
  file_type text,
  size_bytes integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(project_id, file_path)
);

CREATE INDEX IF NOT EXISTS idx_project_files_project ON public.project_files(project_id);
CREATE INDEX IF NOT EXISTS idx_project_files_user ON public.project_files(user_id);

ALTER TABLE public.project_files ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON public.project_files TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.project_files TO service_role;

DROP POLICY IF EXISTS "select_own_project_files" ON public.project_files;
CREATE POLICY "select_own_project_files" ON public.project_files FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_project_files" ON public.project_files;
CREATE POLICY "insert_own_project_files" ON public.project_files FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_project_files" ON public.project_files;
CREATE POLICY "update_own_project_files" ON public.project_files FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_project_files" ON public.project_files;
CREATE POLICY "delete_own_project_files" ON public.project_files FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============ api_apps: add key_hash column ============
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'api_apps' AND column_name = 'key_hash') THEN
    ALTER TABLE public.api_apps ADD COLUMN key_hash text;
  END IF;
END
$$;

CREATE INDEX IF NOT EXISTS idx_api_apps_key_hash ON public.api_apps(key_hash) WHERE key_hash IS NOT NULL;
