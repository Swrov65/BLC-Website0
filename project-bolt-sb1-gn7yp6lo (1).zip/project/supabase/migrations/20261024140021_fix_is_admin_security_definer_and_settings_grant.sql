-- 1. Convert is_admin() to SECURITY INVOKER — it only reads auth.jwt() which is
--    available to the calling role. No elevated privileges needed. This clears
--    the Supabase advisor warning about callable SECURITY DEFINER functions.
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT COALESCE(
    (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin',
    false
  );
$$;

-- Keep EXECUTE grants as before: authenticated + service_role can call it
REVOKE EXECUTE ON FUNCTION public.is_admin() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated, service_role;

-- 2. Add INSERT grant to platform_settings so admin upsert (INSERT ... ON CONFLICT UPDATE) works
--    Currently only SELECT, UPDATE granted to authenticated. Upsert requires INSERT privilege.
GRANT INSERT ON public.platform_settings TO authenticated;

-- 3. Add admin INSERT policy on platform_settings so upsert passes RLS
DROP POLICY IF EXISTS "admin_insert_settings" ON public.platform_settings;
CREATE POLICY "admin_insert_settings" ON public.platform_settings FOR INSERT
  TO authenticated WITH CHECK (public.is_admin());
