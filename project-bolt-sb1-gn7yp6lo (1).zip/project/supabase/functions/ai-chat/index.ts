// BLC AI Chat Edge Function
// Proxies AI provider requests server-side so API keys never reach the browser.
// Supports multiple tool types with specialized system prompts.
// Includes per-user daily usage tracking and rate limiting.
import { createClient } from 'npm:@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

const supabaseUrl = Deno.env.get('SUPABASE_URL') ?? Deno.env.get('VITE_SUPABASE_URL') ?? '';

const AI_API_KEY = Deno.env.get('AI_API_KEY') ?? '';
const AI_MODEL = Deno.env.get('AI_MODEL') ?? 'gpt-4o-mini';
const AI_PROVIDER = Deno.env.get('AI_PROVIDER') ?? 'openai';

const isConfigured = Boolean(AI_API_KEY && AI_PROVIDER);

const DAILY_LIMIT = 50;

const toolPrompts: Record<string, string> = {
  chat: 'You are BLC Intelligence, a helpful AI assistant for the Bangladesh Logic Code platform. Be concise and accurate.',
  writing: 'You are BLC Writing Assistant. Help users write clear, professional content. Improve grammar, structure, and clarity. Provide drafts and revisions.',
  code: 'You are BLC Code Assistant. Help users write, debug, and understand code. Provide working examples with explanations. Always use proper syntax and best practices.',
  research: 'You are BLC Research Assistant. Help users find and synthesize information. Always note when information may be outdated or unverified. Never fabricate sources or claim unverified information is verified.',
  learning: 'You are BLC Learning Assistant. Help users learn new topics with clear explanations, examples, and practice questions. Adapt to the user\'s skill level.',
  productivity: 'You are BLC Productivity Assistant. Help users plan tasks, organize workflows, and improve efficiency. Provide actionable, structured advice.',
  image_prompt: 'You are BLC Image Prompt Generator. Create detailed, effective prompts for image generation AI. Include style, composition, lighting, and mood descriptions.',
  av_planning: 'You are BLC Audio/Video Content Planning Assistant. Help users plan audio and video content — scripts, outlines, shot lists, and production schedules. Do not generate actual audio or video.',
  math: 'You are BLC Math Solver. Solve mathematical problems step by step, showing each step clearly. Explain the reasoning behind each step. Support algebra, calculus, geometry, statistics, and more. Use clear notation.',
  translator: 'You are BLC Translator. Translate text between languages accurately and naturally. Preserve tone and context. Support Bengali, English, and all major languages. If the user does not specify a target language, ask them which language they want to translate to.',
  presentation: 'You are BLC Presentation Maker. Create presentation outlines with slide titles, bullet points, and speaker notes. Structure content logically. Format output as numbered slides with clear sections.',
  website_builder: 'You are BLC Website Builder. Help users create website layouts and generate HTML, CSS, and JavaScript code from descriptions. Provide complete, working code snippets. Explain design choices.',
  app_builder: 'You are BLC App Builder. Help users plan and generate application code, project structures, and implementation guides. Provide architecture recommendations and working code examples.',
  support: 'You are BLC Customer Support Assistant. Help users with questions about the Bangladesh Logic Code platform. Be helpful, accurate, and concise. If you do not know the answer, direct users to the support ticket system.',
  document: 'You are BLC Document Reader Assistant. Help users extract and summarize text from documents. Answer questions about document contents. Note that you cannot directly read files — users should paste relevant text.',
  pdf: 'You are BLC PDF Assistant. Help users understand and summarize PDF content. Answer questions about PDF text. Users should paste relevant text since direct file reading is not available.',
  data_analyst: 'You are BLC Data Analyst. Help users analyze data, calculate statistics, identify trends, and suggest visualizations. Users should paste or describe their data. Provide clear, structured analysis.',
};

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  const authHeader = req.headers.get('Authorization') ?? '';
  if (!authHeader.startsWith('Bearer ')) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), {
      status: 401,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  const anonKey = req.headers.get('apikey') ?? Deno.env.get('SUPABASE_ANON_KEY') ?? '';
  const userJwt = authHeader.replace('Bearer ', '');

  const supabase = createClient(supabaseUrl, anonKey, {
    global: { headers: { Authorization: `Bearer ${userJwt}` } },
    auth: { persistSession: false, autoRefreshToken: false },
  });

  const url = new URL(req.url);

  if (url.pathname.endsWith('/status') || url.searchParams.get('status') !== null) {
    return new Response(JSON.stringify({
      configured: isConfigured,
      provider: isConfigured ? AI_PROVIDER : null,
      model: isConfigured ? AI_MODEL : null,
      daily_limit: DAILY_LIMIT,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  if (!isConfigured) {
    return new Response(
      JSON.stringify({
        error: 'AI provider is not configured. An admin must set AI_API_KEY in Edge Function secrets. We do not generate fake AI responses.',
      }),
      { status: 503, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    );
  }

  try {
    const body = await req.json();
    const { conversationId, message, toolType } = body as { conversationId?: string; message?: string; toolType?: string };
    if (!conversationId || !message || typeof message !== 'string') {
      return new Response(JSON.stringify({ error: 'conversationId and message are required' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const tool = toolType && toolPrompts[toolType] ? toolType : 'chat';
    const systemPrompt = toolPrompts[tool];

    // Get user ID from JWT for usage tracking
    const { data: userData, error: userErr } = await supabase.auth.getUser();
    if (userErr || !userData.user) {
      return new Response(JSON.stringify({ error: 'Authentication failed' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
    const userId = userData.user.id;
    const today = new Date().toISOString().split('T')[0];

    // Check daily usage limit
    const { data: usageData } = await supabase
      .from('ai_usage_tracking')
      .select('request_count')
      .eq('user_id', userId)
      .eq('date_used', today)
      .eq('tool_type', tool)
      .maybeSingle();

    const currentCount = (usageData as { request_count?: number } | null)?.request_count ?? 0;
    if (currentCount >= DAILY_LIMIT) {
      return new Response(JSON.stringify({
        error: `Daily limit reached (${DAILY_LIMIT} requests per day for ${tool}). Please try again tomorrow.`,
        limit: DAILY_LIMIT,
        used: currentCount,
      }), {
        status: 429,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Save user message
    const { error: insertUserErr } = await supabase
      .from('ai_messages')
      .insert({ conversation_id: conversationId, role: 'user', content: message });
    if (insertUserErr) throw new Error(`Failed to save user message: ${insertUserErr.message}`);

    // Load recent context (last 10 messages)
    const { data: history, error: histErr } = await supabase
      .from('ai_messages')
      .select('role, content')
      .eq('conversation_id', conversationId)
      .order('created_at', { ascending: true })
      .limit(10);
    if (histErr) throw new Error(`Failed to load history: ${histErr.message}`);

    const messages = [
      { role: 'system', content: systemPrompt },
      ...(history ?? []).map((h: { role: string; content: string }) => ({ role: h.role, content: h.content })),
    ];

    const providerUrl = AI_PROVIDER === 'openai'
      ? 'https://api.openai.com/v1/chat/completions'
      : `https://api.${AI_PROVIDER}.com/v1/chat/completions`;

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000);

    const aiRes = await fetch(providerUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${AI_API_KEY}`,
      },
      body: JSON.stringify({ model: AI_MODEL, messages, max_tokens: 800, temperature: 0.7 }),
      signal: controller.signal,
    });
    clearTimeout(timeoutId);

    if (!aiRes.ok) {
      const errText = await aiRes.text();
      throw new Error(`AI provider error (${aiRes.status}): ${errText}`);
    }

    const aiData = await aiRes.json();
    const reply = aiData?.choices?.[0]?.message?.content ?? '(No response from AI provider)';

    // Save assistant reply
    const { data: savedMsg, error: insertAiErr } = await supabase
      .from('ai_messages')
      .insert({ conversation_id: conversationId, role: 'assistant', content: reply })
      .select('id')
      .single();
    if (insertAiErr) throw new Error(`Failed to save assistant message: ${insertAiErr.message}`);

    // Update conversation timestamp
    await supabase.from('ai_conversations').update({ updated_at: new Date().toISOString() }).eq('id', conversationId);

    // Increment usage tracking (upsert)
    await supabase
      .from('ai_usage_tracking')
      .upsert({
        user_id: userId,
        date_used: today,
        tool_type: tool,
        request_count: currentCount + 1,
        updated_at: new Date().toISOString(),
      }, { onConflict: 'user_id,date_used,tool_type' });

    return new Response(JSON.stringify({
      reply,
      messageId: savedMsg?.id ?? null,
      tool_type: tool,
      usage: { used: currentCount + 1, limit: DAILY_LIMIT },
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Unknown error';
    const isTimeout = msg.includes('aborted');
    return new Response(JSON.stringify({
      error: isTimeout ? 'Request timed out. Please try again.' : msg,
    }), {
      status: isTimeout ? 504 : 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
